package com.chinatechstar.crm.vo;

import lombok.Data;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-28 18-13
 * @Description: TODO
 * @Version: 1.0
 */
@Data
public class CrmUserInfoContactVO extends CrmBaseVO{

    private String name;
}
