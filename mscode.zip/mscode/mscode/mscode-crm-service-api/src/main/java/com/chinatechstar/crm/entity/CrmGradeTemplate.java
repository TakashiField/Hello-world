package com.chinatechstar.crm.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.Getter;

import java.io.Serializable;
import java.util.List;

/**
 * 等级模板表(CrmGradeTemplate)实体类
 *
 * @author zhengxl
 * @since 2024-07-02 10:55:02
 */
@Data
public class CrmGradeTemplate implements Serializable {
    private static final long serialVersionUID = -46716469151062047L;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;
    /**
     * 模板名称
     */
    private String templateName;
    /**
     * 来源
     */
    private String srcChannel;
    /**
     * 状态（0-关闭 1-开启）
     */
    private String status;
    /**
     * 模板类型（1-经销商2-供应商3-消费商4-荣誉）
     */
    private String templateType;
    /**
     * 商户ID
     */
    private Long mchtId ;
    /**
     * 模板内容
     */
    private String templateContent;

    private List<CrmGradeTemplateDetail> list;

    public void setList(List<CrmGradeTemplateDetail> list) {
        this.list = list;
    }


}

