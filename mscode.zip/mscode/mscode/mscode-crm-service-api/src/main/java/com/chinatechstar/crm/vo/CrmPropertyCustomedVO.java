package com.chinatechstar.crm.vo;

import com.chinatechstar.crm.entity.CrmPropertyCustomed;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CrmPropertyCustomedVO extends CrmBaseVO {

    //属性名称
    private String propName;
}