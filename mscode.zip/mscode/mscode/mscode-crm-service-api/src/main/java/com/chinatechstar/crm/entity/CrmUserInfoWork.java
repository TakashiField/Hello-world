package com.chinatechstar.crm.entity;

import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;
import java.io.Serializable;

/**
 * 会员健康信息表(CrmUserInfoWork)实体类
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:03
 */
@Getter
public class CrmUserInfoWork extends CrmOperEntity implements Serializable {
    private static final long serialVersionUID = -21267194687353033L;
    /**
     * id
     */
    @NotNull(groups = { UpdateValidator.class})
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;
    /**
     * 用户ID
     */
    @NotNull(groups = { InsertValidator.class })
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long userId;
    /**
     * 商户ID
     */
    @NotNull(groups = { InsertValidator.class})
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long mchtId;
    /**
     * 工作类型
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 1 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String workType;
    /**
     * 职业类型
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 1 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String employType;
    /**
     * 单位名称
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 60 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String companyName;
    /**
     * 单位性质
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 10 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String companyProp;
    /**
     * 单位地址
     */
    private String companyAddress;

    private String companyPost;
    /**
     * 行业
     */
    private String industry;
    /**
     * 部门
     */
    private String department;
    /**
     * 职位级别
     */
    private String level;
    /**
     * 入职时间
     */
    private Date entryTime;
    /**
     * 工资发放形势
     */
    private String payType;
    /**
     * 单位电话
     */
    private String companyPhone;
    /**
     * 月均薪资
     */
    private Double salaryAvg;
    /**
     * 其他收入
     */
    private Double salaryOther;
    /**
     * 每月发薪日
     */
    private Integer payDay;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private String createUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 更新人
     */
    private String updateUser;


    public void setId(Long id) {
        this.id = id;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setMchtId(Long mchtId) {
        this.mchtId = mchtId;
    }

    public void setWorkType(String workType) {
        this.workType = workType;
    }

    public void setEmployType(String employType) {
        this.employType = employType;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public void setCompanyProp(String companyProp) {
        this.companyProp = companyProp;
    }

    public void setCompanyAddress(String companyAddress) {
        this.companyAddress = companyAddress;
    }

    public void setCompanyPost(String companyPost) {
        this.companyPost = companyPost;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public void setEntryTime(Date entryTime) {
        this.entryTime = entryTime;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public void setCompanyPhone(String companyPhone) {
        this.companyPhone = companyPhone;
    }

    public void setSalaryAvg(Double salaryAvg) {
        this.salaryAvg = salaryAvg;
    }

    public void setSalaryOther(Double salaryOther) {
        this.salaryOther = salaryOther;
    }

    public void setPayDay(Integer payDay) {
        this.payDay = payDay;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

}

