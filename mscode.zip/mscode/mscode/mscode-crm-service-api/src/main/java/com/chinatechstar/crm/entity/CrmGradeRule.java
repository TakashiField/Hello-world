package com.chinatechstar.crm.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.Getter;

import java.io.Serializable;

/**
 * 等级规则表(CrmGradeRule)实体类
 *
 * @author zhengxl
 * @since 2024-07-03 17:26:54
 */
@Data
public class CrmGradeRule implements Serializable {
    private static final long serialVersionUID = 292529948014236148L;
    /**
     * 等级ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long gradeId;
    /**
     * 规则ID
     */
    private Long ruleId;
    /**
     * 状态
     */
    private String status;





}

