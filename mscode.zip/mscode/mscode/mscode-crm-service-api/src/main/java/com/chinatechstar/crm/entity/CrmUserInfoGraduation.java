package com.chinatechstar.crm.entity;

import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;
import java.io.Serializable;

/**
 * 会员学习信息表(CrmUserInfoGraduation)实体类
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:02
 */
@Getter
public class CrmUserInfoGraduation extends CrmOperEntity implements Serializable {
    private static final long serialVersionUID = 828528212781741093L;
    /**
     * id
     */
    @NotNull(groups = { UpdateValidator.class})
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;
    /**
     * 用户ID
     */
    @NotNull(groups = { InsertValidator.class })
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long userId;
    /**
     * 商户ID
     */
    @NotNull(groups = { InsertValidator.class})
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long mchtId;
    /**
     * 学校名称
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 60 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String schoolName;
    /**
     * 学校性质（public-公办 private-私立、民办）
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 10 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String schoolProp;
    /**
     * 学校地址
     */
    private String schoolAddress;
    /**
     * 学历
     */
    private String degree;
    /**
     * 学年
     */
    private Integer schoolYear;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private String createUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 更新人
     */
    private String updateUser;


    public void setId(Long id) {
        this.id = id;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setMchtId(Long mchtId) {
        this.mchtId = mchtId;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public void setSchoolProp(String schoolProp) {
        this.schoolProp = schoolProp;
    }

    public void setSchoolAddress(String schoolAddress) {
        this.schoolAddress = schoolAddress;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public void setSchoolYear(Integer schoolYear) {
        this.schoolYear = schoolYear;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

}

