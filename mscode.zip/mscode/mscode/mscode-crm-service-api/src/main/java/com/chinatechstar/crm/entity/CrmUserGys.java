package com.chinatechstar.crm.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;

import java.util.Date;
import java.io.Serializable;

/**
 * 供应商列表(CrmUserGys)实体类
 *
 * @author zhengxl
 * @since 2024-07-05 10:01:59
 */
@Getter
public class CrmUserGys implements Serializable {
    private static final long serialVersionUID = -24232948467560816L;
    /**
     * 用户ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long userId;
    /**
     * 姓名
     */
    private String name;
    /**
     * 手机号码
     */
    private String mobile;
    /**
     * 注册时间
     */
    private Date createTime;
    /**
     * 累计供货金额
     */
    private String supplyAmtSum;
    /**
     * 等级
     */
    private String grade;
    /**
     * 来源渠道
     */
    private String srcChannel;
    /**
     * 商户ID
     */
    private Long mchtId ;
    /**
     * 更新时间
     */
    private Date updateTime;


    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public void setSupplyAmtSum(String supplyAmtSum) {
        this.supplyAmtSum = supplyAmtSum;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public void setSrcChannel(String srcChannel) {
        this.srcChannel = srcChannel;
    }

    public void setMchtId(Long mchtId ) {
        this.mchtId = mchtId;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

}

