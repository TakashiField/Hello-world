package com.chinatechstar.crm.entity;

import lombok.Getter;

import java.io.Serializable;

/**
 * 会员关系企业信息表(CrmRelationCorpInfo)实体类
 *
 * @author zhengxl
 * @since 2025-01-22 11:21:33
 */
@Getter
public class CrmRelationCorpInfo implements Serializable {
    private static final long serialVersionUID = 964271118789188640L;
    /**
     * 关系ID
     */
    private Long id;
    /**
     * 企业名称
     */
    private Long corpName;
    /**
     * 组织机构代码
     */
    private String corpCode;
    /**
     * 企业电话
     */
    private String corpTel;
    /**
     * 法人名称
     */
    private Long corpPerson;
    /**
     * 法人手机号
     */
    private String corpPersonMobile;
    /**
     * 联系人姓名
     */
    private String contactName;
    /**
     * 联系人手机号
     */
    private String contactMobile;


    public void setId(Long id) {
        this.id = id;
    }

    public void setCorpName(Long corpName) {
        this.corpName = corpName;
    }

    public void setCorpCode(String corpCode) {
        this.corpCode = corpCode;
    }

    public void setCorpTel(String corpTel) {
        this.corpTel = corpTel;
    }

    public void setCorpPerson(Long corpPerson) {
        this.corpPerson = corpPerson;
    }

    public void setCorpPersonMobile(String corpPersonMobile) {
        this.corpPersonMobile = corpPersonMobile;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public void setContactMobile(String contactMobile) {
        this.contactMobile = contactMobile;
    }

}

