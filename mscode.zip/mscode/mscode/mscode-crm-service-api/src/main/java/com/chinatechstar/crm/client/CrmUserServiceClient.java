//package com.chinatechstar.crm.client;
//
//import com.chinatechstar.component.commons.result.ListResult;
//import com.chinatechstar.component.commons.result.ResultBuilder;
//import com.chinatechstar.crm.entity.CrmUser;
//import com.chinatechstar.crm.vo.CrmUserVO;
//import org.springframework.cloud.openfeign.FeignClient;
//import org.springframework.validation.annotation.Validated;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestParam;
//
//import java.util.LinkedHashMap;
//import java.util.List;
//
///**
// * 提供给其他微服务调用的字典微服务接口层
// *
// * @版权所有 东软集团
// */
//@FeignClient(name = "mscode-crm-service", path = "/crm/crmUser", fallback = CrmUserServiceClientFallback.class)
//public interface CrmUserServiceClient {
//
//	/**
//	 * 分页查询
//	 * @param vo
//	 * @return
//	 */
//	@GetMapping(value = "/queryByPage")
//	List<CrmUser> queryByPage(@RequestBody @Validated CrmUserVO vo);
//
//	@PostMapping("/sync")
//	public CrmUserVO sync(@RequestBody @Validated CrmUserVO crmUser);
//
//}
