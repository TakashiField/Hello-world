package com.chinatechstar.crm.entity;

import lombok.Getter;

import java.util.Date;
import java.io.Serializable;

/**
 * 会员资产明细表(CrmUserWealthInfoDetail)实体类
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:02
 */
@Getter
public class CrmUserWealthInfoDetail implements Serializable {
    private static final long serialVersionUID = -39538943884626749L;
    /**
     * ID
     */
    private Integer id;
    /**
     * 用户ID
     */
    private Long userId;
    /**
     * 商户ID
     */
    private Long mchtId ;
    /**
     * 姓名
     */
    private String name;
    /**
     * 证件类型
     */
    private String idtType;
    /**
     * 证件号码
     */
    private String idtNo;
    /**
     * 资产类型
     */
    private String wealthType;
    /**
     * 资产内容
     */
    private String wealthContent;
    /**
     * 资产价值
     */
    private String wealthWorth;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private String createUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 更新人
     */
    private String updateUser;
    /**
     * 来源
     */
    private String srcChannel;
    /**
     * 资产名称
     */
    private String wealthName;
    /**
     * 资产收益
     */
    private String wealthBenefit;


    public void setId(Integer id) {
        this.id = id;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setMchtId(Long mchtId ) {
        this.mchtId = mchtId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setIdtType(String idtType) {
        this.idtType = idtType;
    }

    public void setIdtNo(String idtNo) {
        this.idtNo = idtNo;
    }

    public void setWealthType(String wealthType) {
        this.wealthType = wealthType;
    }

    public void setWealthContent(String wealthContent) {
        this.wealthContent = wealthContent;
    }

    public void setWealthWorth(String wealthWorth) {
        this.wealthWorth = wealthWorth;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public void setSrcChannel(String srcChannel) {
        this.srcChannel = srcChannel;
    }

    public void setWealthName(String wealthName) {
        this.wealthName = wealthName;
    }

    public void setWealthBenefit(String wealthBenefit) {
        this.wealthBenefit = wealthBenefit;
    }

}

