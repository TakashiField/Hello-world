package com.chinatechstar.crm.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.Getter;

import java.util.Date;
import java.io.Serializable;

/**
 * 合作商管理表(CrmCooperationManager)实体类
 *
 * @author zhengxl
 * @since 2024-07-01 10:20:45
 */
@Data
public class CrmCooperationManager implements Serializable {
    private static final long serialVersionUID = 937270375943895102L;
    /**
     * 用户ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long userId;
    /**
     * 姓名
     */
    private String name;
    /**
     * 手机号码
     */
    private String mobile;
    /**
     * 邮箱
     */
    private String email;
    /**
     * 行业
     */
    private String industry;
    /**
     * 性别
     */
    private String sex;
    /**
     * 供应物资：多种，隔开
     */
    private String supplyGood;
    /**
     * 区域
     */
    private String area;
    /**
     * 详细地址
     */
    private String address;
    /**
     * 是否签订合同
     */
    private String issigned;
    /**
     * 合同路径
     */
    private String contract;
    /**
     * 等级
     */
    private String grade;
    /**
     * 来源渠道
     */
    private String srcChannel;
    /**
     * 审核理由
     */
    private String checkRemark;
    /**
     * 审核状态
     */
    private String checkStatus;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private String createUser;

    private Date updateTime;
    /**
     * 更新人
     */
    private String updateUser;
    /**
     * 审核时间
     */
    private Date checkTime;
    /**
     * 审核人
     */
    private String checkUser;
    /**
     * 合作类型：1-经销商2-供应商3-消费商
     */
    private String coopType;
    /**
     * 商户ID
     */
    private Long mchtId ;




}

