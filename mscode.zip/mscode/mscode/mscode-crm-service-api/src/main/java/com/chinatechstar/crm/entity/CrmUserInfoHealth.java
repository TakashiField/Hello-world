package com.chinatechstar.crm.entity;

import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;
import java.io.Serializable;

/**
 * 会员健康信息表(CrmUserInfoHealth)实体类
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:03
 */
@Getter
public class CrmUserInfoHealth extends CrmOperEntity implements Serializable {
    private static final long serialVersionUID = -73301744664423395L;
    /**
     * id
     */
    @NotNull(groups = { UpdateValidator.class})
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;
    /**
     * 用户ID
     */
    @NotNull(groups = { InsertValidator.class })
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long userId;
    /**
     * 商户ID
     */
    @NotNull(groups = { InsertValidator.class})
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long mchtId;
    /**
     * 血型
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 10 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String bloodType;
    /**
     * 医疗费用支付方式
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 10 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String feePayType;
    /**
     * 过敏史
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 10 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String allergy;
    /**
     * 慢性疾病
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 20 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String chronicDisease;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private String createUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 更新人
     */
    private String updateUser;


    public void setId(Long id) {
        this.id = id;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setMchtId(Long mchtId) {
        this.mchtId = mchtId;
    }

    public void setBloodType(String bloodType) {
        this.bloodType = bloodType;
    }

    public void setFeePayType(String feePayType) {
        this.feePayType = feePayType;
    }

    public void setAllergy(String allergy) {
        this.allergy = allergy;
    }

    public void setChronicDisease(String chronicDisease) {
        this.chronicDisease = chronicDisease;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

}

