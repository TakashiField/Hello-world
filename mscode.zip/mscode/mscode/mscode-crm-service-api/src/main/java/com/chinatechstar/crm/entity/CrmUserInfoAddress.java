package com.chinatechstar.crm.entity;

import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.Getter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;
import java.io.Serializable;

/**
 * 会员地址信息表(CrmUserInfoAddress)实体类
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:01
 */
@Data
public class CrmUserInfoAddress extends CrmOperEntity implements Serializable {
    private static final long serialVersionUID = 222231349093897851L;
    /**
     * ID
     */
    @NotNull(groups = { UpdateValidator.class})
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;
    /**
     * 会员ID
     */
    @NotNull(groups = { InsertValidator.class })
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long userId;
    /**
     * 商户ID
     */
    @NotNull(groups = { InsertValidator.class})
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long mchtId;
    /**
     * 地址类型（工作、家庭等）
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 2 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String addressType;
    /**
     * 省
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 20 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String province;
    /**
     * 市
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 20 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String city;
    /**
     * 县
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 20 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String county;
    /**
     * 详细地址
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 128 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String address;
    /**
     * 邮编
     */
    private String post;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private String createUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 更新人
     */
    private String updateUser;




}

