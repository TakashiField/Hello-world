package com.chinatechstar.crm.vo;

import com.chinatechstar.crm.entity.CrmRelationType;
import lombok.Getter;
import lombok.Setter;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-06-27 14-37
 * @Description: TODO
 * @Version: 1.0
 */
@Getter
@Setter
public class CrmRelationSymbolVO extends CrmBaseVO{

    private String symbolName;

}
