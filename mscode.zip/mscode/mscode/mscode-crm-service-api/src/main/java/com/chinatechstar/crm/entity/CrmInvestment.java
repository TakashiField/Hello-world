package com.chinatechstar.crm.entity;

import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * 招商加盟表(CrmInvestment)实体类
 *
 * @author zhengxl
 * @since 2024-07-16 09:50:30
 */
@Getter
public class CrmInvestment implements Serializable {
    private static final long serialVersionUID = 769732506936238158L;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;
    /**
     * 加盟类型
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class })
    @Size(max = 1 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String investType;
    /**
     * 姓名
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class })
    @Size(max = 60 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String name;
    /**
     * 手机号码
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 20 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String mobile;
    /**
     * 消费者会员等级
     */
    private Integer vipGrade;
    /**
     * 状态
     */
    private String status;
    /**
     * 备注
     */
    private String remark;
    /**
     * 商户ID
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 45 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private Long mchtId;
    /**
     * 性别
     */
    private String sex;


    public void setId(Long id) {
        this.id = id;
    }

    public void setInvestType(String investType) {
        this.investType = investType;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setVipGrade(Integer vipGrade) {
        this.vipGrade = vipGrade;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public void setMchtId(Long mchtId) {
        this.mchtId = mchtId;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

}

