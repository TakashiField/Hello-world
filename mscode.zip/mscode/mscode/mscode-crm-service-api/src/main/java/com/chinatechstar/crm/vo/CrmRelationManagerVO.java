package com.chinatechstar.crm.vo;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-06-27 14-26
 * @Description: TODO
 * @Version: 1.0
 */
@Getter
@Setter
public class CrmRelationManagerVO extends CrmBaseVO{

    private String name;

    private String relationName;

    private String mobile;

    private String relationType;

    private String mobileRelated;

    private String relationTypeId;

    private String relationNameId;

    // 区分个人和企业  ，选项参数配置
    private String type;
    // 证件类型
    private String idType;
    // 证件号码
    private String idNo;

    private String nameRelated;
    private String idTypeRelated;
    private String idNoRelated;

//    @NotBlank
//    private String relationProperty;

//    @NotNull
//    private String isMcht;
}
