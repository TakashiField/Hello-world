package com.chinatechstar.crm.vo;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2025-01-16 13-49
 * @Description: TODO
 * @Version: 1.0
 */
public class CrmInvestmentVO extends CrmBaseVO{
}
