package com.chinatechstar.crm.entity;

import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;
import lombok.Data;
import lombok.Getter;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.io.Serializable;

/**
 * 会员地址信息表(CrmUserAddress)实体类
 *
 * @author zhengxl
 * @since 2024-07-05 10:01:59
 */
@Data
public class CrmUserAddress implements Serializable {
    private static final long serialVersionUID = 952075748003411808L;
    /**
     * ID
     */
    @NotNull(groups = { UpdateValidator.class })
    private Long id;
    /**
     * 会员ID
     */
    @NotNull(groups = { InsertValidator.class })
    private Long userId;
    /**
     * 商户ID
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    private Long mchtId ;
    /**
     * 地址类型（工作、家庭等）
     */
    private String addressType;
    /**
     * 省
     */
    private String provice;
    /**
     * 市
     */
    private String city;
    /**
     * 县
     */
    private String county;
    /**
     * 详细地址
     */
    private String address;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private String createUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 更新人
     */
    private String updateUser;




}

