package com.chinatechstar.crm.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.Getter;

import java.io.Serializable;

/**
 * 自定义标签值表(CrmPropertyCustomedValue)实体类
 *
 * @author makejava
 * @since 2024-06-24 17:20:22
 */
@Data
public class CrmPropertyCustomedValue implements Serializable {
    private static final long serialVersionUID = -29788948919119259L;
    /**
     * 用户ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long userId;
    /**
     * 标签ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private String propId;
    /**
     * 标签值
     */
    private String propValue;

    private String propName;




}

