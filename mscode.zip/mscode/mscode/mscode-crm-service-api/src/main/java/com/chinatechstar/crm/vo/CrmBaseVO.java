package com.chinatechstar.crm.vo;

import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;
import lombok.Getter;
import lombok.Setter;
import org.apache.poi.ss.formula.functions.T;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-06-27 14-29
 * @Description: TODO
 * @Version: 1.0
 */
@Getter
@Setter
public class CrmBaseVO<T> implements Serializable {

    private static final long serialVersionUID = 6332697217948480782L;
    Integer currentPage = 1;// 当前页数
    Integer pageSize = 10;// 每页记录数
    Long totalSize;//总条数
    Integer totalPage;//总页数
    String sorter;// 排序

    //@NotBlank(message = "商户ID 不能为空")
    @Size(max = 32, min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private Long mchtId ;
    //用户ID
    private Long userId;
    //查询列表
    private List<T> crmList;
    //操作员ID
    private Long operatorId;
    //操作元姓名
    private String operatorName;

}
