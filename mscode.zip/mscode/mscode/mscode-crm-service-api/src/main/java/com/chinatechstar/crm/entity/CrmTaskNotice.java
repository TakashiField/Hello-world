package com.chinatechstar.crm.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.Getter;

import java.util.Date;
import java.io.Serializable;

/**
 * 通知提醒表(CrmTaskNotice)实体类
 *
 * @author zhengxl
 * @since 2024-07-15 15:47:56
 */
@Data
public class CrmTaskNotice implements Serializable {
    private static final long serialVersionUID = -82753837527176879L;
    /**
     * 任务ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;
    /**
     * 提醒名称
     */
    private String taskName;
    /**
     * 是否发送短信
     */
    private String sendSmsOn;
    /**
     * 发送时间
     */
    private Integer sendTime;
    /**
     * 发送周期
     */
    private String sendRecycle;
    /**
     * 相关权益
     */
    private String benifitRelated;
    /**
     * 发送内容
     */
    private String sendContent;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private String createUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 更新人
     */
    private String updateUser;
    /**
     * 通配符
     */
    private String characters;
    /**
     * 商户ID
     */
    private Long mchtId ;




}

