package com.chinatechstar.crm.vo;

import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-28 18-17
 * @Description: TODO
 * @Version: 1.0
 */
@Data
public class CrmUserInfoHealthVO extends CrmBaseVO{

    private String bloodType;
    /**
     * 医疗费用支付方式
     */
    private String feePayType;
    /**
     * 过敏史
     */

    private String allergy;
    /**
     * 慢性疾病
     */
    private String chronicDisease;

}
