package com.chinatechstar.crm.vo;

import lombok.Getter;
import lombok.Setter;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-08 09-22
 * @Description: TODO
 * @Version: 1.0
 */
@Getter
@Setter
public class CrmUserHonorVO extends CrmBaseVO{

    private Long userId;

    private String mobile;

    private String srcChannel;
}
