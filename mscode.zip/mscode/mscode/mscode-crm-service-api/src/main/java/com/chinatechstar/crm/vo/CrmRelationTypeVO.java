package com.chinatechstar.crm.vo;

import com.chinatechstar.crm.entity.CrmRelationType;
import lombok.Getter;
import lombok.Setter;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-06-27 10-08
 * @Description: TODO
 * @Version: 1.0
 */
@Getter
@Setter
public class CrmRelationTypeVO extends CrmBaseVO {

    private Long id;
    /**
     * 关系类别
     */
    private String relationType;
    /**
     * 状态
     */
    private String status;


}
