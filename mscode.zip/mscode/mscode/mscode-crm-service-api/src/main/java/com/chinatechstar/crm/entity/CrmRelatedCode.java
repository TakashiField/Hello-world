package com.chinatechstar.crm.entity;

import lombok.Getter;

import java.util.Date;
import java.io.Serializable;

/**
 * 会员分享信息表(CrmRelatedCode)实体类
 *
 * @author makejava
 * @since 2024-06-25 08:55:11
 */
@Getter
public class CrmRelatedCode implements Serializable {
    private static final long serialVersionUID = 202953189743365403L;
    /**
     * 会员ID
     */
    private Long userId;
    /**
     * 商户ID
     */
    private Long mchtId ;
    /**
     * 分享码
     */
    private String shareCode;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 关联状态
     */
    private String status;


    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setMchtId(Long mchtId ) {
        this.mchtId = mchtId;
    }

    public void setShareCode(String shareCode) {
        this.shareCode = shareCode;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}

