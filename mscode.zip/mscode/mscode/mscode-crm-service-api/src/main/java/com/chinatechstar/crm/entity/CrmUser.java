package com.chinatechstar.crm.entity;

import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;
import java.io.Serializable;
import java.util.List;

/**
 * 会员基础信息表(CrmUser)实体类
 *
 * @author zhengxl
 * @since 2024-06-28 11:31:37
 */
@Getter
public class CrmUser implements Serializable {
    private static final long serialVersionUID = -65394741583983270L;
    /**
     * 会员ID
     */
    @NotNull(groups = { UpdateValidator.class })
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long userId;
    /**
     * 商户ID
     */
    @NotNull(groups = { InsertValidator.class })
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long mchtId ;
    /**
     * 手机号码
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 20 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String mobile;
    /**
     * 姓名
     */
    private String name;
    /**
     * 性别
     */
    private String sex;
    /**
     * 证件类型
     */
    private String idType;
    /**
     * 证件号码
     */
    private String idNo;
    /**
     * 生日类型（公历-1/阴历-2）
     */
    private String birthType;
    /**
     * 生日
     */
    private Date birthday;
    /**
     * 婚姻状态（已婚-1/未婚-0/其他-9）
     */
    private String isMarried;
    /**
     * 政治面貌
     */
    private String policy;
    /**
     * 来源渠道
     */
    private String srcChannel;
    /**
     * 个人标签
     */
    private String symbol;
    /**
     * 认证方式
     */
    private String idtType;
    /**
     * 认证状态
     */
    private String idtStatus;
    /**
     * 头像
     */
    private String headImg;
    /**
     * 用户名
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 60 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String userName;
    /**
     * 邮箱
     */
    private String email;
    /**
     * 注册时间
     */
    private Date createTime;
    /**
     * 是否企业会员
     */
    private String isMcht;
    /**
     * 是否加盟商（0-否 1-是）
     */
    private String isCoop;
    /**
     * 自定义标签ID，分隔
     */
    private String properties;
    /**
     * 推荐码
     */
    private String shareCode;

    private List<CrmPropertyCustomedValue> propValue;
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setMchtId(Long mchtId ) {
        this.mchtId = mchtId;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public void setIdNo(String idNo) {
        this.idNo = idNo;
    }

    public void setBirthType(String birthType) {
        this.birthType = birthType;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public void setIsMarried(String isMarried) {
        this.isMarried = isMarried;
    }

    public void setPolicy(String policy) {
        this.policy = policy;
    }

    public void setSrcChannel(String srcChannel) {
        this.srcChannel = srcChannel;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public void setIdtType(String idtType) {
        this.idtType = idtType;
    }

    public void setIdtStatus(String idtStatus) {
        this.idtStatus = idtStatus;
    }

    public void setHeadImg(String headImg) {
        this.headImg = headImg;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public void setIsMcht(String isMcht) {
        this.isMcht = isMcht;
    }

    public void setIsCoop(String isCoop) {
        this.isCoop = isCoop;
    }

    public void setProperties(String properties) {
        this.properties = properties;
    }

    public void setShareCode(String shareCode) {
        this.shareCode = shareCode;
    }


    public void setPropValue(List<CrmPropertyCustomedValue> propValue) {
        this.propValue = propValue;
    }
}

