package com.chinatechstar.crm.vo;

import lombok.Data;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-08-07 17-52
 * @Description: TODO
 * @Version: 1.0
 */
@Data
public class CrmDeleteVO {

    private Long[] id;

}
