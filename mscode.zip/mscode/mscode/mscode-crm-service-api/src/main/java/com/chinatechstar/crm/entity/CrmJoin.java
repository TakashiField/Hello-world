package com.chinatechstar.crm.entity;

import lombok.Data;
import lombok.Getter;

import java.io.Serializable;

/**
 * 招商加盟表(CrmJoin)实体类
 *
 * @author zhengxl
 * @since 2024-07-08 15:57:02
 */
@Data
public class CrmJoin implements Serializable {
    private static final long serialVersionUID = 847073782182539847L;
    /**
     * id
     */
    private Long id;
    /**
     * 姓名
     */
    private String name;
    /**
     * 手机号码
     */
    private String mobile;
    /**
     * 加盟类型
     */
    private String coopType;
    /**
     * 性别
     */
    private String sex;
    /**
     * 消费者会员等级
     */
    private String grade;
    /**
     * 状态
     */
    private String status;
    /**
     * 备注
     */
    private String remark;
    /**
     * 商户ID
     */
    private Long mchtId ;






}

