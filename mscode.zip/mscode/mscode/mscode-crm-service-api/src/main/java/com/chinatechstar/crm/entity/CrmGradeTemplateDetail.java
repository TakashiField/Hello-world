package com.chinatechstar.crm.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.Getter;

import java.io.Serializable;
import java.util.List;

/**
 * 等级模板明细表(CrmGradeTemplateDetail)实体类
 *
 * @author zhengxl
 * @since 2024-07-02 10:58:36
 */
@Data
public class CrmGradeTemplateDetail implements Serializable {
    private static final long serialVersionUID = -35422666516693000L;
    /**
     * ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;
    /**
     * 等级
     */
    private String grade;
    /**
     * 等级名称
     */
    private String gradeName;
    /**
     * 等级图标
     */
    private String gradeImage;
    /**
     * 升级规则状态（0-关闭 1-开启 默认开启状态）
     */
    private String rulesUpState;
    /**
     * 降级规则状态（0-关闭 1-开启 默认关闭）
     */
    private String rulesDownState;
    /**
     * 升级规则ID，分割
     */
    private String rulesUpId;
    /**
     * 降级规则ID ，分割
     */
    private String rulesDownId;
    /**
     * 权益规则状态（1-开启 0-关闭 默认关闭）
     */
    private String rulesBenefitStatus;
    /**
     * 权益规则ID
     */
    private String rulesBenefitId;
    /**
     * 成长值（规则里面的奖励分之和）
     */
    private String bonus;
    /**
     * 商户ID
     */
    private Long mchtId ;
    /**
     * 模板ID
     */
    private Long templateId;

    private List<CrmRulesUp> rulesUpList;

    private List<CrmRulesDown> rulesDownList;

    private List<CrmRulesEquity> rulesEquityList;

    private String ruleUpContent;

    private String ruleDownContent;

    private String ruleEquityContent;

    private String status;

}

