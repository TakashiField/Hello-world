package com.chinatechstar.crm.entity;

import lombok.Data;
import lombok.Getter;

import java.util.Date;
import java.io.Serializable;

/**
 * 会员资产信息表(CrmUserWealthInfo)实体类
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:02
 */
@Data
public class CrmUserWealthInfo implements Serializable {
    private static final long serialVersionUID = 420803987532387801L;
    /**
     * ID
     */
    private Integer id;
    /**
     * 用户ID
     */
    private Long userId;
    /**
     * 商户ID
     */
    private Long mchtId ;
    /**
     * 姓名
     */
    private String name;
    /**
     * 证件类型
     */
    private String idtType;
    /**
     * 证件号码
     */
    private String idtNo;
    /**
     * 是否有实物资产
     */
    private String isPhysical;
    /**
     * 是否有虚拟资产
     */
    private String isVirtual;
    /**
     * 是否有货币资产
     */
    private String isCurrency;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private String createUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 更新人
     */
    private String updateUser;


}

