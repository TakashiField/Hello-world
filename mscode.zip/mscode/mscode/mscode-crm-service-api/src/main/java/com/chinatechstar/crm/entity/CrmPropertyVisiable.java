package com.chinatechstar.crm.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;

/**
 * 属性可见控制表(CrmPropertyVisiable)实体类
 *
 * @author zhengxl
 * @since 2024-08-08 10:33:43
 */
@Data
public class CrmPropertyVisiable implements Serializable {
    private static final long serialVersionUID = -84591843797122626L;
/**
     * ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;
/**
     * 属性名称
     */
    private String fieldName;

    private String fieldDesc;
/**
     * 属性类型（1-展示 2-查询条件）
     */
    private String fieldType;
/**
     * 是否可见（0-不可见 1-可见）
     */
    private String fieldVisiable;

    private Long mchtId;

    private Long[] ids;
}

