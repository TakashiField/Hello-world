package com.chinatechstar.crm.entity;

import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.Getter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;
import java.io.Serializable;

/**
 * 会员资料表(CrmMchtData)实体类
 *
 * @author makejava
 * @since 2024-06-19 16:57:40
 */
@Data
public class CrmMchtData implements Serializable {
    private static final long serialVersionUID = -28533180700873153L;
    /**
     * 资料ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    @NotNull(groups = { UpdateValidator.class})
    @Size(max = 32 ,min = 1, groups = { UpdateValidator.class })
    private Long dataId;
    /**
     * 商户ID
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 32 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private Long mchtId ;
    /**
     * 资料名称
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 50 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String dataName;
    /**
     * 资料内容
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 1024 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String dataContent;
    /**
     * 上传位置
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 256 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String dataPosition;
    /**
     * 上传端口
     */
    private Integer dataPort;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private String createUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 更新人
     */
    private String updateUser;
    /**
     * 资料状态
     */
    private String dataStatus;



}

