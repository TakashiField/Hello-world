package com.chinatechstar.crm.entity;

import lombok.Getter;

import java.util.Date;
import java.io.Serializable;

/**
 * 消费会员列表(CrmUserVip)实体类
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:01
 */
@Getter
public class CrmUserVip implements Serializable {
    private static final long serialVersionUID = -25935085341892282L;
    /**
     * 用户ID
     */
    private Long userId;
    /**
     * 姓名
     */
    private String name;
    /**
     * 手机号码
     */
    private String mobile;
    /**
     * 注册时间
     */
    private Date createTime;
    /**
     * 下级总人数
     */
    private String relatedUserSum;
    /**
     * 累计消费金额
     */
    private String consumeAmtSum;
    /**
     * 累计消费次数
     */
    private String consumeCount;
    /**
     * 等级
     */
    private String grade;
    /**
     * 来源渠道
     */
    private String srcChannel;
    /**
     * 商户ID
     */
    private Long mchtId ;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 认证状态
     */
    private String idtStatus;


    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public void setRelatedUserSum(String relatedUserSum) {
        this.relatedUserSum = relatedUserSum;
    }

    public void setConsumeAmtSum(String consumeAmtSum) {
        this.consumeAmtSum = consumeAmtSum;
    }

    public void setConsumeCount(String consumeCount) {
        this.consumeCount = consumeCount;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public void setSrcChannel(String srcChannel) {
        this.srcChannel = srcChannel;
    }

    public void setMchtId(Long mchtId ) {
        this.mchtId = mchtId;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public void setIdtStatus(String idtStatus) {
        this.idtStatus = idtStatus;
    }

}

