package com.chinatechstar.crm.vo;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-06-25 10-22
 * @Description: TODO
 * @Version: 1.0
 */
@Data
public class CrmMchtDataVO extends CrmBaseVO {

    private String dataName;

    private String dataStatus;

    private Long dataId;

}
