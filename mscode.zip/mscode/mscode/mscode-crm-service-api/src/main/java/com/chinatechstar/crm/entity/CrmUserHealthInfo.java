package com.chinatechstar.crm.entity;

import lombok.Getter;

import java.util.Date;
import java.io.Serializable;

/**
 * 会员健康信息表(CrmUserHealthInfo)实体类
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:00
 */
@Getter
public class CrmUserHealthInfo implements Serializable {
    private static final long serialVersionUID = 803265782288642474L;
    /**
     * ID
     */
    private Integer id;
    /**
     * 用户ID
     */
    private Long userId;
    /**
     * 商户ID
     */
    private Long mchtId ;
    /**
     * 血型
     */
    private String bloodType;
    /**
     * 医疗费用支付方式
     */
    private String feePayType;
    /**
     * 过敏史
     */
    private String allergy;
    /**
     * 慢性疾病
     */
    private String chronicDisease;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private String createUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 更新人
     */
    private String updateUser;


    public void setId(Integer id) {
        this.id = id;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setMchtId(Long mchtId ) {
        this.mchtId = mchtId;
    }

    public void setBloodType(String bloodType) {
        this.bloodType = bloodType;
    }

    public void setFeePayType(String feePayType) {
        this.feePayType = feePayType;
    }

    public void setAllergy(String allergy) {
        this.allergy = allergy;
    }

    public void setChronicDisease(String chronicDisease) {
        this.chronicDisease = chronicDisease;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

}

