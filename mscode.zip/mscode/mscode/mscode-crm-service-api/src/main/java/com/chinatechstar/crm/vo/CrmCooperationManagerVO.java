package com.chinatechstar.crm.vo;

import lombok.Getter;
import lombok.Setter;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-01 10-41
 * @Description: TODO
 * @Version: 1.0
 */
@Getter
@Setter
public class CrmCooperationManagerVO extends CrmBaseVO{
    //姓名
    private String name;
    //手机号
    private String mobile;
    //状态 0-待审核 1-审核中 2-已审核
    private String checkstatus;
    //合作类型：1-经销商2-供应商3-消费商
    private String coopType;
}
