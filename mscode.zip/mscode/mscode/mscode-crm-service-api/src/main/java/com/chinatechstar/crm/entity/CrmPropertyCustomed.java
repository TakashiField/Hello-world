package com.chinatechstar.crm.entity;

import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;
import java.io.Serializable;

/**
 * 自定义标签表(CrmPropertyCustomed)实体类
 *
 * @author makejava
 * @since 2024-06-24 17:20:22
 */
@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CrmPropertyCustomed extends CrmOperEntity implements Serializable {
    private static final long serialVersionUID = 258930768933953258L;

    @NotNull(groups = { UpdateValidator.class })
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;
    /**
     * 属性分类
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 1 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String propType;
    /**
     * 属性名称
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 60 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String propName;
    /**
     * 数据类型
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 20 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String dataType;
    /**
     * 数据集
     */
    private String dataCollection;
    /**
     * 是否必填
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 1 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String isNull;
    /**
     * 排序
     */
    private String orderId;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private String createUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 更新人
     */
    private String updateUser;
    /**
     * 商户ID
     */
    @NotNull(groups = { InsertValidator.class})
    private Long mchtId ;





    @Override
    public String toString() {
        return "CrmPropertyCustomed{" +
                "id='" + id + '\'' +
                ", propType='" + propType + '\'' +
                ", propName='" + propName + '\'' +
                ", dataType='" + dataType + '\'' +
                ", dataCollection='" + dataCollection + '\'' +
                ", isNull='" + isNull + '\'' +
                ", orderId='" + orderId + '\'' +
                ", createTime=" + createTime +
                ", createUser='" + createUser + '\'' +
                ", updateTime=" + updateTime +
                ", updateUser='" + updateUser + '\'' +
                ", mchtId='" + mchtId + '\'' +
                '}';
    }
}

