package com.chinatechstar.crm.vo;

import lombok.Getter;
import lombok.Setter;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-08 09-41
 * @Description: TODO
 * @Version: 1.0
 */
@Getter
@Setter
public class CrmUserJxsVO extends CrmBaseVO{

    //账号
    private Long userId;
    //手机号
    private String mobile;
    //来源渠道
    private String srcChannel;
}
