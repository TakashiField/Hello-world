//package com.chinatechstar.crm.client;
//
//import com.chinatechstar.component.commons.result.ListResult;
//import com.chinatechstar.crm.entity.CrmUser;
//import com.chinatechstar.crm.vo.CrmUserVO;
//import org.springframework.stereotype.Component;
//import org.springframework.validation.annotation.Validated;
//import org.springframework.web.bind.annotation.RequestBody;
//
//import java.util.Collections;
//import java.util.LinkedHashMap;
//import java.util.List;
//
///**
// * 提供给其他微服务调用的字典微服务接口的熔断降级类
// *
// * @版权所有 东软集团
// */
//@Component
//public class CrmUserServiceClientFallback implements CrmUserServiceClient {
//
//
//	/**
//	 * 分页查询
//	 * @param vo
//	 * @return
//	 */
//	@Override
//	public List<CrmUser> queryByPage(CrmUserVO vo) {
//		return Collections.emptyList();
//	}
//
//	/**
//	 * 信息同步
//	 * @param crmUser
//	 * @return
//	 */
//	@Override
//	public CrmUserVO sync(CrmUserVO crmUser) {
//		return null;
//	}
//}
