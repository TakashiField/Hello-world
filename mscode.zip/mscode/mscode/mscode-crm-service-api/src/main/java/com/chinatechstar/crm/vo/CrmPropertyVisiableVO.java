package com.chinatechstar.crm.vo;

import lombok.Data;

@Data
public class CrmPropertyVisiableVO extends CrmBaseVO {
    private Long id;

    private String fieldName;

    private String fieldType;

    private String fieldVisiable;

    private static final long serialVersionUID = 1L;





    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", fieldName=").append(fieldName);
        sb.append(", fieldType=").append(fieldType);
        sb.append(", fieldVisiable=").append(fieldVisiable);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}