package com.chinatechstar.crm.entity;

import lombok.Getter;

import java.util.Date;
import java.io.Serializable;

/**
 * 用户关系管理(CrmUserRelation)实体类
 *
 * @author zhengxl
 * @since 2024-07-19 14:49:54
 */
@Getter
public class CrmUserRelation implements Serializable {
    private static final long serialVersionUID = 163688410734763543L;

    private Long id;

    private Long userId;

    private String name;

    private String mobile;

    private Long userIdRelated;

    private String nameRelated;

    private String mobileRelated;

    private String srcChannel;

    private Long relationNameId;

    private String relationName;

    private String relationData;
    /**
     * 类型：business 商业
     */
    private String type;
    /**
     * 商户ID
     */
    private Long mchtId;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private String createUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 更新人
     */
    private String updateUser;


    public void setId(Long id) {
        this.id = id;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setUserIdRelated(Long userIdRelated) {
        this.userIdRelated = userIdRelated;
    }

    public void setNameRelated(String nameRelated) {
        this.nameRelated = nameRelated;
    }

    public void setMobileRelated(String mobileRelated) {
        this.mobileRelated = mobileRelated;
    }

    public void setSrcChannel(String srcChannel) {
        this.srcChannel = srcChannel;
    }

    public void setRelationNameId(Long relationNameId) {
        this.relationNameId = relationNameId;
    }

    public void setRelationName(String relationName) {
        this.relationName = relationName;
    }

    public void setRelationData(String relationData) {
        this.relationData = relationData;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setMchtId(Long mchtId) {
        this.mchtId = mchtId;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

}

