package com.chinatechstar.crm.vo;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-03 14-44
 * @Description: TODO
 * @Version: 1.0
 */
@Setter
@Getter
public class CrmRulesVO extends CrmBaseVO{

    @NotBlank(message = "规则类型不能为空")
    private String ruleType;
    @NotBlank(message = "等级ID不能为空")
    private String gradeId;
    //0 查询该规则ID关联的所有规则  1 查询没有跟该规则ID关联的所以规则
//    @NotBlank(message = "查询类型不能为空")
//    private String selectType;
}
