package com.chinatechstar.crm.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.Getter;

import java.io.Serializable;

/**
 * 会员升级规则(CrmRulesUp)实体类
 *
 * @author zhengxl
 * @since 2024-07-03 12:43:03
 */
@Data
public class CrmRulesUp extends CrmOperEntity implements Serializable {
    private static final long serialVersionUID = 350152496148262182L;
    /**
     * 规则ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long ruleId;
    /**
     * 规则名称
     */
    private String ruleName;
    /**
     * 规则描述
     */
    private String ruleDesc;
    /**
     * 规则条件
     */
    private String ruleParam;
    /**
     * 规则值
     */
    private String ruleValue;
    /**
     * 规则值单位
     */
    private String ruleValueUnit;
    /**
     * 奖励
     */
    private String ruleBonus;
    /**
     * 奖励单位
     */
    private String ruleBonusUnit;
    /**
     * 次数
     */
    private String ruleTimes;
    /**
     * 次数单位
     */
    private String ruleTimesUnit;
    /**
     * 任务有效期
     */
    private String ruleExpire;
    /**
     * 任务有效期单位
     */
    private String ruleExpireUnit;
    /**
     * 规则类型
     */
    private String ruleType;
    /**
     * 规则状态
     */
    private String ruleStatus;
    /**
     * 商户ID
     */
    private Long mchtId ;




}

