package com.chinatechstar.crm.vo;

import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-28 18-18
 * @Description: TODO
 * @Version: 1.0
 */
@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CrmUserInfoWorkVO extends CrmBaseVO{

    /**
     * 工作类型
     */

    private String workType;
    /**
     * 职业类型
     */

    private String employType;
    /**
     * 单位名称
     */

    private String companyName;
    /**
     * 单位性质
     */

    private String companyProp;
    /**
     * 单位地址
     */
    private String companyAddress;

    private String companyPost;
    /**
     * 行业
     */
    private String industry;
    /**
     * 部门
     */
    private String department;
    /**
     * 职位级别
     */
    private String level;
    /**
     * 入职时间
     */
    private Date entryTime;
    /**
     * 工资发放形势
     */
    private String payType;
    /**
     * 单位电话
     */
    private String companyPhone;
    /**
     * 月均薪资
     */
    private Double salaryAvg;
    /**
     * 其他收入
     */
    private Double salaryOther;
    /**
     * 每月发薪日
     */
    private Integer payDay;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private String createUser;

}
