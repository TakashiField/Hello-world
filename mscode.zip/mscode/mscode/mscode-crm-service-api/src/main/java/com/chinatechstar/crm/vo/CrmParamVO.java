package com.chinatechstar.crm.vo;

import lombok.Data;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-18 16-51
 * @Description: TODO
 * @Version: 1.0
 */
@Data
public class CrmParamVO extends CrmBaseVO{

    private Long id;

    private String paramCode;

    private String paramValue;

    private String parentCode;
}
