package com.chinatechstar.crm.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.Getter;

import java.util.Date;
import java.io.Serializable;

/**
 * 会员关系管理表(CrmRelationManager)实体类
 *
 * @author zhengxl
 * @since 2024-07-18 10:55:05
 */
@Data
public class CrmRelationManager extends CrmOperEntity implements Serializable {
    private static final long serialVersionUID = -50066380509879575L;
/**
     * 关系ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;
/**
     * 用户ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long userId;
/**
     * 姓名
     */
    private String name;
/**
     * 手机号
     */
    private String mobile;
/**
     * 关系人ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long userIdRelated;
/**
     * 关系人姓名
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private String nameRelated;
/**
     * 关系人手机号
     */
    private String mobileRelated;
/**
     * 来源渠道
     */
    private String srcChannel;
/**
     * 状态
     */
    private String status;
/**
     * 关系名称ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long relationNameId;
/**
     * 关系名称
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long relationTypeId;
/**
     * 关系性质
     */
    private String relationName;
/**
     * 关系资料
     */
    private String relationData;
/**
     * 创建时间
     */
    private Date createTime;
/**
     * 创建人
     */
    private String createUser;
/**
     * 更新时间
     */
    private Date updateTime;
/**
     * 更新人
     */
    private String updateUser;
/**
     * 商户ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long mchtId;
    // 关系类别
    private String relationType;
    // 关系人证件类型
    private String idTypeRelated;
    // 关系人证件号码
    private String idNoRelated;
    // 关系资料数组
    private String[] relationDataArr;
    // 本人证件类型
    private String idType;
    // 本人证件号码
    private String idNo;
    //  类别
    private String type;
    // 关系性质
    private String relationProperty;
}

