package com.chinatechstar.crm.entity;

import lombok.Data;
import lombok.Getter;

import java.io.Serializable;

/**
 * 性别参数表(CrmParamSex)实体类
 *
 * @author zhengxl
 * @since 2024-12-17 11:09:30
 */
@Data
public class CrmParamSex implements Serializable {
    private static final long serialVersionUID = 648031622820872604L;
    /**
     * 性别名称
     */
    private String sex;
    /**
     * ID
     */
    private Long id;
    /**
     * 图标
     */
    private String img;
    /**
     * 来源渠道
     */
    private String srcChannel;
    /**
     * 商户ID
     */
    private Long mchtId;
    /**
     * 状态
     */
    private String status;


    public void setSex(String sex) {
        this.sex = sex;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public void setSrcChannel(String srcChannel) {
        this.srcChannel = srcChannel;
    }

    public void setMchtId(Long mchtId) {
        this.mchtId = mchtId;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}

