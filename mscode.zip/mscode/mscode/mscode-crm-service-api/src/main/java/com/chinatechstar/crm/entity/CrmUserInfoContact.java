package com.chinatechstar.crm.entity;

import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;
import java.io.Serializable;

/**
 * 会员联系人信息表(CrmUserInfoContact)实体类
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:02
 */
@Getter
public class CrmUserInfoContact extends CrmOperEntity implements Serializable {
    private static final long serialVersionUID = 302389215387138685L;
    /**
     * id
     */
    @NotNull(groups = { UpdateValidator.class})
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;
    /**
     * 用户ID
     */
    @NotNull(groups = { InsertValidator.class })
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long userId;
    /**
     * 商户ID
     */
    @NotNull(groups = { InsertValidator.class})
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long mchtId;
    /**
     * 工作类型
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 1 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String contactType;
    /**
     * 姓名
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 60 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String name;
    /**
     * 职业类型
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 1 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String relationType;
    /**
     * 电话
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 20 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String mobile;
    /**
     * 住宅电话
     */
    private String phone;
    /**
     * 年龄
     */
    private Integer age;
    /**
     * 证件类型
     */
    private String idType;
    /**
     * 证件号码
     */
    private String idNo;
    /**
     * 单位名称
     */
    private String companyName;
    /**
     * 单位电话
     */
    private String companyPhone;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 创建人
     */
    private String createUser;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 更新人
     */
    private String updateUser;


    public void setId(Long id) {
        this.id = id;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setMchtId(Long mchtId) {
        this.mchtId = mchtId;
    }

    public void setContactType(String contactType) {
        this.contactType = contactType;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRelationType(String relationType) {
        this.relationType = relationType;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public void setIdNo(String idNo) {
        this.idNo = idNo;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public void setCompanyPhone(String companyPhone) {
        this.companyPhone = companyPhone;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

}

