package com.chinatechstar.crm.vo;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-15 15-25
 * @Description: TODO
 * @Version: 1.0
 */
public class CrmTaskNoticeVO extends CrmBaseVO{
}
