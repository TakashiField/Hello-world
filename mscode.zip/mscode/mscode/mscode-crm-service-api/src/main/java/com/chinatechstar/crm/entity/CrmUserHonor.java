package com.chinatechstar.crm.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;

import java.util.Date;
import java.io.Serializable;

/**
 * 会员荣誉列表(CrmUserHonor)实体类
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:01
 */
@Getter
public class CrmUserHonor implements Serializable {
    private static final long serialVersionUID = 964164715954687297L;
    /**
     * 用户ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long userId;
    /**
     * 姓名
     */
    private String name;
    /**
     * 手机号码
     */
    private String mobile;
    /**
     * 注册时间
     */
    private Date createTime;
    /**
     * 下级总人数
     */
    private String relatedUserSum;
    /**
     * 累计消费金额
     */
    private String consumeAmtSum;
    /**
     * 等级
     */
    private String grade;
    /**
     * 来源渠道
     */
    private String srcChannel;
    /**
     * 商户ID
     */
    private Long mchtId ;
    /**
     * 更新时间
     */
    private Date updateTime;


    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public void setRelatedUserSum(String relatedUserSum) {
        this.relatedUserSum = relatedUserSum;
    }

    public void setConsumeAmtSum(String consumeAmtSum) {
        this.consumeAmtSum = consumeAmtSum;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public void setSrcChannel(String srcChannel) {
        this.srcChannel = srcChannel;
    }

    public void setMchtId(Long mchtId ) {
        this.mchtId = mchtId;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

}

