package com.chinatechstar.crm.vo;

import com.chinatechstar.crm.entity.CrmRulesDown;
import com.chinatechstar.crm.entity.CrmRulesUp;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-02 11-05
 * @Description: TODO
 * @Version: 1.0
 */
@Getter
@Setter
public class CrmGradeTemplateDetailVO extends CrmBaseVO{

    /**
     * 等级
     */
    private String grade;
    /**
     * 等级名称
     */
    private String gradeName;
    /**
     * 等级图标
     */
    private String gradeImage;

    /**
     * 升级规则状态（0-关闭 1-开启 默认开启状态）
     */
    private String rulesUpState;
    /**
     * 降级规则状态（0-关闭 1-开启 默认关闭）
     */
    private String rulesDownState;

    private Long templateId;

    private String templateType;
}
