package com.chinatechstar.crm.vo;

import lombok.Data;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2025-02-08 14-27
 * @Description: TODO
 * @Version: 1.0
 */
@Data
public class CrmPersonInfo {

    private String name;

    private String idType;

    private String idNo;

    private String mobile;
}
