package com.chinatechstar.crm.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.Getter;

import java.io.Serializable;

/**
 * 会员权益规则表(CrmRulesEquity)实体类
 *
 * @author zhengxl
 * @since 2024-07-03 12:42:05
 */
@Data
public class CrmRulesEquity extends CrmOperEntity implements Serializable {
    private static final long serialVersionUID = 681471386812172515L;
    /**
     * 规则ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long ruleId;
    /**
     * 权益模块
     */
    private String benefitModule;
    /**
     * 权益名称
     */
    private String benefitName;
    /**
     * 权益内容
     */
    private String benefitContent;
    /**
     * 权益值
     */
    private String benefitValue;
    /**
     * 规则类型
     */
    private String ruleType;
    /**
     * 规则状态
     */
    private String ruleStatus;
    /**
     * 商户ID
     */
    private Long mchtId ;

}

