package com.chinatechstar.crm.vo;

import com.chinatechstar.crm.entity.*;
import lombok.Data;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-30 15-15
 * @Description: TODO
 * @Version: 1.0
 */
@Data
public class CrmCenterVO extends CrmBaseVO{
    //用户ID
    private Long userId;

    private CrmUser crmUser;

    private CrmUserVip crmUserVip;

    private CrmUserHonor crmUserHonor;

    private CrmUserGys crmUserGys;

    private CrmUserJxs crmUserJxs;

    private CrmParamSex crmParamSex;
}
