package com.chinatechstar.crm.vo;

import lombok.Data;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-12-18 15-32
 * @Description: TODO
 * @Version: 1.0
 */
@Data
public class CrmParamSexVO extends CrmBaseVO{

    /**
     * 性别名称
     */
    private String sex;
    /**
     * ID
     */
    private Long id;
    /**
     * 图标
     */
    private String img;
    /**
     * 来源渠道
     */
    private String srcChannel;
    /**
     * 状态
     */
    private String status;
}
