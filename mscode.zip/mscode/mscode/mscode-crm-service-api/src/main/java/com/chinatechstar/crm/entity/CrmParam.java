package com.chinatechstar.crm.entity;

import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.Getter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;
import java.io.Serializable;

/**
 * 选项参数表(CrmParam)实体类
 *
 * @author zhengxl
 * @since 2024-07-18 16:49:16
 */
@Data
public class CrmParam implements Serializable {
    private static final long serialVersionUID = -74103592628092488L;
    /**
     * ID
     */
    @NotNull(groups = { UpdateValidator.class })
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;
    /**
     * 商户ID
     */
    @NotNull(groups = { InsertValidator.class })
    private Long mchtId;
    /**
     * 组别
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 20 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String paramCode;
    /**
     * 名称
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 60 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String paramValue;
    /**
     * 父组别
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 20 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String parentCode;
    /**
     * 备注
     */
    private String remark;
    /**
     * 状态
     */
    private String status;
    /**
     * 创建人
     */
    private String createUser;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 更新人
     */
    private String updateUser;
    /**
     * 更新时间
     */
    private Date updateTime;


}

