package com.chinatechstar.crm.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.entity
 * @Author: zhengxiaolei
 * @CreateTime: 2024-08-07 16-39
 * @Description: TODO
 * @Version: 1.0
 */
@Data
public class CrmOperEntity {

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long operatorId;

    private String operatorName;
}
