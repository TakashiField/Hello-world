package com.chinatechstar.crm.vo;

import com.chinatechstar.crm.entity.CrmGradeTemplateDetail;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.NotBlank;

import java.util.List;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-02 10-12
 * @Description: TODO
 * @Version: 1.0
 */
@Setter
@Getter
public class CrmGradeTemplateVO extends CrmBaseVO{

    /**
     * 模板名称
     */
    private String templateName;

    /**
     * 模板类型（1-经销商2-供应商3-消费商4-荣誉）
     */
    @NotBlank(message = "模板类型不能为空")
    private String templateType;


    List<CrmGradeTemplateDetailVO> list;

}
