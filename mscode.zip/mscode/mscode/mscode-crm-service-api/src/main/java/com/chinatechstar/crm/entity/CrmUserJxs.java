package com.chinatechstar.crm.entity;

import lombok.Getter;

import java.util.Date;
import java.io.Serializable;

/**
 * 经销商列表(CrmUserJxs)实体类
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:01
 */
@Getter
public class CrmUserJxs implements Serializable {
    private static final long serialVersionUID = 733684613267993352L;
    /**
     * 用户ID
     */
    private Long userId;
    /**
     * 姓名
     */
    private String name;
    /**
     * 性别
     */
    private String sex;
    /**
     * 手机号码
     */
    private String mobile;
    /**
     * 注册时间
     */
    private Date createTime;
    /**
     * 累计销售金额
     */
    private String sellAmtSum;
    /**
     * 累计采购金额
     */
    private String buyAmtSum;
    /**
     * 等级
     */
    private String grade;
    /**
     * 来源渠道
     */
    private String srcChannel;
    /**
     * 商户ID
     */
    private Long mchtId ;
    /**
     * 更新时间
     */
    private Date updateTime;


    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public void setSellAmtSum(String sellAmtSum) {
        this.sellAmtSum = sellAmtSum;
    }

    public void setBuyAmtSum(String buyAmtSum) {
        this.buyAmtSum = buyAmtSum;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public void setSrcChannel(String srcChannel) {
        this.srcChannel = srcChannel;
    }

    public void setMchtId(Long mchtId ) {
        this.mchtId = mchtId;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

}

