package com.chinatechstar.crm.vo;

import lombok.Getter;
import lombok.Setter;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-06-27 14-23
 * @Description: TODO
 * @Version: 1.0
 */
@Getter
@Setter
public class CrmRelationNameVO extends CrmBaseVO{

    private Long id;

    private String relationName;

    private String status;

    private String relationType;

    private String relationProperty;
}
