package com.chinatechstar.crm.entity;

import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.Getter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;
import java.io.Serializable;

/**
 * 会员关系类别表(CrmRelationType)实体类
 *
 * @author makejava
 * @since 2024-06-26 09:59:20
 */
@Data
public class CrmRelationType extends CrmOperEntity implements Serializable {
    private static final long serialVersionUID = -68883820725355779L;

    @NotNull(groups = { UpdateValidator.class})
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;
    /**
     * 关系类别
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 45 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String relationType;
    /**
     * 序号
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 4 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String orderNo;
    /**
     * 状态
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 2 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private String status;

    private Date createTime;
    /**
     * 创建人
     */
    private String createUser;

    private Date updateTime;
    /**
     * 更新人
     */
    private String updateUser;
    /**
     * 商户ID
     */
    @NotNull(groups = { InsertValidator.class, UpdateValidator.class})
    @Size(max = 32 ,min = 1, groups = { InsertValidator.class, UpdateValidator.class })
    private Long mchtId ;




}

