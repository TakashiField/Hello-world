package com.chinatechstar.admin.controller;

import java.util.*;

import javax.servlet.http.HttpServletResponse;

import com.chinatechstar.component.commons.utils.PDFUtils;
import com.chinatechstar.component.commons.utils.WordUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.chinatechstar.admin.entity.SysRegion;
import com.chinatechstar.admin.service.SysRegionService;
import com.chinatechstar.admin.vo.SysRegionVO;
import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.component.commons.utils.ExcelUtils;
import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;
import org.springframework.web.multipart.MultipartFile;

/**
 * 区域信息的控制层
 * 
 * @版权所有 东软集团
 */
@Api(tags = { "区域信息" })
@RestController
@RequestMapping("/sysregion")
public class SysRegionController {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private SysRegionService sysRegionService;

	/**
	 * 查询区域分页
	 * 
	 * @param sysRegionVO 区域前端参数
	 * @return
	 */
	@ApiOperation(value = "查询区域分页")
	@GetMapping(path = "/querySysRegion")
	public ListResult<Object> querySysRegion(SysRegionVO sysRegionVO) {
		Map<String, Object> data = sysRegionService.querySysRegion(sysRegionVO.getCurrentPage(), sysRegionVO.getPageSize(), sysRegionVO.getRegionName(),
				sysRegionVO.getRegionCode(), sysRegionVO.getRegionType());
		return ResultBuilder.buildListSuccess(data);
	}

	/**
	 * 查询区域的树数据
	 * 
	 * @return
	 */
	@ApiOperation(value = "查询区域的树数据")
	@GetMapping(path = "/querySysRegionTree")
	public ListResult<Object> querySysRegionTree() {
		LinkedHashMap<String, Object> data = sysRegionService.querySysRegionTree();
		return ResultBuilder.buildListSuccess(data);
	}

	@ApiOperation(value = "查询所有区域的树数据")
	@GetMapping(path = "/querySysRegionTreeAll")
	public ListResult<Object> querySysRegionTreeAll(){
		logger.info("进入getMenuInfo方法+++++++++++++++++++++++");
		List<Map<String, Object>> result = new ArrayList<>();// 定义一个map处理json键名问题

		List<SysRegion> first = sysRegionService.selectProvinceAll();// 查找所有一级省信息

		//省市区数据量太多页面渲染很慢,先暂时显示北京、广东、广西、江西
//		List<SysRegion> first2 = new ArrayList<SysRegion>();
//		for (int i = 0; i < first.size(); i++) {
//			Area_code area_code = first.get(i);
//			long id = area_code.getId();
//			if(id == 110000 || id == 440000 || id == 450000 || id == 360000) {
//				first2.add(area_code);
//			}
//		}
		return ResultBuilder.buildListSuccess(treeload(first, result,1));
	}

	/**
	 * 	对菜单树数据进行处理
	 * @param first 一级菜单
	 * @param result 遍历结果菜单
	 * @param i 当前菜单级数（只能从1开始）
	 * @return
	 */
	private List<Map<String, Object>> treeload(List<SysRegion> first, List<Map<String, Object>> result,int i) {
		i++;
		for (SysRegion d : first) {
			HashMap<String, Object> map = new HashMap<>();
			map.put("id", d.getId());
			map.put("title", d.getRegionName());
			map.put("spread", false);      //设置是否展开
			List<Map<String, Object>> result1 = new ArrayList<Map<String, Object>>();
			List<SysRegion> children = new ArrayList<>();
			if(i==2){
//				children = us.getAreaList(d.getId()); // 获取2级菜单
				children = sysRegionService.selectSysRegion(d.getRegionCode());
				i=2;
			}else if(i==3){
//				children = us.getAreaList(d.getId()); // 获取3级数据
				children = sysRegionService.selectSysRegion(d.getRegionCode());
				i=3;
			}
			map.put("children", treeload(children, result1,i));
			result.add(map);
		}
		return result;
	}

	/**
	 * 查询区域类型的下拉框数据
	 * 
	 * @return
	 */
	@ApiOperation(value = "查询区域类型的下拉框数据")
	@GetMapping(path = "/queryRegionType")
	public ListResult<Object> queryRegionType() {
		LinkedHashMap<String, Object> data = sysRegionService.queryRegionType();
		return ResultBuilder.buildListSuccess(data);
	}

	/**
	 * 查询全部省份数据
	 * 
	 * @return
	 */
	@ApiOperation(value = "查询全部省份数据")
	@GetMapping(path = "/queryProvince")
	public ListResult<Object> queryProvince() {
		LinkedHashMap<String, Object> data = sysRegionService.queryProvince();
		return ResultBuilder.buildListSuccess(data);
	}

	/**
	 * 根据省份代码查询对应地市数据
	 * 
	 * @return
	 */
	@ApiOperation(value = "根据省份代码查询对应地市数据")
	@GetMapping(path = "/queryCity/{province}")
	public ListResult<Object> queryCity(@PathVariable String province) {
		LinkedHashMap<String, Object> data = sysRegionService.queryCity(province);
		return ResultBuilder.buildListSuccess(data);
	}

	/**
	 * 新增区域
	 * 
	 * @param sysRegion 区域对象
	 * @return
	 */
	@ApiOperation(value = "新增区域")
	@PostMapping(path = "/addSysRegion")
	public ActionResult addSysRegion(@Validated(InsertValidator.class) @RequestBody SysRegion sysRegion) {
		sysRegionService.insertSysRegion(sysRegion);
		return ResultBuilder.buildActionSuccess();
	}

	/**
	 * 编辑区域
	 * 
	 * @param sysRegion 区域对象
	 * @return
	 */
	@ApiOperation(value = "编辑区域")
	@PutMapping(path = "/updateSysRegion")
	public ActionResult updateSysRegion(@Validated(UpdateValidator.class) @RequestBody SysRegion sysRegion) {
		sysRegionService.updateSysRegion(sysRegion);
		return ResultBuilder.buildActionSuccess();
	}

	/**
	 * 删除区域
	 * 
	 * @param regionCode 区域代码
	 * @return
	 */
	@ApiOperation(value = "删除区域")
	@PostMapping(path = "/deleteSysRegion")
	public ActionResult deleteSysRegion(@RequestParam(name = "regionCode", required = true) String[] regionCode) {
		sysRegionService.deleteSysRegion(regionCode);
		return ResultBuilder.buildActionSuccess();
	}

	/**
	 * 根据查询条件导出区域到Excel
	 *
	 * @param response 响应对象
	 * @param paramMap 参数Map
	 */
	@ApiOperation(value = "根据查询条件导出区域到Excel")
	@PostMapping(path = "/exportSysRegion")
	public void exportSysRegion(HttpServletResponse response, @RequestParam Map<String, Object> paramMap) {
		try {
			if (paramMap.get("isTemplate").equals("1")) { // 1为模板，0不为模板
				List<String> headList = Arrays.asList("区域名称", "区域代码", "区域类型", "上级区域代码");
				ExcelUtils.exportExcel(headList, null, "区域管理", response);
			} else {
				List<String> headList = Arrays.asList("ID", "区域名称", "区域代码", "区域类型", "区域类型名称", "上级区域代码", "上级区域ID", "创建时间");
				List<LinkedHashMap<String, Object>> dataList = sysRegionService.querySysRegionForExcel(paramMap);
				ExcelUtils.exportExcel(headList, dataList, "区域管理", response);
			}
		} catch (Exception e) {
			logger.warn(e.toString());
		}
	}

	/**
	 * 导入区域
	 *
	 * @param file 文件资源
	 * @return
	 */
	@ApiOperation(value = "导入区域")
	@PostMapping(value = "/importSysRegion", consumes = {"multipart/form-data"})
	public ActionResult importSysRegion(@RequestParam(name = "file", required = true) MultipartFile file) {
		sysRegionService.importSysRegion(file);
		return ResultBuilder.buildActionSuccess();
	}

	/**
	 * 根据查询条件导出区域到Word
	 *
	 * @param response 响应对象
	 * @param paramMap 参数Map
	 */
	@ApiOperation(value = "根据查询条件导出区域到Word")
	@PostMapping(path = "/exportWordSysRegion")
	public void exportWordSysRegion(HttpServletResponse response, @RequestParam Map<String, Object> paramMap) {
		exportCommonSysRegion(response, paramMap, "Word");
	}

	/**
	 * 根据查询条件导出区域到PDF
	 *
	 * @param response 响应对象
	 * @param paramMap 参数Map
	 */
	@ApiOperation(value = "根据查询条件导出区域到PDF")
	@PostMapping(path = "/exportPDFSysRegion")
	public void exportPDFSysRegion(HttpServletResponse response, @RequestParam Map<String, Object> paramMap) {
		exportCommonSysRegion(response, paramMap, "PDF");
	}

	/**
	 * 根据查询条件导出区域到Word或PDF
	 *
	 * @param response 响应对象
	 * @param paramMap 参数Map
	 * @param flag     Word或PDF
	 */
	private void exportCommonSysRegion(HttpServletResponse response, @RequestParam Map<String, Object> paramMap, String flag) {
		try {
			List<String> headList = Arrays.asList("区域名称", "区域代码", "区域类型名称", "创建时间");
			List<LinkedHashMap<String, Object>> dataList = sysRegionService.querySysRegionForExcel(paramMap);
			dataList.forEach(map -> {
				map.entrySet().removeIf(entry -> ("id".equals(entry.getKey()) || "regionType".equals(entry.getKey()) || "parentRegionCode".equals(entry.getKey()) || "parentId".equals(entry.getKey())));
			});
			if (flag == "Word") {
				WordUtils.exportWord(headList, dataList, "区域管理", response);
			} else if (flag == "PDF") {
				PDFUtils.exportPDF(headList, dataList, "区域管理", response);
			}
		} catch (Exception e) {
			logger.warn(e.toString());
		}
	}


	@ApiOperation("查询所有的省列表")
	@GetMapping("/selectProvinceAll")
	public ListResult<Object> selectProvinceAll(){
		return ResultBuilder.buildListSuccess(sysRegionService.selectProvinceAll());
	}

	@ApiOperation("查询对应的省市下面所属市区")
	@GetMapping("/selectRegionBelow")
	public ListResult<Object> selectRegionBelow(String regionCode){
		return ResultBuilder.buildListSuccess(sysRegionService.selectSysRegion(regionCode));
	}

}
