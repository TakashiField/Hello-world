package com.chinatechstar.admin.service.impl;

import com.chinatechstar.admin.entity.FppTrade;
import com.chinatechstar.admin.mapper.FppTradeMapper;
import com.chinatechstar.admin.service.FppTradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author lixu
 */

@Service
public class FppTradeServiceImpl implements FppTradeService {
    @Autowired
    FppTradeMapper fppTradeMapper;

    @Override
    public List<FppTrade> selectTradeTop() {
        return fppTradeMapper.selectTradeTop();
    }

    @Override
    public List<FppTrade> selectTrade(String typeno) {
        return fppTradeMapper.selectTrade(typeno);
    }
}
