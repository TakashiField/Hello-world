package com.chinatechstar.admin.service;

import com.chinatechstar.admin.entity.FppTrade;

import java.util.List;

public interface FppTradeService {

    List<FppTrade> selectTradeTop();

    List<FppTrade> selectTrade(String typeno);
}
