package com.chinatechstar.admin.service.impl;

import java.util.*;
import java.util.Map.Entry;

import com.chinatechstar.admin.entity.*;
import com.chinatechstar.admin.mapper.*;
import com.chinatechstar.admin.service.SysTenantService;
import com.chinatechstar.cache.redis.constants.ApplicationConstants;
import com.chinatechstar.cache.redis.util.RedisUtils;
import com.chinatechstar.component.commons.utils.ExcelUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.chinatechstar.admin.service.SysOrgService;
import com.chinatechstar.admin.service.SysUserService;
import com.chinatechstar.component.commons.result.PaginationBuilder;
import com.chinatechstar.component.commons.utils.CollectionUtils;
import com.chinatechstar.component.commons.utils.CurrentUserUtils;
import com.chinatechstar.component.commons.utils.SequenceGenerator;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.web.multipart.MultipartFile;

/**
 * 用户信息的业务逻辑实现层
 * 
 * @版权所有 广东国星科技有限公司 www.mscodecloud.com
 */
@Service
@Transactional
public class SysUserServiceImpl implements SysUserService {

	private final Logger logger = LoggerFactory.getLogger(getClass());
	private static final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
	private static final SequenceGenerator sequenceGenerator = new SequenceGenerator();

	@Autowired
	private RedisUtils redisUtils;
	@Autowired
	private SysUserMapper sysUserMapper;
	@Autowired
	private SysRoleMapper sysRoleMapper;
	@Autowired
	private SysMenuMapper sysMenuMapper;
	@Autowired
	private SysPostMapper sysPostMapper;
	@Autowired
	private SysUrlMapper sysUrlMapper;
	@Autowired
	private SysOrgMapper sysOrgMapper;
	@Autowired
	private SysDictMapper sysDictMapper;
	@Autowired
	private SysUserPostMapper sysUserPostMapper;
	@Autowired
	private SysOrgService sysOrgService;
	@Autowired
	private SysTenantMapper sysTenantMapper;
	@Autowired
	private SessionRegistry sessionRegistry;

	/**
	 * 查询在线用户分页
	 */
	@Override
	public Map<String, Object> queryOnlineSysUser(Integer currentPage, Integer pageSize, String username, String nickname, String mobile, Long[] roleId,
			Long orgId, String sorter) {
		List<Object> principals = sessionRegistry.getAllPrincipals();
		if (principals.isEmpty()) {
			principals.add("admin");
		}

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("username", StringUtils.join(principals.toArray(), "|"));
		paramMap.put("nickname", nickname);
		paramMap.put("mobile", mobile);

		if (orgId != null) {
			Set<Long> orgIds = new HashSet<>();
			orgIds.add(orgId);
			sysOrgService.getRecursiveIds(orgId, orgIds);
			paramMap.put("orgIdArray", orgIds.stream().toArray(Long[]::new));
		}

		if (roleId != null && roleId.length > 0) {
			paramMap.put("roleId", roleId[0]);
		}

		paramMap.put("onlineusername", username);
		paramMap.put("tenantCode", CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode"));// 当前用户的租户编码
		if (StringUtils.isNotBlank(sorter)) {
			String sort = sorter.substring(0, sorter.lastIndexOf('_'));
			String sequence = "ascend".equals(sorter.substring(sorter.lastIndexOf('_') + 1)) ? "ASC" : "DESC";
			paramMap.put("sort", sort);
			paramMap.put("sequence", sequence);
		} else {
			paramMap.put("sort", "createTime");
			paramMap.put("sequence", "DESC");
		}
		Page<Object> page = PageHelper.startPage(currentPage, pageSize);
		List<LinkedHashMap<String, Object>> resultList = sysUserMapper.querySysUser(paramMap);

		String roleData = sysRoleMapper.queryRoleData("onlinesysuser", CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("name"), CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode"));
		String[] roleDataArray = roleData == null ? null : roleData.split(",");
		if (roleDataArray != null && roleDataArray.length > 0) {// 处理数据权限
			return PaginationBuilder.buildResult(CollectionUtils.convertFilterList(resultList, roleDataArray), page.getTotal(), currentPage, pageSize);
		} else {
			return PaginationBuilder.buildResult(resultList, page.getTotal(), currentPage, pageSize);
		}
	}

	/**
	 * 查询用户分页
	 */
	@Override
	public Map<String, Object> querySysUser(Integer currentPage, Integer pageSize, String username, String status, Long orgId, Long[] roleId, String nickname,
			String mobile, String tenantCode, String sorter) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("username", username);
		paramMap.put("nickname", nickname);
		paramMap.put("mobile", mobile);

		if (orgId != null) {
			Set<Long> orgIds = new HashSet<>();
			orgIds.add(orgId);
			sysOrgService.getRecursiveIds(orgId, orgIds);
			paramMap.put("orgIdArray", orgIds.stream().toArray(Long[]::new));
		}

		if (roleId != null && roleId.length > 0) {
			paramMap.put("roleId", roleId[0]);
		}

		if (StringUtils.isNotBlank(tenantCode) && !tenantCode.contains("notContain")) {
			paramMap.put("tenantCode", tenantCode);// 租户编码参数
		} else if (StringUtils.isNotBlank(tenantCode) && tenantCode.contains("notContain")) {
			paramMap.put("notContainTenantCode", tenantCode.replace("notContain", ""));// 不包含的租户编码
		} else {
			paramMap.put("tenantCode", CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode"));// 当前用户的租户编码
		}
		if (StringUtils.isNotBlank(status)) {
			String[] statusArray = status.split(",");
			paramMap.put("statusList", ConvertUtils.convert(statusArray, Short.class));
		}
		if (StringUtils.isNotBlank(sorter)) {
			String sort = sorter.substring(0, sorter.lastIndexOf('_'));
			String sequence = "ascend".equals(sorter.substring(sorter.lastIndexOf('_') + 1)) ? "ASC" : "DESC";
			paramMap.put("sort", sort);
			paramMap.put("sequence", sequence);
		} else {
			paramMap.put("sort", "createTime");
			paramMap.put("sequence", "DESC");
		}
		Page<Object> page = PageHelper.startPage(currentPage, pageSize);
		List<LinkedHashMap<String, Object>> resultList = sysUserMapper.querySysUser(paramMap);

		String roleData = sysRoleMapper.queryRoleData("sysuser", CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("name"), CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode"));
		String[] roleDataArray = roleData == null ? null : roleData.split(",");
		if (roleDataArray != null && roleDataArray.length > 0) {// 处理数据权限
			return PaginationBuilder.buildResult(CollectionUtils.convertFilterList(resultList, roleDataArray), page.getTotal(), currentPage, pageSize);
		} else {
			return PaginationBuilder.buildResult(resultList, page.getTotal(), currentPage, pageSize);
		}
	}

	/**
	 * 根据参数查询用户列表
	 */
	public List<LinkedHashMap<String, Object>> querySysUser(Map<String, Object> paramMap) {
		Long orgId = Long.valueOf(String.valueOf(paramMap.get("orgId")));
		if (orgId != null) {
			Set<Long> orgIds = new HashSet<>();
			orgIds.add(orgId);
			paramMap.put("orgIdArray", orgIds.stream().toArray(Long[]::new));
		}
		return sysUserMapper.querySysUser(paramMap);
	}

	/**
	 * 查询用户的导出数据列表
	 */
	@Override
	public List<LinkedHashMap<String, Object>> querySysUserForExcel(Map<String, Object> paramMap) {
		paramMap.put("tenantCode", CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode"));// 当前用户的租户编码
		if (paramMap.get("onlinestatus") != null) {
			List<Object> principals = sessionRegistry.getAllPrincipals();
			if (principals.isEmpty()) {
				principals.add("admin");
			}
			if (paramMap.get("username") != null && StringUtils.isNotBlank(paramMap.get("username").toString())) {
				paramMap.put("onlineusername", paramMap.get("username").toString());
			}
			paramMap.put("username", StringUtils.join(principals.toArray(), "|"));
		}

		if (paramMap.get("status") != null && StringUtils.isNotBlank(paramMap.get("status").toString())) {
			String[] statusArray = paramMap.get("status").toString().split(",");
			paramMap.put("statusList", ConvertUtils.convert(statusArray, Short.class));
		}
		List<LinkedHashMap<String, Object>> resultList = new ArrayList<>();
		List<LinkedHashMap<String, Object>> dataList = sysUserMapper.querySysUser(paramMap);
		if (!org.apache.commons.collections.CollectionUtils.isEmpty(dataList)) {
			dataList.forEach(map -> {
				LinkedHashMap<String, Object> entity = new LinkedHashMap<>();
				for (Entry<String, Object> entry : map.entrySet()) {
					String key = entry.getKey();
					Object value = entry.getValue();
					if ("status".equals(key)) {
						value = Short.valueOf(value.toString()) == 1 ? "正常" : "禁用";
					}
					entity.put(key, value);
				}
				resultList.add(entity);
			});
		}
		return resultList;
	}

	/**
	 * 根据用户ID查询用户名的数据列表
	 */
	@Override
	public List<LinkedHashMap<String, Object>> queryUsername(Long[] id, String tenantCode) {
		String realTenantCode;
		if (StringUtils.isNotBlank(tenantCode)) {
			realTenantCode = tenantCode;
		} else {
			realTenantCode = CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode");
		}
		return sysUserMapper.queryUsername(id, realTenantCode);
	}

	/**
	 * 根据用户名查询用户ID的数据列表
	 */
	@Override
	public List<Long> querySysUserId(String[] username, String tenantCode) {
		String realTenantCode;
		if (StringUtils.isNotBlank(tenantCode)) {
			realTenantCode = tenantCode;
		} else {
			realTenantCode = CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode");
		}
		return sysUserMapper.querySysUserId(username, realTenantCode);
	}

	/**
	 * 查询用户所属的多个租户的下拉框数据
	 */
	@Override
	public List<LinkedHashMap<String, Object>> queryTenantUser(String userInfo) {
		return sysUserMapper.queryTenantUser(userInfo);
	}

	/**
	 * 注册用户并初始化
	 */
	@Override
	public void insertSysUserInitial(SysUser sysUser) {
		String smsCaptchaKey = ApplicationConstants.SMS_CAPTCHA_PREFIX + sysUser.getMobile();
//		String smsCaptchaCache = redisUtils.get(smsCaptchaKey);
//		if (!sysUser.getCaptcha().equals(smsCaptchaCache)) {
//			throw new IllegalArgumentException("手机验证码错误");
//		}
//		redisUtils.del(smsCaptchaKey);

		Integer existing = sysUserMapper.getSysUserByIdentification(sysUser.getUsername().trim(), sysUser.getEmail().trim(), sysUser.getMobile().trim());
		if (existing != null && existing > 0) {
			throw new IllegalArgumentException("用户名或邮箱或手机号已存在");
		}

		String tenantCode = String.valueOf(new Random().nextInt(99999999));

		// 新增机构
		SysOrg sysOrg = new SysOrg();
		Long sysOrgId = sequenceGenerator.nextId();
		sysOrg.setId(sysOrgId);
		sysOrg.setOrgName(sysUser.getTenantName() + "机构");
		sysOrg.setOrgType("company");
		sysOrg.setParentId(0L);
		sysOrg.setTenantCode(tenantCode);
		sysOrgMapper.insertSysOrg(sysOrg);

		Long userId = sequenceGenerator.nextId();
		sysUser.setId(userId);
		sysUser.setPassword(encoder.encode(sysUser.getPassword()));
		sysUser.setProvinceRegionCode("440000");
		sysUser.setCityRegionCode("440100");
		sysUser.setTenantCode(tenantCode);
		sysUserMapper.insertSysUser(sysUser);

		// 新增机构和用户关联信息
		sysUserMapper.insertSysOrgUser(sequenceGenerator.nextId(), sysOrgId, userId, tenantCode);

		// 新增租户
		SysTenant sysTenant = new SysTenant();
		Long tenantId = sequenceGenerator.nextId();
		sysTenant.setId(tenantId);
		sysTenant.setTenantCode(tenantCode);
		sysTenant.setTenantName(sysUser.getTenantName());
		sysTenantMapper.insertSysTenant(sysTenant);

		// 新增用户与租户关联
		sysUserMapper.insertSysTenantUser(sequenceGenerator.nextId(), tenantId, userId);

		// 新增岗位
		SysPost sysPost = new SysPost();
		sysPost.setId(sequenceGenerator.nextId());
		String postCode = "OFFICE-" + tenantCode;
		sysPost.setPostCode(postCode);
		String postName = sysUser.getTenantName() + "管理员岗位";
		sysPost.setPostName(postName);
		sysPost.setParentId(0L);
		sysPost.setTenantCode(tenantCode);
		sysPostMapper.insertSysPost(sysPost);

		// 新增角色
		SysRole sysRole = new SysRole();
		Long roleId = sequenceGenerator.nextId();
		sysRole.setId(roleId);
		sysRole.setRoleCode("ROLE_ADMIN_" + tenantCode);
		sysRole.setRoleName(sysUser.getTenantName() + "管理员角色");
		sysRole.setTenantCode(tenantCode);
		sysRoleMapper.insertSysRole(sysRole);

		// 新增用户与岗位关联
		SysUserPost sysUserPost = new SysUserPost();
		sysUserPost.setId(sequenceGenerator.nextId());
		sysUserPost.setUserId(userId);
		sysUserPost.setPostCode(postCode);
		sysUserPost.setPostName(postName);
		sysUserPost.setPostType((short) 1);
		sysUserPost.setStatus((short) 1);
		sysUserPost.setTenantCode(tenantCode);
		sysUserPostMapper.insertSysUserPost(sysUserPost);

		// 新增用户、岗位与角色关联
		sysRoleMapper.insertSysRoleUser(sequenceGenerator.nextId(), roleId, userId, postCode, tenantCode);

		// 新增菜单
		Map<String, Object> menuParamMap = new HashMap<>();
		menuParamMap.put("parentId", 0);
		//menuParamMap.put("tenantCode", "10001");
		menuParamMap.put("tenantCode", "31453219");
		List<LinkedHashMap<String, Object>> menuTotalList = sysMenuMapper.querySysMenu(menuParamMap);
		if (menuTotalList.size() > 0) {
			for (int i = 0; i < menuTotalList.size(); i++) {
				LinkedHashMap<String, Object> map = menuTotalList.get(i);

				SysMenu sysMenu = new SysMenu();
				Long menuId = sequenceGenerator.nextId();
				sysMenu.setId(menuId);
				sysMenu.setMenuCode(String.valueOf(map.get("menuCode")));
				sysMenu.setMenuName(String.valueOf(map.get("menuName")));
				sysMenu.setMenuIcon(String.valueOf(map.get("menuIcon")));
				sysMenu.setMenuPath(String.valueOf(map.get("menuPath")));
				sysMenu.setMenuComponent(String.valueOf(map.get("menuComponent")));
				sysMenu.setMenuSequence(Long.valueOf(String.valueOf(map.get("menuSequence"))));
				sysMenu.setMenuStatus(Short.valueOf(String.valueOf(map.get("menuStatus"))));
				sysMenu.setParentId(0L);
				sysMenu.setTenantCode(tenantCode);
				sysMenuMapper.insertSysMenu(sysMenu);

				// 新增角色与菜单关联
				sysMenuMapper.insertRoleIdMenuId(sequenceGenerator.nextId(), roleId, menuId, tenantCode);

				insertRecursiveSysMenu(Long.valueOf(String.valueOf(map.get("id"))), menuId, roleId, tenantCode);
			}
		}

		// 新增URL
		Map<String, Object> urlParamMap = new HashMap<>();
		//menuParamMap.put("tenantCode", "10001");
		menuParamMap.put("tenantCode", "31453219");
		List<LinkedHashMap<String, Object>> urlTotalList = sysUrlMapper.querySysUrl(urlParamMap);
		if (urlTotalList.size() > 0) {
			for (int i = 0; i < urlTotalList.size(); i++) {
				LinkedHashMap<String, Object> map = urlTotalList.get(i);
				SysUrl sysUrl = new SysUrl();
				Long urlId = sequenceGenerator.nextId();
				sysUrl.setId(urlId);
				sysUrl.setUrl(String.valueOf(map.get("url")));
				sysUrl.setDescription(String.valueOf(map.get("description")));
				sysUrl.setTenantCode(tenantCode);
				sysUrlMapper.insertSysUrl(sysUrl);

				// 新增URL与角色关联
				sysUrlMapper.insertUrlIdRoleId(Long.valueOf(sequenceGenerator.nextId()), urlId, roleId, tenantCode);
			}
		}

		// 新增字典
		Map<String, Object> dictParamMap = new HashMap<>();
		dictParamMap.put("parentId", 0);
		//menuParamMap.put("tenantCode", "10001");
		menuParamMap.put("tenantCode", "31453219");
		List<LinkedHashMap<String, Object>> dictTotalList = sysDictMapper.querySysDict(dictParamMap);
		if (dictTotalList.size() > 0) {
			for (int i = 0; i < dictTotalList.size(); i++) {
				LinkedHashMap<String, Object> map = dictTotalList.get(i);
				SysDict sysDict = new SysDict();
				Long dictId = sequenceGenerator.nextId();
				sysDict.setId(dictId);
				sysDict.setDictName(String.valueOf(map.get("dictName")));
				sysDict.setDictValue(String.valueOf(map.get("dictValue")));
				sysDict.setDictType(String.valueOf(map.get("dictType")));
				sysDict.setDictSequence(Long.valueOf(String.valueOf(map.get("dictSequence"))));
				sysDict.setParentId(0L);
				sysDict.setTenantCode(tenantCode);
				sysDictMapper.insertSysDict(sysDict);

				insertRecursiveSysDict(Long.valueOf(String.valueOf(map.get("id"))), dictId, tenantCode);
			}
		}

		refreshRedis();

		logger.info("用户已新增： {}", sysUser.getUsername());
	}

	/**
	 * 刷新Redis里的缓存数据
	 */
	private void refreshRedis() {
		List<String> roleCodeList = sysRoleMapper.queryRoleCodeList();
		for (int i = 0; i < roleCodeList.size(); i++) {
			String roleCode = roleCodeList.get(i);
			List<String> url = sysUrlMapper.queryRoleUrl(roleCode);
			redisUtils.psetex(ApplicationConstants.URL_ROLECODE_PREFIX + roleCode, url == null ? Collections.emptyList().toString() : url.toString());
		}
	}

	/**
	 * 无限级迭代菜单数据
	 *
	 * @param id         原菜单ID
	 * @param menuId     新菜单ID
	 * @param roleId     角色ID
	 * @param tenantCode 租户编码
	 */
	private void insertRecursiveSysMenu(Long id, Long menuId, Long roleId, String tenantCode) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("parentId", id);
		//menuParamMap.put("tenantCode", "10001");
		paramMap.put("tenantCode", "31453219");
		List<LinkedHashMap<String, Object>> list = sysMenuMapper.querySysMenu(paramMap);
		if (list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				LinkedHashMap<String, Object> subMap = list.get(i);
				SysMenu subSysMenu = new SysMenu();
				Long subMenuId = sequenceGenerator.nextId();
				subSysMenu.setId(subMenuId);
				subSysMenu.setMenuCode(String.valueOf(subMap.get("menuCode")));
				subSysMenu.setMenuName(String.valueOf(subMap.get("menuName")));
				subSysMenu.setMenuIcon(String.valueOf(subMap.get("menuIcon")));
				subSysMenu.setMenuPath(String.valueOf(subMap.get("menuPath")));
				subSysMenu.setMenuComponent(String.valueOf(subMap.get("menuComponent")));
				subSysMenu.setMenuSequence(Long.valueOf(String.valueOf(subMap.get("menuSequence"))));
				subSysMenu.setMenuStatus(Short.valueOf(String.valueOf(subMap.get("menuStatus"))));
				subSysMenu.setParentId(menuId);
				subSysMenu.setTenantCode(tenantCode);
				sysMenuMapper.insertSysMenu(subSysMenu);

				// 新增角色与菜单关联
				sysMenuMapper.insertRoleIdMenuId(sequenceGenerator.nextId(), roleId, subMenuId, tenantCode);

				insertRecursiveSysMenu(Long.valueOf(String.valueOf(subMap.get("id"))), subMenuId, roleId, tenantCode);
			}
		}
	}

	/**
	 * 无限级迭代字典数据
	 *
	 * @param id         原字典ID
	 * @param dictId     新字典ID
	 * @param tenantCode 租户编码
	 */
	private void insertRecursiveSysDict(Long id, Long dictId, String tenantCode) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("parentId", id);
		//paramMap.put("tenantCode", "10001");
		paramMap.put("tenantCode", "31453219");
		List<LinkedHashMap<String, Object>> list = sysDictMapper.querySysDict(paramMap);
		if (list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				LinkedHashMap<String, Object> subMap = list.get(i);
				SysDict subSysDict = new SysDict();
				Long subDictId = sequenceGenerator.nextId();
				subSysDict.setId(subDictId);
				subSysDict.setDictName(String.valueOf(subMap.get("dictName")));
				subSysDict.setDictValue(String.valueOf(subMap.get("dictValue")));
				subSysDict.setDictType(String.valueOf(subMap.get("dictType")));
				subSysDict.setDictSequence(Long.valueOf(String.valueOf(subMap.get("dictSequence"))));
				subSysDict.setParentId(dictId);
				subSysDict.setTenantCode(tenantCode);
				sysDictMapper.insertSysDict(subSysDict);

				insertRecursiveSysDict(Long.valueOf(String.valueOf(subMap.get("id"))), subDictId, tenantCode);
			}
		}
	}

	/**
	 * 新增用户
	 */
	@Override
	public void insertSysUser(SysUser sysUser) {
		Integer existing = sysUserMapper.getSysUserByIdentification(sysUser.getUsername().trim(), sysUser.getEmail().trim(), sysUser.getMobile().trim());
		if (existing != null && existing > 0) {
			throw new IllegalArgumentException("用户名或邮箱或手机号已存在");
		}
		long userId = sequenceGenerator.nextId();
		sysUser.setId(userId);
		sysUser.setPassword(encoder.encode(sysUser.getPassword()));
		sysUser.setTenantCode(CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode"));// 当前用户的租户编码
		sysUserMapper.insertSysUser(sysUser);
		if (sysUser.getRoleId() != null && sysUser.getRoleId().length > 0) {
			for (int i = 0; i < sysUser.getRoleId().length; i++) {
				sysRoleMapper.insertSysRoleUser(sequenceGenerator.nextId(), sysUser.getRoleId()[i], userId, "CTS-RD-04", CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode"));
			}
		}
		if (sysUser.getOrgId() != null && sysUser.getOrgId().length > 0) {
			for (int i = 0; i < sysUser.getOrgId().length; i++) {
				sysUserMapper.insertSysOrgUser(sequenceGenerator.nextId(), sysUser.getOrgId()[i], userId, CurrentUserUtils.getOAuth2AuthenticationInfo().get("tenantCode"));
			}
		}
		sysUserMapper.insertSysTenantUser(sequenceGenerator.nextId(), sysTenantMapper.getIdByCode(CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode")), userId);
		logger.info("用户已新增： {}", sysUser.getUsername());
	}

	/**
	 * 将对应的角色授予用户
	 */
	@Override
	public void insertRoleIdUserId(Long[] roleId, Long userId, String postCode) {
		Set<Long> roleIdSet = new HashSet<>();
        Collections.addAll(roleIdSet, roleId);
		sysRoleMapper.deleteSysRoleUserPost(userId, postCode, CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode"));
		Iterator<Long> iterator = roleIdSet.iterator();
		while (iterator.hasNext()) {
			Long roleIdData = iterator.next();
			sysRoleMapper.insertSysRoleUser(sequenceGenerator.nextId(), roleIdData, userId, postCode, CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode"));
		}
	}

	/**
	 * 新增租户与用户关联信息
	 */
	@Override
	public void insertSysTenantUser(String tenantCode, Long[] userId) {
		for (int i = 0; i < userId.length; i++) {
			sysUserMapper.insertSysTenantUser(sequenceGenerator.nextId(), sysTenantMapper.getIdByCode(tenantCode), userId[i]);
		}
	}

	/**
	 * 编辑用户
	 */
	@Override
	public void updateSysUser(SysUser sysUser) {
		Integer existing = sysUserMapper.getSysUserByIdEmailMobile(sysUser.getId(), sysUser.getEmail().trim(), sysUser.getMobile().trim(), CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode"));
		if (existing != null && existing > 0) {
			throw new IllegalArgumentException("邮箱或手机号已存在");
		}
		if (StringUtils.isNotBlank(sysUser.getPassword())) {
			sysUser.setPassword(encoder.encode(sysUser.getPassword()));
		}
		sysUser.setTenantCode(CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode"));// 当前用户的租户编码
		sysUserMapper.updateSysUser(sysUser);
		if (sysUser.getRoleId() != null && sysUser.getRoleId().length > 0) {
			sysRoleMapper.deleteSysRoleUser(sysUser.getId(), null, CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode"));
			for (int i = 0; i < sysUser.getRoleId().length; i++) {
				sysRoleMapper.insertSysRoleUser(sequenceGenerator.nextId(), sysUser.getRoleId()[i], sysUser.getId(), "CTS-RD-04", CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode"));
			}
		}
		if (sysUser.getOrgId() != null && sysUser.getOrgId().length > 0) {
			sysUserMapper.deleteSysOrgUser(sysUser.getId());
			for (int i = 0; i < sysUser.getOrgId().length; i++) {
				sysUserMapper.insertSysOrgUser(sequenceGenerator.nextId(), sysUser.getOrgId()[i], sysUser.getId(), CurrentUserUtils.getOAuth2AuthenticationInfo().get("tenantCode"));
			}
		}
		logger.info("用户已编辑： {}", sysUser.getUsername());
	}

	/**
	 * 删除用户
	 */
	@Override
	public void deleteSysUser(Long[] id) {
		if (ArrayUtils.contains(id, 1L)) {
			throw new IllegalArgumentException("系统管理员不能删除");
		}
		sysUserMapper.deleteSysUser(id, CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode"));
		sysUserMapper.deleteSysTenantUser(id, sysTenantMapper.getIdByCode(CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode")));
		for (int i = 0; i < id.length; i++) {
			sysUserMapper.deleteSysOrgUser(id[i]);
		}
		for (int j = 0; j < id.length; j++) {
			sysRoleMapper.deleteSysRoleUser(id[j], null, CurrentUserUtils.getOAuth2AuthenticationInfo().get("tenantCode"));
		}
	}

	/**
	 * 导入用户
	 */
	@Override
	public void importSysUser(MultipartFile file) {
		if (file.getOriginalFilename().toLowerCase().indexOf(".xlsx") == -1) {
			throw new IllegalArgumentException("请上传xlsx格式的文件");
		}
		List<Map<Integer, String>> listMap = ExcelUtils.readExcel(file);
		for (Map<Integer, String> data : listMap) {
			SysUser sysUser = new SysUser();
			sysUser.setUsername(data.get(0) == null ? "" : data.get(0));
			sysUser.setPassword(data.get(1) == null ? "" : data.get(1));
			sysUser.setEmail(data.get(2) == null ? "" : data.get(2));
			sysUser.setMobile(data.get(3) == null ? "" : data.get(3));
			sysUser.setPrefix(data.get(4) == null ? "" : data.get(4));
			sysUser.setStatus(data.get(5) == null ? 1 : Short.valueOf(data.get(5)));
			insertSysUser(sysUser);
		}
	}

}
