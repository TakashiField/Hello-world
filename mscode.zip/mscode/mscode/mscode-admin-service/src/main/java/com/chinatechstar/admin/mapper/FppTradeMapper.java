package com.chinatechstar.admin.mapper;

import com.chinatechstar.admin.entity.FppTrade;

import java.util.List;

/**
 * 行业类别信息mapper
 */
public interface FppTradeMapper {

    /**
     * 查询所有的顶级0下面的行业类别，因为是两个级别，除了顶级0下面的类别就只剩下一个类别
     */
    List<FppTrade> selectTradeTop();

    /**
     * 根据父id查询父id下面的所有数据
     * @return
     */
    List<FppTrade> selectTrade(String typeno);
}
