package com.chinatechstar.admin.controller;

import com.chinatechstar.admin.entity.FppTrade;
import com.chinatechstar.admin.entity.SysRegion;
import com.chinatechstar.admin.service.FppTradeService;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author lixu
 */
@RestController
@RequestMapping("/fppTrade")
public class FppTradeController {

    @Autowired
    private FppTradeService fppTradeService;

    private final Logger logger = LoggerFactory.getLogger(getClass());

    @ApiOperation(value = "查询所有区域的树数据")
    @GetMapping("/queryFppTradeTreeAll")
    public ListResult<Object> queryFppTradeTreeAll(){
        logger.info("进入getMenuInfo方法+++++++++++++++++++++++");
        List<Map<String, Object>> result = new ArrayList<>();// 定义一个map处理json键名问题
        List<FppTrade> fppTrades = fppTradeService.selectTradeTop();
        return ResultBuilder.buildListSuccess(treeload(fppTrades,result,1));
    }

    /**
     * 	对菜单树数据进行处理
     * @param first 一级菜单
     * @param result 遍历结果菜单
     * @param i 当前菜单级数（只能从1开始）
     * @return
     */
    private List<Map<String, Object>> treeload(List<FppTrade> first, List<Map<String, Object>> result,int i) {
        i++;
        for (FppTrade d : first) {
            HashMap<String, Object> map = new HashMap<>();
            map.put("id", d.getTypeno());
            map.put("title", d.getTypename());
            map.put("spread", false);      //设置是否展开
            if(i == 3){
                map.put("leaf",true);
            }else {
                map.put("leaf",false);
            }
            List<Map<String, Object>> result1 = new ArrayList<Map<String, Object>>();
            List<FppTrade> children = new ArrayList<>();
            if(i==2){
                children = fppTradeService.selectTrade(d.getTypeno());
                i=2;
            }
            map.put("children", treeload(children, result1,i));
            result.add(map);
        }
        return result;
    }
}
