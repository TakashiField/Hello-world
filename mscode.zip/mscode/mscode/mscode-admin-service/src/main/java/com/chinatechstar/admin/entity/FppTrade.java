package com.chinatechstar.admin.entity;


public class FppTrade {

  private String typeno;
  private String typename;
  private String parentno;
  private String remark;
  private String mchntTpGrp;
  private String status;


  public String getTypeno() {
    return typeno;
  }

  public void setTypeno(String typeno) {
    this.typeno = typeno;
  }


  public String getTypename() {
    return typename;
  }

  public void setTypename(String typename) {
    this.typename = typename;
  }


  public String getParentno() {
    return parentno;
  }

  public void setParentno(String parentno) {
    this.parentno = parentno;
  }


  public String getRemark() {
    return remark;
  }

  public void setRemark(String remark) {
    this.remark = remark;
  }


  public String getMchntTpGrp() {
    return mchntTpGrp;
  }

  public void setMchntTpGrp(String mchntTpGrp) {
    this.mchntTpGrp = mchntTpGrp;
  }


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }
}
