package com.chinatechstar.admin.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.chinatechstar.component.commons.utils.CurrentUserUtils;
import com.chinatechstar.component.commons.utils.PDFUtils;
import com.chinatechstar.component.commons.utils.WordUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.session.SessionInformation;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.userdetails.User;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.chinatechstar.admin.entity.SysUser;
import com.chinatechstar.admin.service.SysUserService;
import com.chinatechstar.admin.vo.SysUserVO;
import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.component.commons.utils.ExcelUtils;
import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.multipart.MultipartFile;

/**
 * 用户信息的控制层
 * 
 * @版权所有 东软集团
 */
@Api(tags = { "用户信息" })
@RestController
@RequestMapping("/sysuser")
public class SysUserController {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private SysUserService sysUserService;
	@Autowired
	private SessionRegistry sessionRegistry;

	/**
	 * 注册一个新的会话
	 * 
	 * @param request 请求对象
	 * @return
	 */
	@ApiOperation(value = "注册一个新的会话")
	@PostMapping(path = "/registerNewSession")
	public ActionResult registerNewSession(HttpServletRequest request) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		sessionRegistry.registerNewSession(request.getSession().getId(), authentication.getPrincipal());
		return ResultBuilder.buildActionSuccess();
	}

	/**
	 * 下线用户
	 *
	 * @param username 用户名
	 * @return
	 */
	@ApiOperation(value = "下线用户")
	@PostMapping(path = "/removePrincipal")
	public ActionResult removePrincipal(@RequestParam(name = "username", required = true) String username) {
		String[] usernameArray = username.split(",");
		for (int i = 0; i < usernameArray.length; i++) {
			List<Object> users = sessionRegistry.getAllPrincipals();
			for (Object principal : users) {
				if (principal instanceof User) {
					String principalName = ((User) principal).getUsername();
					if (principalName.equals(usernameArray[i])) {
						List<SessionInformation> sessionsInfo = sessionRegistry.getAllSessions(principal, true);
						if (null != sessionsInfo && sessionsInfo.size() > 0) {
							for (SessionInformation sessionInformation : sessionsInfo) {
								sessionInformation.expireNow();
								sessionRegistry.removeSessionInformation(sessionInformation.getSessionId());
							}
						}
					}
				}
			}
		}
		return ResultBuilder.buildActionSuccess();
	}

	/**
	 * 查询在线用户分页
	 * 
	 * @param sysUserVO 用户前端参数
	 * @return
	 */
	@ApiOperation(value = "查询在线用户分页")
	@GetMapping(path = "/queryOnlineSysUser")
	public ListResult<Object> queryOnlineSysUser(SysUserVO sysUserVO) {
		Map<String, Object> data = sysUserService.queryOnlineSysUser(sysUserVO.getCurrentPage(), sysUserVO.getPageSize(), sysUserVO.getUsername(),
				sysUserVO.getNickname(), sysUserVO.getMobile(), sysUserVO.getRoleId(), sysUserVO.getOrgId(), sysUserVO.getSorter());
		return ResultBuilder.buildListSuccess(data);
	}

	/**
	 * 查询用户分页
	 * 
	 * @param sysUserVO 用户前端参数
	 * @return
	 */
	@ApiOperation(value = "查询用户分页")
	@GetMapping(path = "/querySysUser")
	public ListResult<Object> querySysUser(SysUserVO sysUserVO) {
		Map<String, Object> data = sysUserService.querySysUser(sysUserVO.getCurrentPage(), sysUserVO.getPageSize(), sysUserVO.getUsername(),
				sysUserVO.getStatus(), sysUserVO.getOrgId(), sysUserVO.getRoleId(), sysUserVO.getNickname(), sysUserVO.getMobile(), sysUserVO.getTenantCode(), sysUserVO.getSorter());
		return ResultBuilder.buildListSuccess(data);
	}

	/**
	 * 查询用户名的下拉框数据
	 * 
	 * @return
	 */
	@ApiOperation(value = "查询用户名的下拉框数据")
	@GetMapping(path = "/queryUsername")
	public ListResult<Object> queryUsername() {
		List<LinkedHashMap<String, Object>> data = sysUserService.queryUsername(null, null);// 查询全部用户名
		return ResultBuilder.buildListSuccess(data);
	}

	/**
	 * 查询用户所属的多个租户的下拉框数据
	 *
	 * @param userInfo 用户信息
	 * @return
	 */
	@ApiOperation(value = "查询用户所属的多个租户的下拉框数据")
	@GetMapping(path = "/queryTenantUser")
	public ListResult<Object> queryTenantUser(@RequestParam(name = "userInfo", required = true) String userInfo) {
		List<LinkedHashMap<String, Object>> data = sysUserService.queryTenantUser(userInfo);
		return ResultBuilder.buildListSuccess(data);
	}

	/**
	 * 注册用户并初始化
	 *
	 * @param sysUser 用户对象
	 * @return
	 */
	@ApiOperation(value = "注册用户并初始化")
	@PostMapping(path = "/registerAccountInitial")
	public ActionResult registerAccountInitial(@Validated(InsertValidator.class) @RequestBody SysUser sysUser) {
		sysUserService.insertSysUserInitial(sysUser);
		return ResultBuilder.buildActionSuccess();
	}

	/**
	 * 新增用户
	 * 
	 * @param sysUser 用户对象
	 * @return
	 */
	@ApiOperation(value = "新增用户")
	@PostMapping(path = "/addSysUser")
	public ActionResult addSysUser(@Validated(InsertValidator.class) @RequestBody SysUser sysUser) {
		sysUserService.insertSysUser(sysUser);
		return ResultBuilder.buildActionSuccess();
	}

	/**
	 * 新增租户与用户关联信息
	 *
	 * @param tenantCode 租户编码
	 * @param userId     用户ID
	 * @return
	 */
	@ApiOperation(value = "新增租户与用户关联信息")
	@PostMapping(path = "/addSysTenantUser")
	public ActionResult addSysTenantUser(@RequestParam(name = "tenantCode", required = true) String tenantCode, @RequestParam(name = "userId", required = true) String userId) {
		sysUserService.insertSysTenantUser(tenantCode, (Long[]) ConvertUtils.convert(userId.split(","), Long.class));
		return ResultBuilder.buildActionSuccess();
	}

	/**
	 * 将对应的角色授予用户
	 * 
	 * @param sysUserVO 用户前端参数
	 * @return
	 */
	@ApiOperation(value = "将对应的角色授予用户")
	@PostMapping(path = "/authorizeRoleToUser")
	public ActionResult authorizeRoleToUser(@Validated(InsertValidator.class) @RequestBody SysUserVO sysUserVO) {
		sysUserService.insertRoleIdUserId(sysUserVO.getRoleId(), sysUserVO.getUserId(), sysUserVO.getPostCode());
		return ResultBuilder.buildActionSuccess();
	}

	/**
	 * 编辑用户
	 * 
	 * @param sysUser 用户对象
	 * @return
	 */
	@ApiOperation(value = "编辑用户")
	@PutMapping(path = "/updateSysUser")
	public ActionResult updateSysUser(@Validated(UpdateValidator.class) @RequestBody SysUser sysUser) {
		sysUserService.updateSysUser(sysUser);
		return ResultBuilder.buildActionSuccess();
	}

	/**
	 * 删除用户
	 * 
	 * @param id 用户ID
	 * @return
	 */
	@ApiOperation(value = "删除用户")
	@PostMapping(path = "/deleteSysUser")
	public ActionResult deleteSysUser(@RequestParam(name = "id", required = true) Long[] id) {
		sysUserService.deleteSysUser(id);
		return ResultBuilder.buildActionSuccess();
	}

	/**
	 * 根据查询条件导出用户到Excel
	 *
	 * @param response 响应对象
	 * @param paramMap 参数Map
	 */
	@ApiOperation(value = "根据查询条件导出用户到Excel")
	@PostMapping(path = "/exportSysUser")
	public void exportSysUser(HttpServletResponse response, @RequestParam Map<String, Object> paramMap) {
		try {
			if (paramMap.get("isTemplate").equals("1")) { // 1为模板，0不为模板
				List<String> headList = Arrays.asList("用户名", "密码", "邮箱", "手机号", "手机号国家代码", "状态");
				ExcelUtils.exportExcel(headList, null, "用户管理", response);
			} else {
				List<String> headList = Arrays.asList("ID", "用户名", "昵称", "邮箱", "手机号", "手机号国家代码", "角色ID", "角色名称", "机构ID", "机构名称", "状态", "创建时间", "岗位编码");
				List<LinkedHashMap<String, Object>> dataList = sysUserService.querySysUserForExcel(paramMap);
				ExcelUtils.exportExcel(headList, dataList, "用户管理", response);
			}
		} catch (Exception e) {
			logger.warn(e.toString());
		}
	}

	/**
	 * 导入用户
	 *
	 * @param file 文件资源
	 * @return
	 */
	@ApiOperation(value = "导入用户")
	@PostMapping(value = "/importSysUser", consumes = {"multipart/form-data"})
	public ActionResult importSysUser(@RequestParam(name = "file", required = true) MultipartFile file) {
		sysUserService.importSysUser(file);
		return ResultBuilder.buildActionSuccess();
	}

	/**
	 * 根据查询条件导出用户到Word
	 *
	 * @param response 响应对象
	 * @param paramMap 参数Map
	 */
	@ApiOperation(value = "根据查询条件导出用户到Word")
	@PostMapping(path = "/exportWordSysUser")
	public void exportWordSysUser(HttpServletResponse response, @RequestParam Map<String, Object> paramMap) {
		try {
			List<String> headList = Arrays.asList("用户名", "昵称", "邮箱", "手机号", "机构名称", "状态");
			List<LinkedHashMap<String, Object>> dataList = sysUserService.querySysUserForExcel(paramMap);
			dataList.forEach(map -> {
				map.entrySet().removeIf(entry -> ("id".equals(entry.getKey()) || "prefix".equals(entry.getKey()) || "roleId".equals(entry.getKey()) || "roleIdCn".equals(entry.getKey()) || "orgId".equals(entry.getKey()) || "createTime".equals(entry.getKey()) || "postCode".equals(entry.getKey())));
			});
			WordUtils.exportWord(headList, dataList, "用户管理", response);
		} catch (Exception e) {
			logger.warn(e.toString());
		}
	}

	/**
	 * 根据查询条件导出用户到PDF
	 *
	 * @param response 响应对象
	 * @param paramMap 参数Map
	 */
	@ApiOperation(value = "根据查询条件导出用户到PDF")
	@PostMapping(path = "/exportPDFSysUser")
	public void exportPDFSysUser(HttpServletResponse response, @RequestParam Map<String, Object> paramMap) {
		try {
			List<String> headList = Arrays.asList("用户名", "昵称", "邮箱", "手机号", "状态");
			List<LinkedHashMap<String, Object>> dataList = sysUserService.querySysUserForExcel(paramMap);
			dataList.forEach(map -> {
				map.entrySet().removeIf(entry -> ("id".equals(entry.getKey()) || "prefix".equals(entry.getKey()) || "roleId".equals(entry.getKey()) || "roleIdCn".equals(entry.getKey()) || "orgId".equals(entry.getKey()) || "orgIdCn".equals(entry.getKey()) || "createTime".equals(entry.getKey()) || "postCode".equals(entry.getKey())));
			});
			PDFUtils.exportPDF(headList, dataList, "用户管理", response);
		} catch (Exception e) {
			logger.warn(e.toString());
		}
	}

	/**
	 * 根据用户ID查询用户名的数据列表
	 *
	 * @param sysUserId  用户ID
	 * @param tenantCode 租户编码
	 * @return
	 */
	// @PreAuthorize("#oauth2.hasScope('server')")
	@ApiOperation(value = "根据用户ID查询用户名的数据列表")
	@GetMapping(value = "/queryUsernameBySysUserId")
	public List<LinkedHashMap<String, Object>> queryUsernameBySysUserId(@RequestParam(name = "sysUserId", required = false) Long[] sysUserId, @RequestParam(name = "tenantCode", required = false) String tenantCode) {
		return sysUserService.queryUsername(sysUserId, tenantCode);
	}

	/**
	 * 根据用户名查询用户ID的数据列表
	 *
	 * @param username   用户名
	 * @param tenantCode 租户编码
	 * @return
	 */
	// @PreAuthorize("#oauth2.hasScope('server')")
	@ApiOperation(value = "根据用户名查询用户ID的数据列表")
	@GetMapping(value = "/querySysUserIdByUsername")
	public List<Long> querySysUserIdByUsername(@RequestParam(name = "username", required = false) String[] username, @RequestParam(name = "tenantCode", required = false) String tenantCode) {
		return sysUserService.querySysUserId(username, tenantCode);
	}

	/**
	 * 根据所属机构ID查询用户列表
	 *
	 * @param orgId      所属机构ID
	 * @param tenantCode 租户编码
	 * @return
	 */
	// @PreAuthorize("#oauth2.hasScope('server')")
	@ApiOperation(value = "根据所属机构ID查询用户列表")
	@PostMapping(value = "/querySysUserList")
	public List<LinkedHashMap<String, Object>> querySysUserList(@RequestParam(name = "orgId", required = true) Long orgId, @RequestParam(name = "tenantCode", required = false) String tenantCode) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("orgId", orgId);
		if (StringUtils.isNotBlank(tenantCode)) {
			paramMap.put("tenantCode", tenantCode);
		} else {
			paramMap.put("tenantCode", CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode"));
		}
		return sysUserService.querySysUser(paramMap);
	}

}
