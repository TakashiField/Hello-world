package com.chinatechstar.admin.controller;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.chinatechstar.component.commons.utils.PDFUtils;
import com.chinatechstar.component.commons.utils.WordUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.chinatechstar.admin.entity.SysTenant;
import com.chinatechstar.admin.service.SysTenantService;
import com.chinatechstar.admin.vo.SysTenantVO;
import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.component.commons.utils.ExcelUtils;
import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;
import org.springframework.web.multipart.MultipartFile;

/**
 * 租户信息的控制层
 * 
 * @版权所有 东软集团
 */
@Api(tags = { "租户信息" })
@RestController
@RequestMapping("/systenant")
public class SysTenantController {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private SysTenantService sysTenantService;

	/**
	 * 查询租户分页
	 * 
	 * @param sysTenantVO 租户前端参数
	 * @return
	 */
	@ApiOperation(value = "查询租户分页")
	@GetMapping(path = "/querySysTenant")
	public ListResult<Object> querySysTenant(SysTenantVO sysTenantVO) {
		Map<String, Object> data = sysTenantService.querySysTenant(sysTenantVO.getCurrentPage(), sysTenantVO.getPageSize(), sysTenantVO.getTenantCode(),
				sysTenantVO.getTenantName(), sysTenantVO.getDomain(), sysTenantVO.getStartTime(), sysTenantVO.getEndTime(), sysTenantVO.getTenantContact(), sysTenantVO.getTenantEmail(), sysTenantVO.getTenantTel(), sysTenantVO.getSorter());
		return ResultBuilder.buildListSuccess(data);
	}

	/**
	 * 新增租户
	 * 
	 * @param sysTenant 租户对象
	 * @return
	 */
	@ApiOperation(value = "新增租户")
	@PostMapping(path = "/addSysTenant")
	public ActionResult addSysTenant(@Validated(InsertValidator.class) @RequestBody SysTenant sysTenant) {
		sysTenantService.insertSysTenant(sysTenant);
		return ResultBuilder.buildActionSuccess();
	}

	/**
	 * 编辑租户
	 * 
	 * @param sysTenant 租户对象
	 * @return
	 */
	@ApiOperation(value = "编辑租户")
	@PutMapping(path = "/updateSysTenant")
	public ActionResult updateSysTenant(@Validated(UpdateValidator.class) @RequestBody SysTenant sysTenant) {
		sysTenantService.updateSysTenant(sysTenant);
		return ResultBuilder.buildActionSuccess();
	}

	/**
	 * 删除租户
	 * 
	 * @param id 租户ID
	 * @return
	 */
	@ApiOperation(value = "删除租户")
	@PostMapping(path = "/deleteSysTenant")
	public ActionResult deleteSysTenant(@RequestParam(name = "id", required = true) Long[] id) {
		sysTenantService.deleteSysTenant(id);
		return ResultBuilder.buildActionSuccess();
	}

	/**
	 * 根据查询条件导出租户到Excel
	 *
	 * @param response 响应对象
	 * @param paramMap 参数Map
	 */
	@ApiOperation(value = "根据查询条件导出租户到Excel")
	@PostMapping(path = "/exportSysTenant")
	public void exportSysTenant(HttpServletResponse response, @RequestParam Map<String, Object> paramMap) {
		try {
			if (paramMap.get("isTemplate").equals("1")) { // 1为模板，0不为模板
				List<String> headList = Arrays.asList("租户编码", "租户名称", "联系人", "联系邮箱", "联系电话");
				ExcelUtils.exportExcel(headList, null, "租户管理", response);
			} else {
				List<String> headList = Arrays.asList("ID", "租户编码", "租户名称", "联系人", "联系邮箱", "联系电话", "创建时间", "域名", "开始时间", "结束时间");
				List<LinkedHashMap<String, Object>> dataList = sysTenantService.querySysTenantForExcel(paramMap);
				ExcelUtils.exportExcel(headList, dataList, "租户管理", response);
			}
		} catch (Exception e) {
			logger.warn(e.toString());
		}
	}

	/**
	 * 导入租户
	 *
	 * @param file 文件资源
	 * @return
	 */
	@ApiOperation(value = "导入租户")
	@PostMapping(value = "/importSysTenant", consumes = {"multipart/form-data"})
	public ActionResult importSysTenant(@RequestParam(name = "file", required = true) MultipartFile file) {
		sysTenantService.importSysTenant(file);
		return ResultBuilder.buildActionSuccess();
	}

	/**
	 * 根据查询条件导出租户到Word
	 *
	 * @param response 响应对象
	 * @param paramMap 参数Map
	 */
	@ApiOperation(value = "根据查询条件导出租户到Word")
	@PostMapping(path = "/exportWordSysTenant")
	public void exportWordSysTenant(HttpServletResponse response, @RequestParam Map<String, Object> paramMap) {
		exportCommonSysTenant(response, paramMap, "Word");
	}

	/**
	 * 根据查询条件导出租户到PDF
	 *
	 * @param response 响应对象
	 * @param paramMap 参数Map
	 */
	@ApiOperation(value = "根据查询条件导出租户到PDF")
	@PostMapping(path = "/exportPDFSysTenant")
	public void exportPDFSysTenant(HttpServletResponse response, @RequestParam Map<String, Object> paramMap) {
		exportCommonSysTenant(response, paramMap, "PDF");
	}

	/**
	 * 根据查询条件导出租户到Word或PDF
	 *
	 * @param response 响应对象
	 * @param paramMap 参数Map
	 * @param flag     Word或PDF
	 */
	private void exportCommonSysTenant(HttpServletResponse response, @RequestParam Map<String, Object> paramMap, String flag) {
		try {
			List<String> headList = Arrays.asList("租户编码", "租户名称", "联系人", "联系邮箱", "联系电话", "创建时间");
			List<LinkedHashMap<String, Object>> dataList = sysTenantService.querySysTenantForExcel(paramMap);
			dataList.forEach(map -> {
				map.entrySet().removeIf(entry -> ("id".equals(entry.getKey()) || "domain".equals(entry.getKey()) || "startTime".equals(entry.getKey()) || "endTime".equals(entry.getKey())));
			});
			if (flag == "Word") {
				WordUtils.exportWord(headList, dataList, "租户管理", response);
			} else if (flag == "PDF") {
				PDFUtils.exportPDF(headList, dataList, "租户管理", response);
			}
		} catch (Exception e) {
			logger.warn(e.toString());
		}
	}

}
