package com.chinatechstar.auth.service.impl;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.chinatechstar.admin.client.SysRoleServiceClient;
import com.chinatechstar.component.commons.utils.ExcelUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.chinatechstar.auth.entity.AppClient;
import com.chinatechstar.auth.mapper.AppClientMapper;
import com.chinatechstar.auth.service.AppClientService;
import com.chinatechstar.component.commons.result.PaginationBuilder;
import com.chinatechstar.component.commons.utils.CollectionUtils;
import com.chinatechstar.component.commons.utils.CurrentUserUtils;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.web.multipart.MultipartFile;

/**
 * 应用信息的业务逻辑实现层
 * 
 * @版权所有 东软集团
 */
@Service
@Transactional
public class AppClientServiceImpl implements AppClientService {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private AppClientMapper appClientMapper;
	@Autowired
	private SysRoleServiceClient sysRoleServiceClient;
	@Autowired
	private PasswordEncoder passwordEncoder;

	/**
	 * 查询应用分页
	 */
	@Override
	public Map<String, Object> queryAppClient(Integer currentPage, Integer pageSize, String clientId, String authorizedGrantTypes, String scope, Long accessTokenValidity,
											  Long refreshTokenValidity, String webServerRedirectUri, String resourceIds, String authorities, String additionalInformation, Short status) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("clientId", clientId);
		paramMap.put("authorizedGrantTypes", authorizedGrantTypes);
		paramMap.put("scope", scope);
		paramMap.put("accessTokenValidity", accessTokenValidity);
		paramMap.put("refreshTokenValidity", refreshTokenValidity);
		paramMap.put("webServerRedirectUri", webServerRedirectUri);
		paramMap.put("resourceIds", resourceIds);
		paramMap.put("authorities", authorities);
		paramMap.put("additionalInformation", additionalInformation);
		paramMap.put("status", status);
		Page<Object> page = PageHelper.startPage(currentPage, pageSize);
		List<LinkedHashMap<String, Object>> resultList = appClientMapper.queryAppClient(paramMap);

		String roleData = sysRoleServiceClient.queryRoleData("appclient", CurrentUserUtils.getOAuth2AuthenticationInfo().get("name"), CurrentUserUtils.getOAuth2AuthenticationInfo().get("tenantCode"));
		String[] roleDataArray = roleData == null ? null : roleData.split(",");
		if (roleDataArray != null && roleDataArray.length > 0) {// 处理数据权限
			return PaginationBuilder.buildResult(CollectionUtils.convertFilterList(resultList, roleDataArray), page.getTotal(), currentPage, pageSize);
		} else {
			return PaginationBuilder.buildResult(resultList, page.getTotal(), currentPage, pageSize);
		}
	}

	/**
	 * 查询应用的导出数据列表
	 */
	@Override
	public List<LinkedHashMap<String, Object>> queryAppClientForExcel(Map<String, Object> paramMap) {
		return appClientMapper.queryAppClient(paramMap);
	}

	/**
	 * 新增应用
	 */
	@Override
	public void insertAppClient(AppClient appClient) {
		Integer existing = appClientMapper.getAppClientByClientCode(appClient.getClientId().trim());
		if (existing != null && existing > 0) {
			throw new IllegalArgumentException("应用编码已存在");
		}
		if (StringUtils.isNotBlank(appClient.getClientSecret())) {
			appClient.setClientSecret(passwordEncoder.encode(appClient.getClientSecret()));
		}
		appClientMapper.insertAppClient(appClient);
		logger.info("应用已新增： {}", appClient.getClientId());
	}

	/**
	 * 编辑应用
	 */
	@Override
	public void updateAppClient(AppClient appClient) {
		if (StringUtils.isNotBlank(appClient.getClientSecret())) {
			appClient.setClientSecret(passwordEncoder.encode(appClient.getClientSecret()));
		}
		appClientMapper.updateAppClient(appClient);
		logger.info("应用已编辑： {}", appClient.getClientId());
	}

	/**
	 * 删除应用
	 */
	@Override
	public void deleteAppClient(String[] clientId) {
		appClientMapper.deleteAppClient(clientId);
	}

	/**
	 * 导入应用
	 */
	@Override
	public void importAppClient(MultipartFile file) {
		if (file.getOriginalFilename().toLowerCase().indexOf(".xlsx") == -1) {
			throw new IllegalArgumentException("请上传xlsx格式的文件");
		}
		List<Map<Integer, String>> listMap = ExcelUtils.readExcel(file);
		for (Map<Integer, String> data : listMap) {
			AppClient appClient = new AppClient();
			appClient.setClientId(data.get(0) == null ? "" : data.get(0));
			appClient.setClientSecret(data.get(1) == null ? "" : passwordEncoder.encode(data.get(1)));
			appClient.setAuthorizedGrantTypes(data.get(2) == null ? "" : data.get(2));
			appClient.setScope(data.get(3) == null ? "" : data.get(3));
			appClient.setAccessTokenValidity(data.get(4) == null ? 0L : Long.valueOf(data.get(4)));
			appClient.setRefreshTokenValidity(data.get(5) == null ? 0L : Long.valueOf(data.get(5)));
			appClient.setWebServerRedirectUri(data.get(6) == null ? "" : data.get(6));
			appClient.setResourceIds(data.get(7) == null ? "" : data.get(7));
			appClient.setAuthorities(data.get(8) == null ? "" : data.get(8));
			appClient.setAdditionalInformation(data.get(9) == null ? "" : data.get(9));
			appClient.setAutoApprove(data.get(10) == null ? "" : data.get(10));
			insertAppClient(appClient);
		}
	}

}
