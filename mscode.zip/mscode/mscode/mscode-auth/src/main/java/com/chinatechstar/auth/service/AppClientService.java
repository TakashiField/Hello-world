package com.chinatechstar.auth.service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.chinatechstar.auth.entity.AppClient;
import org.springframework.web.multipart.MultipartFile;

/**
 * 应用信息的业务逻辑接口层
 *
 * @版权所有 广东国星科技有限公司 www.mscodecloud.com
 */
public interface AppClientService {

    /**
     * 查询应用分页
     *
     * @param currentPage           当前页数
     * @param pageSize              每页记录数
     * @param clientId              应用编码
     * @param authorizedGrantTypes  授权类型
     * @param scope                 授权范围
     * @param accessTokenValidity   令牌秒数
     * @param refreshTokenValidity  刷新秒数
     * @param webServerRedirectUri  回调地址
     * @param resourceIds           资源ID
     * @param authorities           权限
     * @param additionalInformation 附加信息
     * @param status                状态(1:应用管理, 2:SSO单点登录)
     * @return
     */
    Map<String, Object> queryAppClient(Integer currentPage, Integer pageSize, String clientId, String authorizedGrantTypes, String scope, Long accessTokenValidity,
                                       Long refreshTokenValidity, String webServerRedirectUri, String resourceIds, String authorities, String additionalInformation, Short status);

    /**
     * 查询应用的导出数据列表
     *
     * @param paramMap 参数Map
     * @return
     */
    List<LinkedHashMap<String, Object>> queryAppClientForExcel(Map<String, Object> paramMap);

    /**
     * 新增应用
     *
     * @param appClient 应用对象
     */
    void insertAppClient(AppClient appClient);

    /**
     * 编辑应用
     *
     * @param appClient 应用对象
     */
    void updateAppClient(AppClient appClient);

    /**
     * 删除应用
     *
     * @param clientId 应用编码
     */
    void deleteAppClient(String[] clientId);

    /**
     * 导入应用
     *
     * @param file 文件资源
     */
    void importAppClient(MultipartFile file);

}
