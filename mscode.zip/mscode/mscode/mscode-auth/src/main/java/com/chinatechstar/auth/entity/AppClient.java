package com.chinatechstar.auth.entity;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.chinatechstar.component.commons.validator.InsertValidator;
import com.chinatechstar.component.commons.validator.UpdateValidator;
import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;

/**
 * 应用信息的实体类
 * 
 * @版权所有 广东国星科技有限公司 www.mscodecloud.com
 */
public class AppClient implements Serializable {

	private static final long serialVersionUID = 3425047713144124401L;
	@NotBlank(groups = { InsertValidator.class, UpdateValidator.class })
	@Size(max = 48, min = 1, groups = { InsertValidator.class, UpdateValidator.class })
	private String clientId;// 应用编码
	@Size(max = 256, min = 1, groups = { InsertValidator.class, UpdateValidator.class })
	private String clientSecret;// 应用密钥
	@NotBlank(groups = { InsertValidator.class, UpdateValidator.class })
	@Size(max = 256, min = 1, groups = { InsertValidator.class, UpdateValidator.class })
	private String authorizedGrantTypes;// 授权类型
	@NotBlank(groups = { InsertValidator.class, UpdateValidator.class })
	@Size(max = 256, min = 1, groups = { InsertValidator.class, UpdateValidator.class })
	private String scope;// 授权范围
	private Long accessTokenValidity;// 令牌秒数
	private Long refreshTokenValidity;// 刷新秒数
	@Size(max = 256, min = 1, groups = { InsertValidator.class, UpdateValidator.class })
	private String webServerRedirectUri;// 回调地址
	@Size(max = 256, min = 1, groups = { InsertValidator.class, UpdateValidator.class })
	private String resourceIds;// 资源ID
	@Size(max = 256, min = 1, groups = { InsertValidator.class, UpdateValidator.class })
	private String authorities;// 权限
	@Size(max = 4096, min = 1, groups = { InsertValidator.class, UpdateValidator.class })
	private String additionalInformation;// 附加信息
	@Size(max = 256, min = 1, groups = { InsertValidator.class, UpdateValidator.class })
	private String autoApprove;// 自动Approval

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	public String getAuthorizedGrantTypes() {
		return authorizedGrantTypes;
	}

	public void setAuthorizedGrantTypes(String authorizedGrantTypes) {
		this.authorizedGrantTypes = authorizedGrantTypes;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public Long getAccessTokenValidity() {
		return accessTokenValidity;
	}

	public void setAccessTokenValidity(Long accessTokenValidity) {
		this.accessTokenValidity = accessTokenValidity;
	}

	public Long getRefreshTokenValidity() {
		return refreshTokenValidity;
	}

	public void setRefreshTokenValidity(Long refreshTokenValidity) {
		this.refreshTokenValidity = refreshTokenValidity;
	}

	public String getWebServerRedirectUri() {
		return webServerRedirectUri;
	}

	public void setWebServerRedirectUri(String webServerRedirectUri) {
		this.webServerRedirectUri = webServerRedirectUri;
	}

	public String getResourceIds() {
		return resourceIds;
	}

	public void setResourceIds(String resourceIds) {
		this.resourceIds = resourceIds;
	}

	public String getAuthorities() {
		return authorities;
	}

	public void setAuthorities(String authorities) {
		this.authorities = authorities;
	}

	public String getAdditionalInformation() {
		return additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public String getAutoApprove() {
		return autoApprove;
	}

	public void setAutoApprove(String autoApprove) {
		this.autoApprove = autoApprove;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		AppClient item = (AppClient) o;
		return Objects.equal(clientId, item.clientId);
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(clientId);
	}

	@Override
	public String toString() {
		return MoreObjects.toStringHelper(this).add("clientId", clientId).add("clientSecret", clientSecret).add("authorizedGrantTypes", authorizedGrantTypes)
				.add("scope", scope).add("accessTokenValidity", accessTokenValidity).add("refreshTokenValidity", refreshTokenValidity).add("webServerRedirectUri", webServerRedirectUri)
				.add("resourceIds", resourceIds).add("authorities", authorities).add("additionalInformation", additionalInformation).add("autoApprove", autoApprove).toString();
	}

}
