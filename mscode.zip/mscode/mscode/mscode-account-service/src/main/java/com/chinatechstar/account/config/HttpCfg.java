/*
 * 
 * Copyright 2016, China UnionPay Co., Ltd. All right reserved.
 * 
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF CHINA UNIONPAY CO., LTD. THE CONTENTS OF THIS FILE MAY NOT BE
 * DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM, IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN
 * PERMISSION OF CHINA UNIONPAY CO., LTD.
 * 
 * $Id: HttpCfg.java,v 1.1 2017/09/29 07:35:04 peiwang Exp $
 * 
 * Function:
 * 
 * //TODO 请添加功能描述
 * 
 * Edit History:
 * 
 * 2016-12-14 - Create By peiwang
 */
package com.chinatechstar.account.config;


import lombok.Getter;

/** @version:1.0（版本，具体版本信息自己来定）
* @Description: HTTP客户端配置（对类进行功能描述） 
* @author: czp （作者,自己姓名的拼音简称） 
* @date: 2020年5月7日上午9:46:26（日期） 
*/ 
@Getter
public class HttpCfg {
	private int connectTo;

	private int socketTo;

	private int requestTo;

	public HttpCfg(int connectTo, int socketTo, int requestTo) {
		super();
		this.connectTo = connectTo;
		this.socketTo = socketTo;
		this.requestTo = requestTo;
	}

    public void setConnectTo(int connectTo) {
		this.connectTo = connectTo;
	}

    public void setSocketTo(int socketTo) {
		this.socketTo = socketTo;
	}

    public void setRequestTo(int requestTo) {
		this.requestTo = requestTo;
	}

	@Override
	public String toString() {
		return "HttpCfg [connectTo=" + connectTo + ", socketTo=" + socketTo
				+ ", requestTo=" + requestTo + "]";
	}
}
