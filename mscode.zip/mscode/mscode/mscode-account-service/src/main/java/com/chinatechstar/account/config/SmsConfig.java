package com.chinatechstar.account.config;

import com.alibaba.fastjson.JSONObject;
import com.chinatechstar.account.util.HttpUtils;
import com.chinatechstar.account.util.MBPUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.account.config
 * @Author: zhengxiaolei
 * @CreateTime: 2024-12-03 16-02
 * @Description: TODO
 * @Version: 1.0
 */
@Configuration
public class SmsConfig {

    @Value("${crm.url}")
    private String crmUrl;
    private final Logger logger = LoggerFactory.getLogger(getClass());
    public String genSmsCode() {
        Random random = new Random();
        int code = random.nextInt(999999) + 100000;
        return String.valueOf(code);
    }

    public JSONObject commonSendMbp(String mobile,String smscode,String transCode,String platForm) {

        JSONObject respJson = new JSONObject();
        JSONObject respHead = new JSONObject();
        Map<String,String> body = new HashMap<>();
        body.put("telno",mobile);
        body.put("sendmsg","您本次的会员登录验证码为:" + smscode + "，为了你的帐号安全，请勿将此验证码透露给他人。");
        JSONObject headObj = MBPUtils.getCommonHead(transCode, platForm);
        JSONObject dataObj = MBPUtils.getDataObj(body);


        JSONObject sendObj = MBPUtils.getSendObj(headObj, dataObj);

        logger.info("发往mbp的请求报文sendText=" + sendObj);
        String url = crmUrl;
        String respStr = HttpUtils.doPostJsonNew(url, sendObj);
        logger.info("mbp返回内容respStr=" + respStr);

        JSONObject respHeadObj = MBPUtils.getRespHeadObj(respStr);
        JSONObject respDataObj = MBPUtils.getRespDataObj(respStr);

        String respcode = respHeadObj.getString("respcode");
        String msgCode = "";
        if (MBPUtils.isSuccess(respHeadObj)) {
            msgCode = "0";
        } else {
            msgCode = respcode;
        }
        String respmsg = respHeadObj.getString("respmsg");

        respHead.put("msgCode", msgCode);
        respHead.put("msgMsg", respmsg);

        respJson.put("head", respHead);
        respJson.put("body", respDataObj);

        return respJson;
    }
}
