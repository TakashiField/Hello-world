package com.chinatechstar.account.util;

import java.util.Date;

/**
 * description: ID产生器，根据时间和随机数字产生一个int类型的数字
 * @author zhg
 */
public class IdGenerator {

	public IdGenerator() {
	}

	public static long getId() {

		Date date = new Date();

		int a1 = date.hashCode();

		int a2 = (new Double((Math.random() * 100000))).intValue();

		int a3 = a1 * a2;

		// if a3>Integer.MAX_VALUE,a4 will be negative,so it be multiplyed with
		// -1
		if (a3 < 0) {
			a3 = (-1) * a3;
		}

		return a3;
	}

	public static String getIdStr() {
		String idstr = String.valueOf(getId());
		idstr = addonzero(idstr, 8);
		return String.valueOf(idstr).substring(0, 8);
	}

	public static String getIdLongStr() {
		SystemNowTime syst = new SystemNowTime();
		String idstr = String.valueOf(getId());
		idstr = addonzero(idstr, 8);
		return syst.getDateStryymmdd() + syst.getTimeStrhhmmss()
				+ String.valueOf(idstr).substring(0, 8);
	}

	/**
	 * 在字符串后补0
	 * 
	 * @param str
	 * @param len
	 * @return 字符串
	 */
	public static String addonzero(String str, int len) {
		int length = str.length();
		if (length < len)
			for (int i = 0; i < len - length; i++) {
				str += 0;
			}
		return str;
	}
	
	/**
	 * 在字符串前补0
	 * 
	 * @param str
	 * @param len
	 * @return 字符串
	 */
	public static String addLeftZero(String str, int len) {
		int length = str.length();
		String add = "";
		if (length < len)
			for (int i = 0; i < len - length; i++) {
				add += 0;
			}
		return add+str;
	}
	
	/**
	 * 生成GK开头付款码定长22位
	 * @return
	 */
//	public static String getPaymentCode() {
//		SnowFlakeIdWorker snowFlake = new SnowFlakeIdWorker(0);
//		String idstr = String.valueOf(snowFlake.nextId());
//        return "GK"+addLeftZero(idstr, 20);
//	}
}
