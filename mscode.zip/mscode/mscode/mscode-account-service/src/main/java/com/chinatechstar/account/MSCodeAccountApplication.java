package com.chinatechstar.account;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

/**
 * MSCode的账户管理启动类
 * 
 * @版权所有 东软集团
 */
@SpringBootApplication(scanBasePackages = "com.chinatechstar")
@EnableDiscoveryClient
@EnableWebSecurity
@EnableFeignClients(basePackages = { "com.chinatechstar" })
@EnableCircuitBreaker
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class MSCodeAccountApplication {

	public static void main(String[] args) {
		SpringApplication.run(MSCodeAccountApplication.class);
	}

}
