package com.chinatechstar.account.controller;

import javax.servlet.http.HttpServletResponse;

import com.chinatechstar.account.config.SmsConfig;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.chinatechstar.cache.redis.constants.ApplicationConstants;
import com.chinatechstar.cache.redis.util.RedisUtils;
import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.component.commons.utils.CaptchaUtils;

/**
 * 验证码的控制层
 *
 * @版权所有 东软集团
 */
@Api(tags = { "验证码" })
@RestController
@RequestMapping("/captcha")
public class CaptchaController {

	private final Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	private RedisUtils redisUtils;
	@Autowired
	private SmsConfig smsConfig;
//	@Autowired
//	private AliyunSmsClient aliyunSmsClient;

	/**
	 * 生成图像验证码
	 *
	 * @param response 响应对象
	 * @return
	 */
	@ApiOperation(value = "生成图像验证码")
	@GetMapping(path = "/generateImageCaptcha")
	public ResponseEntity<Resource> generateImageCaptcha(HttpServletResponse response) {
		ResponseEntity<Resource> responseEntity = null;
		try {
			String charCaptcha = CaptchaUtils.generateCharCaptcha();
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			redisUtils.psetex(ApplicationConstants.CHAR_CAPTCHA_PREFIX + authentication.getName(), charCaptcha);
			byte[] bytes = CaptchaUtils.generateImageCaptcha(charCaptcha);
			Resource resource = new ByteArrayResource(bytes);
			responseEntity = new ResponseEntity<>(resource, CaptchaUtils.getResponseHeaders(), HttpStatus.OK);
		} catch (Exception e) {
			logger.warn(e.toString());
		}
		return responseEntity;
	}

	/**
	 * 获取短信验证码并发送短信
	 *
	 * @param mobile 手机号
	 * @return
	 */
	@ApiOperation(value = "获取短信验证码并发送短信")
	@GetMapping(path = "/getSmsCaptcha")
	public ActionResult getSmsCaptcha(@RequestParam(name = "mobile", required = true) String mobile) {
		String smsCaptcha = smsConfig.genSmsCode();
		logger.info("短信验证码为：{}", smsCaptcha);
		redisUtils.psetex(ApplicationConstants.SMS_CAPTCHA_PREFIX + mobile, smsCaptcha);
		smsConfig.commonSendMbp(mobile,smsCaptcha,"USR00009","meicun");
		return ResultBuilder.buildActionSuccess();
	}

}
