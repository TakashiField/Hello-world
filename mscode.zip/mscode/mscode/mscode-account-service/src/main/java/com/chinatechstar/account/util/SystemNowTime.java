package com.chinatechstar.account.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
/**
 * 日期/时间应用
 * @author ZHG
 *
 */
public class SystemNowTime {
	Calendar t;
	int y, m, d, hh, mm, ss, ms,m0;
	public SystemNowTime() {
		t = Calendar.getInstance();
		y = t.get(Calendar.YEAR);
		m = t.get(Calendar.MONTH) + 1;
		m0 = t.get(Calendar.MONTH);
		d = t.get(Calendar.DATE);
		hh = t.get(Calendar.HOUR_OF_DAY);
		mm = t.get(Calendar.MINUTE);
		ss = t.get(Calendar.SECOND);
		ms = t.get(Calendar.MILLISECOND);
	}
	
	/**
	 * 
	 * @param date
	 */
	public SystemNowTime(Date date) {
		Calendar t=Calendar.getInstance();  
	    t.setTime(date);  
	    y = t.get(Calendar.YEAR);
		m = t.get(Calendar.MONTH) + 1;
		m0 = t.get(Calendar.MONTH);
		d = t.get(Calendar.DATE);
		hh = t.get(Calendar.HOUR_OF_DAY);
		mm = t.get(Calendar.MINUTE);
		ss = t.get(Calendar.SECOND);
		ms = t.get(Calendar.MILLISECOND);
	}
	
	public String getChinaDate() {
        String sb = add0(y) + "年" + add0(m) + "月" + add0(d) +
                "日";
		return sb;
	}
	// yyyy-mm-dd
	public String getDate() {
        return add0(y) + "-" + add0(m) + "-" + add0(d);

	}
	// yyyy-mm-dd
	public String getDate(String split) {
        return add0(y) + split + add0(m) + split + add0(d);

	}
	// yyyymmdd
	public String getDateStr() {

        return add0(y) + add0(m) + add0(d);

	}
	public String getDateStr(int i) {
		if (m + i > 12) {
			y = y + (m + i) / 12;
			m = (m + i) % 12;
		} else {
			m = m + i;
		}

        return add0(y) + add0(m) + add0(d);
	}
	// yymmdd
	public String getDateStryymmdd() {
        String sb = add0(y).substring(2
        ) + add0(m) + add0(d);
		return sb;

	}
	public String getTimeStrhhmmss() {
        return add0(hh) + add0(mm) + add0(ss);
	}

	public String getChinaTime() {
        return add0(hh) + "小时" + mm + "分" + ss + "秒";

	}

	public String add0(int parm) {

		String parmout = null;
		if (parm >= 0 && parm < 10) {
			parmout = "0" + parm;
			return parmout;
		} else {
			return String.valueOf(parm);
		}
	}

	public String getTime() {
        return add0(hh) + ":" + add0(mm) + ":" + add0(ss);
	}

	public String getRigorTime() {
        return add0(hh) + add0(mm) + add0(ss) + add0(ms);
	}

	public Date getdtime(String dtimestr) {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date = null;
		try {
			date = sdf.parse(dtimestr.substring(0, 10));
		} catch (ParseException ex) {
		}
		return date;
	}
	
	/**
	 * YYYYMMDD HH:MM:SS
	 * @return
	 *///fzg 20100806 add
	public String getDateTime()
	{

        String date = add0(y) + add0(m) + add0(d);
        String time = add0(hh) + ":" + add0(mm) + ":" + add0(ss);
		return date + " " + time;
	}

	
    /**
     *  以字符串的格式取系统时间;格式：YYYYMMDDHHMMSS
     * @return    时间字符串
     */
    public String getSysTime() {
        SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
        return df.format(new Date());
    }

	public static void main(String[] args) {
		System.out.println(new SystemNowTime());
	}
}
