package com.chinatechstar.component.commons.entity;


import java.math.BigDecimal;
import java.time.LocalDateTime;

public class FppCheckBill {

  private String gkId;
  private String paySerialNo;
  private String channelCode;
  private String payType;
  private String transCode;
  private String transNo;
  private BigDecimal orderAmount;
  private BigDecimal receiptAmount;
  private BigDecimal channelRateAmount;
  private String splitGkId;
  private BigDecimal splitMerAmount;
  private BigDecimal splitMerRateAmount;
  private String checkState;
  private String reason;
  private LocalDateTime createDate;


  public String getGkId() {
    return gkId;
  }

  public void setGkId(String gkId) {
    this.gkId = gkId;
  }


  public String getPaySerialNo() {
    return paySerialNo;
  }

  public void setPaySerialNo(String paySerialNo) {
    this.paySerialNo = paySerialNo;
  }


  public String getChannelCode() {
    return channelCode;
  }

  public void setChannelCode(String channelCode) {
    this.channelCode = channelCode;
  }


  public String getPayType() {
    return payType;
  }

  public void setPayType(String payType) {
    this.payType = payType;
  }


  public String getTransCode() {
    return transCode;
  }

  public void setTransCode(String transCode) {
    this.transCode = transCode;
  }


  public String getTransNo() {
    return transNo;
  }

  public void setTransNo(String transNo) {
    this.transNo = transNo;
  }


  public BigDecimal getOrderAmount() {
    return orderAmount;
  }

  public void setOrderAmount(BigDecimal orderAmount) {
    this.orderAmount = orderAmount;
  }


  public BigDecimal getReceiptAmount() {
    return receiptAmount;
  }

  public void setReceiptAmount(BigDecimal receiptAmount) {
    this.receiptAmount = receiptAmount;
  }


  public BigDecimal getChannelRateAmount() {
    return channelRateAmount;
  }

  public void setChannelRateAmount(BigDecimal channelRateAmount) {
    this.channelRateAmount = channelRateAmount;
  }


  public String getSplitGkId() {
    return splitGkId;
  }

  public void setSplitGkId(String splitGkId) {
    this.splitGkId = splitGkId;
  }


  public BigDecimal getSplitMerAmount() {
    return splitMerAmount;
  }

  public void setSplitMerAmount(BigDecimal splitMerAmount) {
    this.splitMerAmount = splitMerAmount;
  }


  public BigDecimal getSplitMerRateAmount() {
    return splitMerRateAmount;
  }

  public void setSplitMerRateAmount(BigDecimal splitMerRateAmount) {
    this.splitMerRateAmount = splitMerRateAmount;
  }


  public String getCheckState() {
    return checkState;
  }

  public void setCheckState(String checkState) {
    this.checkState = checkState;
  }


  public String getReason() {
    return reason;
  }

  public void setReason(String reason) {
    this.reason = reason;
  }


  public LocalDateTime getCreateDate() {
    return createDate;
  }

  public void setCreateDate(LocalDateTime createDate) {
    this.createDate = createDate;
  }

}
