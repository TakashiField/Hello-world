package com.chinatechstar.component.commons.dto;

public class PayZlApplyQrocdeDTO {

  //订单号
  private String orderNo;
  //对应order_title字段
  private String orderTitle;
  //对应attach字段
  private String attach;
  //二维码类型，00-聚合支付（默认），01-支付宝，02-微信，03-银联
  private String qrcodeType;
  //支付方式 unionpay 云闪付 alipay 支付宝 wechatpay 微信
  private String payType;
  //支付渠道 merpay-商户直连支付
  private String channelCode;
  //
  private String payMethod;

  public String getOrderNo() {
    return orderNo;
  }

  public void setOrderNo(String orderno) {
    this.orderNo = orderno;
  }

  public String getQrcodeType() {
    return qrcodeType;
  }

  public void setQrcodeType(String qrcodeType) {
    this.qrcodeType = qrcodeType;
  }

  public String getOrderTitle() {
    return orderTitle;
  }

  public void setOrderTitle(String orderTitle) {
    this.orderTitle = orderTitle;
  }

  public String getAttach() {
    return attach;
  }

  public void setAttach(String attach) {
    this.attach = attach;
  }

  public String getPayType() {
    return payType;
  }

  public void setPayType(String payType) {
    this.payType = payType;
  }

  public String getChannelCode() {
    return channelCode;
  }

  public void setChannelCode(String channelCode) {
    this.channelCode = channelCode;
  }

  public String getPayMethod() {
    return payMethod;
  }

  public void setPayMethod(String payMethod) {
    this.payMethod = payMethod;
  }

  @Override
  public String toString() {
    return "PayZlApplyQrocdeDTO{" +
            "orderNo='" + orderNo + '\'' +
            ", orderTitle='" + orderTitle + '\'' +
            ", attach='" + attach + '\'' +
            ", qrcodeType='" + qrcodeType + '\'' +
            ", payType='" + payType + '\'' +
            ", channelCode='" + channelCode + '\'' +
            ", payMethod='" + payMethod + '\'' +
            '}';
  }
}
