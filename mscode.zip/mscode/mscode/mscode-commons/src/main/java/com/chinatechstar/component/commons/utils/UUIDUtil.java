package com.chinatechstar.component.commons.utils;

import cn.hutool.core.lang.Snowflake;
import cn.hutool.core.util.IdUtil;

import java.util.UUID;


/** 
* @version:1.0（版本，具体版本信息自己来定） 
* @Description:id生成类 （对类进行功能描述） 
* @author: czp （作者,自己姓名的拼音简称） 
* @date: 2020年5月7日下午4:58:49（日期） 
*/ 
public class UUIDUtil {
	
	private static long workerId = 0;
    private static long datacenterId = 1;
    private static Snowflake snowFlake = IdUtil.createSnowflake(workerId, datacenterId);

	/**
	 * 带-的UUID
	 * 
	 * @return 36位的字符串
	 */
	public static String getUUID() {
		return UUID.randomUUID().toString();
	}
	
	/**
	 * 去掉-的UUID
	 * 
	 * @return 32位的字符串
	 */
	public static String getUUID2() {
		return UUID.randomUUID().toString().replace("-", "");
	}
	
	/**
             * 获取雪花ID
     * @return
     */
    public static synchronized long snowflakeId() {
        return snowFlake.nextId();
    }

    public static synchronized long snowflakeId(long workerId, long datacenterId) {
        Snowflake snowflake = IdUtil.createSnowflake(workerId, datacenterId);
        return snowflake.nextId();
    }
}
