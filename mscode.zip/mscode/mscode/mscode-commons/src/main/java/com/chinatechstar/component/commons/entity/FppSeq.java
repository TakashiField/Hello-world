package com.chinatechstar.component.commons.entity;


public class FppSeq {

  private String tableName;
  private Long tableIndex;


  public String getTableName() {
    return tableName;
  }

  public void setTableName(String tableName) {
    this.tableName = tableName;
  }


  public Long getTableIndex() {
    return tableIndex;
  }

  public void setTableIndex(Long tableIndex) {
    this.tableIndex = tableIndex;
  }

}
