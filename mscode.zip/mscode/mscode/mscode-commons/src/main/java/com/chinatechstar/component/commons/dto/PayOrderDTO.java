package com.chinatechstar.component.commons.dto;


import java.math.BigDecimal;

public class PayOrderDTO {

  private String gkId;//商户号
  private String orderTitle;//订单标题
  private String orderDesc;//订单描述
  private BigDecimal orderAmount;//交易金额
  private String merOrderno;//商户订单号(外部商户的订单号)
  private String merNotifyUrl;//商户接收异步通知的地址

  public String getGkId() {
    return gkId;
  }

  public void setGkId(String gkId) {
    this.gkId = gkId;
  }

  public String getOrderTitle() {
    return orderTitle;
  }

  public void setOrderTitle(String orderTitle) {
    this.orderTitle = orderTitle;
  }

  public String getOrderDesc() {
    return orderDesc;
  }

  public void setOrderDesc(String orderDesc) {
    this.orderDesc = orderDesc;
  }

  public BigDecimal getOrderAmount() {
    return orderAmount;
  }

  public void setOrderAmount(BigDecimal orderAmount) {
    this.orderAmount = orderAmount;
  }

  public String getMerOrderno() {
    return merOrderno;
  }

  public void setMerOrderno(String merOrderno) {
    this.merOrderno = merOrderno;
  }

  public String getMerNotifyUrl() {
    return merNotifyUrl;
  }

  public void setMerNotifyUrl(String merNotifyUrl) {
    this.merNotifyUrl = merNotifyUrl;
  }
}
