package com.chinatechstar.component.commons.utils;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author lixu
 */
public class CreateFppId {

    /**
     * 生成fpp_merchant_info中的gkId
     * @param regType
     * @param tableIndex
     * @return
     */
    public synchronized static String createId(String regType,Long tableIndex){
        // 定义日期格式
        String formattedDate = new SimpleDateFormat("yyyyMMdd").format(new Date());
        return "GK"+regType+formattedDate+ String.format("%08d", tableIndex);
    }

    /**
     * 生成fpp_pay_order中的order_no
     * @param tableIndex
     * @return
     */
    public synchronized  static String createOrderNo(Long tableIndex){
        // 定义日期格式
        String formattedDate = new SimpleDateFormat("yyyyMMdd").format(new Date());
        return "ORD" + formattedDate + String.format("%08d",tableIndex);
    }

    /**
     * 生成fpp_pay_serial中的pay_serial_no
     * @param tableIndex
     * @return
     */
    public synchronized static String createSerialNo(Long tableIndex){
        //定义日期格式
        String formattedDate = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        return formattedDate + "968" + String.format("%09d",tableIndex);
    }

    public static void main(String[] args) {
        String serialNo = createSerialNo(0L);
        System.out.println(serialNo);
    }

    /**
     * 生成fpp_code_plate中的code_plate_no
     * @param tableIndex
     * @return
     */
    public static String createCodePlateId(Long tableIndex) {
        String formattedDate = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        return "FCP" + formattedDate + String.format("%08d",tableIndex);
    }

    /**
     * 生成fpp_mer_cash_out中的id
     * @param tableIndex
     * @return
     */
    public static String createMerCashOut(Long tableIndex) {
        String formattedDate = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        return "MCO" + formattedDate + String.format("%08d",tableIndex);
    }

    public static String createMerSplitRsNo(Long tableIndex){
        String formattedDate = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        return "MSR" + formattedDate + String.format("%08d",tableIndex);
    }

    public static String createMerSplitRsSubNo(Long tableIndex){
        String formattedDate = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        return "MSS" + formattedDate + String.format("%08d",tableIndex);
    }
}
