package com.chinatechstar.component.commons.dto;

/**
 * @author lixu
 */
public class WechatJSAPIPayDTO {

    //订单号
    private String orderNo;
    //对应order_title字段
    private String orderTitle;
    //对应attach字段
    private String attach;
    //支付方式 unionpay 云闪付 alipay 支付宝 wechatpay 微信
    private String payType;
    //支付渠道 merpay-商户直连支付
    private String channelCode;
    //易票联支付方法，对来标记是支付宝还是微信还是银联
    private String payMethod;

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getOrderTitle() {
        return orderTitle;
    }

    public void setOrderTitle(String orderTitle) {
        this.orderTitle = orderTitle;
    }

    public String getAttach() {
        return attach;
    }

    public void setAttach(String attach) {
        this.attach = attach;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getPayMethod() {
        return payMethod;
    }

    public void setPayMethod(String payMethod) {
        this.payMethod = payMethod;
    }
}
