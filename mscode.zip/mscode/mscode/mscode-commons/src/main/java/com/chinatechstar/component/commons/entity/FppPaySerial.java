package com.chinatechstar.component.commons.entity;


import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;

public class FppPaySerial {
  
  private String paySerialNo;
  @DateTimeFormat(pattern = "yyyy-MM-dd")
  private java.time.LocalDate sysdate;
  private String platCode;
  private String extendOrgId;
  private String extendMerId;
  private String cusMgrId;
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:SS")
  @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:SS")
  private java.time.LocalDateTime transDate;
  private String divFlag;
  private String reqSerial;
  private String transCode;
  private String transName;
  private String busiType;
  private String gkId;
  private String tpMerId;
  private String merchantName;
  private String channelCode;
  private String payType;
  private String orderTitle;
  private String orderDesc;
  private BigDecimal orderAmount;
  private String prevPayserialNo;
  private String payAcct;
  private String gatherAcct;
  private BigDecimal feeAmount;
  private BigDecimal basefeeAmount;
  private BigDecimal refundAmount;
  private String currency;
  private String transNo;
  private String merNotifyUrl;
  @DateTimeFormat(pattern = "yyyy-MM-dd")
  private java.time.LocalDate checkDate;
  private BigDecimal settleAmt;
  private String payStatus;
  private String checkState;
  private String status;
  private String respCode;
  private String respMsg;
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:SS")
  @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:SS")
  private java.time.LocalDateTime checkingDate;
  private String devNo;
  private String merOrderNo;
  private String refundNo;
  private String attach;


  public String getPaySerialNo() {
    return paySerialNo;
  }

  public void setPaySerialNo(String paySerialNo) {
    this.paySerialNo = paySerialNo;
  }


  public java.time.LocalDate getSysdate() {
    return sysdate;
  }

  public void setSysdate(java.time.LocalDate sysdate) {
    this.sysdate = sysdate;
  }


  public String getPlatCode() {
    return platCode;
  }

  public void setPlatCode(String platCode) {
    this.platCode = platCode;
  }


  public java.time.LocalDateTime getTransDate() {
    return transDate;
  }

  public void setTransDate(java.time.LocalDateTime transDate) {
    this.transDate = transDate;
  }


  public String getDivFlag() {
    return divFlag;
  }

  public void setDivFlag(String divFlag) {
    this.divFlag = divFlag;
  }


  public String getReqSerial() {
    return reqSerial;
  }

  public void setReqSerial(String reqSerial) {
    this.reqSerial = reqSerial;
  }


  public String getTransCode() {
    return transCode;
  }

  public void setTransCode(String transCode) {
    this.transCode = transCode;
  }


  public String getTransName() {
    return transName;
  }

  public void setTransName(String transName) {
    this.transName = transName;
  }


  public String getBusiType() {
    return busiType;
  }

  public void setBusiType(String busiType) {
    this.busiType = busiType;
  }


  public String getGkId() {
    return gkId;
  }

  public void setGkId(String gkId) {
    this.gkId = gkId;
  }


  public String getTpMerId() {
    return tpMerId;
  }

  public void setTpMerId(String tpMerId) {
    this.tpMerId = tpMerId;
  }


  public String getMerchantName() {
    return merchantName;
  }

  public void setMerchantName(String merchantName) {
    this.merchantName = merchantName;
  }


  public String getChannelCode() {
    return channelCode;
  }

  public void setChannelCode(String channelCode) {
    this.channelCode = channelCode;
  }


  public String getPayType() {
    return payType;
  }

  public void setPayType(String payType) {
    this.payType = payType;
  }


  public String getOrderTitle() {
    return orderTitle;
  }

  public void setOrderTitle(String orderTitle) {
    this.orderTitle = orderTitle;
  }


  public String getOrderDesc() {
    return orderDesc;
  }

  public void setOrderDesc(String orderDesc) {
    this.orderDesc = orderDesc;
  }


  public BigDecimal getOrderAmount() {
    return orderAmount;
  }

  public void setOrderAmount(BigDecimal orderAmount) {
    this.orderAmount = orderAmount;
  }


  public String getPrevPayserialNo() {
    return prevPayserialNo;
  }

  public void setPrevPayserialNo(String prevPayserialNo) {
    this.prevPayserialNo = prevPayserialNo;
  }


  public String getPayAcct() {
    return payAcct;
  }

  public void setPayAcct(String payAcct) {
    this.payAcct = payAcct;
  }


  public String getGatherAcct() {
    return gatherAcct;
  }

  public void setGatherAcct(String gatherAcct) {
    this.gatherAcct = gatherAcct;
  }


  public BigDecimal getFeeAmount() {
    return feeAmount;
  }

  public void setFeeAmount(BigDecimal feeAmount) {
    this.feeAmount = feeAmount;
  }


  public BigDecimal getBasefeeAmount() {
    return basefeeAmount;
  }

  public void setBasefeeAmount(BigDecimal basefeeAmount) {
    this.basefeeAmount = basefeeAmount;
  }


  public BigDecimal getRefundAmount() {
    return refundAmount;
  }

  public void setRefundAmount(BigDecimal refundAmount) {
    this.refundAmount = refundAmount;
  }


  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }


  public String getTransNo() {
    return transNo;
  }

  public void setTransNo(String transNo) {
    this.transNo = transNo;
  }


  public String getMerNotifyUrl() {
    return merNotifyUrl;
  }

  public void setMerNotifyUrl(String merNotifyUrl) {
    this.merNotifyUrl = merNotifyUrl;
  }


  public java.time.LocalDate getCheckDate() {
    return checkDate;
  }

  public void setCheckDate(java.time.LocalDate checkDate) {
    this.checkDate = checkDate;
  }


  public BigDecimal getSettleAmt() {
    return settleAmt;
  }

  public void setSettleAmt(BigDecimal settleAmt) {
    this.settleAmt = settleAmt;
  }


  public String getPayStatus() {
    return payStatus;
  }

  public void setPayStatus(String payStatus) {
    this.payStatus = payStatus;
  }


  public String getCheckState() {
    return checkState;
  }

  public void setCheckState(String checkState) {
    this.checkState = checkState;
  }


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }


  public String getRespCode() {
    return respCode;
  }

  public void setRespCode(String respCode) {
    this.respCode = respCode;
  }


  public String getRespMsg() {
    return respMsg;
  }

  public void setRespMsg(String respMsg) {
    this.respMsg = respMsg;
  }


  public java.time.LocalDateTime getCheckingDate() {
    return checkingDate;
  }

  public void setCheckingDate(java.time.LocalDateTime checkingDate) {
    this.checkingDate = checkingDate;
  }


  public String getDevNo() {
    return devNo;
  }

  public void setDevNo(String devNo) {
    this.devNo = devNo;
  }


  public String getMerOrderNo() {
    return merOrderNo;
  }

  public void setMerOrderNo(String merOrderNo) {
    this.merOrderNo = merOrderNo;
  }


  public String getRefundNo() {
    return refundNo;
  }

  public void setRefundNo(String refundNo) {
    this.refundNo = refundNo;
  }


  public String getAttach() {
    return attach;
  }

  public void setAttach(String attach) {
    this.attach = attach;
  }

  public String getExtendOrgId() {
    return extendOrgId;
  }

  public void setExtendOrgId(String extendOrgId) {
    this.extendOrgId = extendOrgId;
  }

  public String getExtendMerId() {
    return extendMerId;
  }

  public void setExtendMerId(String extendMerId) {
    this.extendMerId = extendMerId;
  }

  public String getCusMgrId() {
    return cusMgrId;
  }

  public void setCusMgrId(String cusMgrId) {
    this.cusMgrId = cusMgrId;
  }
}
