package com.chinatechstar.component.commons.validator;

/**
 * 新增验证器
 * 
 * @版权所有 广东国星科技有限公司 www.mscodecloud.com
 */
public interface InsertValidator {

}
