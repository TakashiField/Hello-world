package com.chinatechstar.component.commons.entity;

import java.math.BigDecimal;

public class FppMerAmountCount {

    private String gkId;

    /**
     * 平台编码
     */
    private String platCode;

    /**
     * 日交易笔数
     */
    private Long maxDayNum;

    /**
     * 月交易笔数
     */
    private Long maxMonthNum;

    /**
     * 日交易限额
     */
    private BigDecimal maxDayAmount;

    /**
     * 月交易限额
     */
    private BigDecimal maxMonthAmount;

    /**
     * 总交易金额
     */
    private BigDecimal allAmount;

    public String getGkId() {
        return gkId;
    }

    public void setGkId(String gkId) {
        this.gkId = gkId;
    }

    public String getPlatCode() {
        return platCode;
    }

    public void setPlatCode(String platCode) {
        this.platCode = platCode;
    }

    public Long getMaxDayNum() {
        return maxDayNum;
    }

    public void setMaxDayNum(Long maxDayNum) {
        this.maxDayNum = maxDayNum;
    }

    public Long getMaxMonthNum() {
        return maxMonthNum;
    }

    public void setMaxMonthNum(Long maxMonthNum) {
        this.maxMonthNum = maxMonthNum;
    }

    public BigDecimal getMaxDayAmount() {
        return maxDayAmount;
    }

    public void setMaxDayAmount(BigDecimal maxDayAmount) {
        this.maxDayAmount = maxDayAmount;
    }

    public BigDecimal getMaxMonthAmount() {
        return maxMonthAmount;
    }

    public void setMaxMonthAmount(BigDecimal maxMonthAmount) {
        this.maxMonthAmount = maxMonthAmount;
    }

    public BigDecimal getAllAmount() {
        return allAmount;
    }

    public void setAllAmount(BigDecimal allAmount) {
        this.allAmount = allAmount;
    }

}
