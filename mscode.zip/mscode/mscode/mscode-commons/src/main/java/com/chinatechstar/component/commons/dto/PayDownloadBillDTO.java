package com.chinatechstar.component.commons.dto;

/**
 * @author lixu
 */
public class PayDownloadBillDTO {

    /**对账单日期**/
    private String billDate;
    /**对账单类型**/
    private String billType;
    /**支付类型**/
    private String payType;
    /***支付渠道*/
    private String channelCode;

    public String getBillDate() {
        return billDate;
    }

    public void setBillDate(String billDate) {
        this.billDate = billDate;
    }

    public String getBillType() {
        return billType;
    }

    public void setBillType(String billType) {
        this.billType = billType;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }
}
