package com.chinatechstar.component.commons.vo;


public class FppChannelParamVO {

  private String channelCode;
  private String platCode;
  private String paramName;
  private String paramValue;
  private String paramDesc;
  private String channelName;
  private String platName;


  public String getChannelCode() {
    return channelCode;
  }

  public void setChannelCode(String channelCode) {
    this.channelCode = channelCode;
  }


  public String getPlatCode() {
    return platCode;
  }

  public void setPlatCode(String platCode) {
    this.platCode = platCode;
  }


  public String getParamName() {
    return paramName;
  }

  public void setParamName(String paramName) {
    this.paramName = paramName;
  }


  public String getParamValue() {
    return paramValue;
  }

  public void setParamValue(String paramValue) {
    this.paramValue = paramValue;
  }


  public String getParamDesc() {
    return paramDesc;
  }

  public void setParamDesc(String paramDesc) {
    this.paramDesc = paramDesc;
  }

  public String getChannelName() {
    return channelName;
  }

  public void setChannelName(String channelName) {
    this.channelName = channelName;
  }

  public String getPlatName() {
    return platName;
  }

  public void setPlatName(String platName) {
    this.platName = platName;
  }
}
