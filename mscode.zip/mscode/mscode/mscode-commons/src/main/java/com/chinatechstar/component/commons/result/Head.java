package com.chinatechstar.component.commons.result;

import java.io.Serializable;

/**
 * @author lixu
 */
public class Head implements Serializable {

    private static final long serialVersionUID = 5640856713420598478L;
    private int status;
    private String message;
    private String sign;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }
}
