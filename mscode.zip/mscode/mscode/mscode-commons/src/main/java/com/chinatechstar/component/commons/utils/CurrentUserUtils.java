package com.chinatechstar.component.commons.utils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

/**
 * 当前用户信息工具类
 * 
 * @版权所有 广东国星科技有限公司 www.mscodecloud.com
 */
public class CurrentUserUtils {

	private CurrentUserUtils() {

	}

	/**
	 * 获取当前用户详情信息
	 * 
	 * @return
	 */
	public static Map<String, String> getOAuth2AuthenticationDetailsInfo() {
		Map<String, String> oauth2AuthenticationMap = new HashMap<>();
		OAuth2Authentication oauth2Authentication = (OAuth2Authentication) SecurityContextHolder.getContext().getAuthentication();
		if (oauth2Authentication != null) {
			UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = (UsernamePasswordAuthenticationToken) oauth2Authentication
					.getUserAuthentication();
			String tenantCode = (String) ((LinkedHashMap<?, ?>) ((LinkedHashMap<?, ?>) ((LinkedHashMap<?, ?>) usernamePasswordAuthenticationToken.getDetails())
					.get("userAuthentication")).get("details")).get("tenantCode");

			LinkedHashMap<String, Object> details = (LinkedHashMap<String, Object>) oauth2Authentication.getUserAuthentication().getDetails();
			LinkedHashMap<String, String> principal = (LinkedHashMap<String, String>)details.get("principal");
			String platCode = principal.get("platCode");
			String id = principal.get("id");

			oauth2AuthenticationMap.put("tenantCode", tenantCode);
			oauth2AuthenticationMap.put("name", oauth2Authentication.getName());
			oauth2AuthenticationMap.put("platCode", platCode);
			oauth2AuthenticationMap.put("id", id);
//			oauth2AuthenticationMap.put("details", oauth2Authentication.getDetails());
		}
		return oauth2AuthenticationMap;
	}

	/**
	 * 获取当前用户信息
	 * 
	 * @return
	 */
	public static Map<String, String> getOAuth2AuthenticationInfo() {
		Map<String, String> oauth2AuthenticationMap = new HashMap<>();
		OAuth2Authentication oauth2Authentication = (OAuth2Authentication) SecurityContextHolder.getContext().getAuthentication();
		if (oauth2Authentication != null) {
			UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = (UsernamePasswordAuthenticationToken) oauth2Authentication
					.getUserAuthentication();
			String tenantCode = (String) ((LinkedHashMap<?, ?>) usernamePasswordAuthenticationToken.getDetails()).get("tenantCode");

			LinkedHashMap<String, Object> details = (LinkedHashMap<String, Object>) oauth2Authentication.getUserAuthentication().getDetails();
			LinkedHashMap<String, String> principal = (LinkedHashMap<String, String>)details.get("principal");
			String platCode = principal.get("platCode");
			String id = principal.get("id");

			oauth2AuthenticationMap.put("tenantCode", tenantCode);
			oauth2AuthenticationMap.put("name", oauth2Authentication.getName());
			oauth2AuthenticationMap.put("platCode", platCode);
			oauth2AuthenticationMap.put("id", id);
		}
		return oauth2AuthenticationMap;
	}

}
