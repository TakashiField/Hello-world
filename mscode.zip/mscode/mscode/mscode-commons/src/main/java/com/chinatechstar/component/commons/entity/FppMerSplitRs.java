package com.chinatechstar.component.commons.entity;


import java.math.BigDecimal;
import java.time.LocalDateTime;

public class FppMerSplitRs {

  private String splitSerialNo;
  private String gkId;
  private String rateId;
  private String paySerialNo;
  private LocalDateTime transDate;
  private String platCode;
  private String extendOrgId;
  private String extendMerId;
  private String cusMgrId;
  private String channelCode;
  private String payType;
  private BigDecimal orderAmount;
  private BigDecimal platAmount;
  private BigDecimal extendOrgAmount;
  private BigDecimal extendMerAmount;
  private BigDecimal channelAmount;
  private BigDecimal merAmount;
  private String splitStatus;
  private String splitReason;
  private LocalDateTime createDate;

  public String getSplitSerialNo() {
    return splitSerialNo;
  }

  public void setSplitSerialNo(String splitSerialNo) {
    this.splitSerialNo = splitSerialNo;
  }

  public LocalDateTime getTransDate() {
    return transDate;
  }

  public void setTransDate(LocalDateTime transDate) {
    this.transDate = transDate;
  }

  public String getGkId() {
    return gkId;
  }

  public void setGkId(String gkId) {
    this.gkId = gkId;
  }


  public String getRateId() {
    return rateId;
  }

  public void setRateId(String rateId) {
    this.rateId = rateId;
  }


  public String getPaySerialNo() {
    return paySerialNo;
  }

  public void setPaySerialNo(String paySerialNo) {
    this.paySerialNo = paySerialNo;
  }


  public String getPlatCode() {
    return platCode;
  }

  public void setPlatCode(String platCode) {
    this.platCode = platCode;
  }


  public String getExtendOrgId() {
    return extendOrgId;
  }

  public void setExtendOrgId(String extendOrgId) {
    this.extendOrgId = extendOrgId;
  }


  public String getExtendMerId() {
    return extendMerId;
  }

  public void setExtendMerId(String extendMerId) {
    this.extendMerId = extendMerId;
  }


  public String getCusMgrId() {
    return cusMgrId;
  }

  public void setCusMgrId(String cusMgrId) {
    this.cusMgrId = cusMgrId;
  }


  public String getChannelCode() {
    return channelCode;
  }

  public void setChannelCode(String channelCode) {
    this.channelCode = channelCode;
  }


  public String getPayType() {
    return payType;
  }

  public void setPayType(String payType) {
    this.payType = payType;
  }


  public BigDecimal getOrderAmount() {
    return orderAmount;
  }

  public void setOrderAmount(BigDecimal orderAmount) {
    this.orderAmount = orderAmount;
  }


  public BigDecimal getPlatAmount() {
    return platAmount;
  }

  public void setPlatAmount(BigDecimal platAmount) {
    this.platAmount = platAmount;
  }


  public BigDecimal getExtendOrgAmount() {
    return extendOrgAmount;
  }

  public void setExtendOrgAmount(BigDecimal extendOrgAmount) {
    this.extendOrgAmount = extendOrgAmount;
  }


  public BigDecimal getExtendMerAmount() {
    return extendMerAmount;
  }

  public void setExtendMerAmount(BigDecimal extendMerAmount) {
    this.extendMerAmount = extendMerAmount;
  }


  public BigDecimal getChannelAmount() {
    return channelAmount;
  }

  public void setChannelAmount(BigDecimal channelAmount) {
    this.channelAmount = channelAmount;
  }


  public BigDecimal getMerAmount() {
    return merAmount;
  }

  public void setMerAmount(BigDecimal merAmount) {
    this.merAmount = merAmount;
  }


  public String getSplitStatus() {
    return splitStatus;
  }

  public void setSplitStatus(String splitStatus) {
    this.splitStatus = splitStatus;
  }


  public String getSplitReason() {
    return splitReason;
  }

  public void setSplitReason(String splitReason) {
    this.splitReason = splitReason;
  }


  public LocalDateTime getCreateDate() {
    return createDate;
  }

  public void setCreateDate(LocalDateTime createDate) {
    this.createDate = createDate;
  }

}
