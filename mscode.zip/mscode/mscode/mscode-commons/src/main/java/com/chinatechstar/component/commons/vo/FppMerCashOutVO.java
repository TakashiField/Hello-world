package com.chinatechstar.component.commons.vo;

import java.time.LocalDateTime;

/**
 * @author lixu
 */
public class FppMerCashOutVO extends CommonVO{

    private String id;
    private String gkId;
    private String platCode;
    private String channelCode;
    private String tpMerId;
    private Double amount;
    private LocalDateTime createDate;
    private String status;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGkId() {
        return gkId;
    }

    public void setGkId(String gkId) {
        this.gkId = gkId;
    }

    public String getPlatCode() {
        return platCode;
    }

    public void setPlatCode(String platCode) {
        this.platCode = platCode;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getTpMerId() {
        return tpMerId;
    }

    public void setTpMerId(String tpMerId) {
        this.tpMerId = tpMerId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public LocalDateTime getCreateDate() {
        return createDate;
    }

    public void setCreateDate(LocalDateTime createDate) {
        this.createDate = createDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
