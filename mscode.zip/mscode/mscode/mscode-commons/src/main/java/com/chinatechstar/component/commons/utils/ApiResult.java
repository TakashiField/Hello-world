package com.chinatechstar.component.commons.utils;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ApiResult implements Serializable {

    private static final long serialVersionUID = 1L;

    private boolean success = false;

    private Integer code = 0;

    private String message = "";

    private Map<String, Object> data;

    public ApiResult(boolean success, String message){
        this.success = success;
        this.message = message;
    }

    public static ApiResult success(String message){
        return new ApiResult(true, message);
    }

    public static ApiResult success(String dataKey, Object data){
        return ApiResult.success(null).data(dataKey, data);
    }

    public static ApiResult failed(String message){
        return new ApiResult(false, message);
    }

    public ApiResult data(String key, Object value){
        if (this.data == null) this.data = new HashMap<String, Object>();
        this.data.put(key, value);
        return this;
    }

    public ApiResult data(Map<String, Object> res){
        if (this.data == null) this.data = new HashMap<String, Object>();
        this.data.putAll(res);
        return this;
    }

    public ApiResult code(Integer code){
        this.setCode(code);
        return this;
    }

    public ApiResult message(String message){
        this.setMessage(message);
        return this;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }
}