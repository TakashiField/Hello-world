package com.chinatechstar.component.commons.dto;

import com.chinatechstar.component.commons.entity.FppPaySerial;
import com.chinatechstar.component.commons.vo.CommonVO;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author lixu
 */
public class PaySerialQueryDTO extends CommonVO implements Serializable {

    //平台订单号、商户订单号，商户，订单标题，交易时间（开始日期、结束日期），交易状态


    //gkId
    private String gkId;
    //平台订单号
    private String orderNo;
    //商户订单号
    private String merOrderNo;
    //商户
    private String merchantName;
    //订单标题
    private String orderTitle;
    //交易开始时间
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate transDateStart;
    //交易结束时间
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate transDateEnd;
    //订单交易状态  9-初始状态待付款 0-交易已付款  1-交易完成  3-交易撤销 4-交易失败 5-部分退款
    private String status;
    //支付渠道
    private String channelCode;
    //支付方式
    private String payType;

    //用于Client专用
    FppPaySerial fppPaySerial;

    private String platCode;

    public String getGkId() {
        return gkId;
    }

    public void setGkId(String gkId) {
        this.gkId = gkId;
    }

    public String getPlatCode() {
        return platCode;
    }

    public void setPlatCode(String platCode) {
        this.platCode = platCode;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getMerOrderNo() {
        return merOrderNo;
    }

    public void setMerOrderNo(String merOrderNo) {
        this.merOrderNo = merOrderNo;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getOrderTitle() {
        return orderTitle;
    }

    public void setOrderTitle(String orderTitle) {
        this.orderTitle = orderTitle;
    }

    public LocalDate getTransDateStart() {
        return transDateStart;
    }

    public void setTransDateStart(LocalDate transDateStart) {
        this.transDateStart = transDateStart;
    }

    public LocalDate getTransDateEnd() {
        return transDateEnd;
    }

    public void setTransDateEnd(LocalDate transDateEnd) {
        this.transDateEnd = transDateEnd;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public FppPaySerial getFppPaySerial() {
        return fppPaySerial;
    }

    public void setFppPaySerial(FppPaySerial fppPaySerial) {
        this.fppPaySerial = fppPaySerial;
    }
}
