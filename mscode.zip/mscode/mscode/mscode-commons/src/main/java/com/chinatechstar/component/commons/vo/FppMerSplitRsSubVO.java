package com.chinatechstar.component.commons.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class FppMerSplitRsSubVO extends CommonVO implements Serializable {

    private String splitSerialNo;
    //商户号
    private String gkId;
    //订单流水号
    private String paySerialNo;
    //费率Id
    private String rateId;
    //订单交易时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:SS")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:SS")
    private LocalDateTime transDate;
    //平台编码
    private String platCode;
    private String platName;
    //渠道编码
    private String channelCode;
    private String channelName;
    //支付方式
    private String payType;
    //分账内部商户号
    private String splitGkId;
    //第三方支付渠道分账商户号
    private String tpMerId;
    //1-平台，2-推广机构，3-推广商, 4-商户
    private String splitOrgType;
    //机构Id
    private String splitOrgId;
    //0-常规分账对象,1-收单手续费扣除对象,2-分账手续费扣除对象,3-收单和分账手续费扣除对象
    private String splitType;
    //分账商户收入
    private BigDecimal splitMerRate;

    public String getGkId() {
        return gkId;
    }

    public void setGkId(String gkId) {
        this.gkId = gkId;
    }

    public String getPaySerialNo() {
        return paySerialNo;
    }

    public void setPaySerialNo(String paySerialNo) {
        this.paySerialNo = paySerialNo;
    }

    public String getPlatCode() {
        return platCode;
    }

    public void setPlatCode(String platCode) {
        this.platCode = platCode;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getSplitGkId() {
        return splitGkId;
    }

    public void setSplitGkId(String splitGkId) {
        this.splitGkId = splitGkId;
    }

    public String getTpMerId() {
        return tpMerId;
    }

    public void setTpMerId(String tpMerId) {
        this.tpMerId = tpMerId;
    }

    public String getSplitOrgType() {
        return splitOrgType;
    }

    public void setSplitOrgType(String splitOrgType) {
        this.splitOrgType = splitOrgType;
    }

    public String getSplitType() {
        return splitType;
    }

    public void setSplitType(String splitType) {
        this.splitType = splitType;
    }

    public BigDecimal getSplitMerRate() {
        return splitMerRate;
    }

    public void setSplitMerRate(BigDecimal splitMerRate) {
        this.splitMerRate = splitMerRate;
    }

    public String getSplitOrgId() {
        return splitOrgId;
    }

    public void setSplitOrgId(String splitOrgId) {
        this.splitOrgId = splitOrgId;
    }

    public String getRateId() {
        return rateId;
    }

    public void setRateId(String rateId) {
        this.rateId = rateId;
    }

    public LocalDateTime getTransDate() {
        return transDate;
    }

    public void setTransDate(LocalDateTime transDate) {
        this.transDate = transDate;
    }

    public String getPlatName() {
        return platName;
    }

    public void setPlatName(String platName) {
        this.platName = platName;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getSplitSerialNo() {
        return splitSerialNo;
    }

    public void setSplitSerialNo(String splitSerialNo) {
        this.splitSerialNo = splitSerialNo;
    }
}
