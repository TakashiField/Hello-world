package com.chinatechstar.component.commons.entity;


import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

public class FppMerchantInfo {

  private String gkId;
  private String platCode;
  private String extendOrgId;
  private String extendMerId;
  private String cusMgrId;
  private String merchantType;
  private String merchantName;
  private String shortName;
  private Long mcc;
  private Long provinceId;
  private Long cityId;
  private Long countyId;
  private String storeHeadPhoto;
  private String storeHallPhoto;
  private String introduce;
  private String contactPerson;
  private String contactPhone;
  private String serviceTel;
  private String email;
  private String lawyerName;
  private String lawyerCertType;
  private String lawyerCertNo;
  private String lawyerCertPhotoFront;
  private String lawyerCertPhotoBack;
  private String certificateName;
  @DateTimeFormat(pattern = "yyyy-MM-dd")
  private java.time.LocalDate certificateFrom;
  @DateTimeFormat(pattern = "yyyy-MM-dd")
  private java.time.LocalDate certificateTo;
  private String businessLicenseCode;
  private String businessLicenseName;
  private String businessLicensePhoto;
  @DateTimeFormat(pattern = "yyyy-MM-dd")
  private java.time.LocalDate businessLicenseFrom;
  @DateTimeFormat(pattern = "yyyy-MM-dd")
  private java.time.LocalDate businessLicenseTo;
  private String businessScope;
  private String registerAddress;
  private String accountType;
  private String licenceAccount;
  private String licenceAccountNo;
  private String licenceOpenBank;
  private String licenceOpenSubBank;
  private String openingLicenseAccountPhoto;
  private String settleCycle;
  private String settleAccountType;
  private String settleAccountNo;
  private String settleAccount;
  private String settleBankPhone;
  private String settleAccountBindStatus;
  private String settleAttachment;
  private String openBank;
  private String openSubBank;
  private String openBankCode;
  private String otherPhoto1;
  private String otherPhoto2;
  private String otherPhoto3;
  private String otherPhoto4;
  private String otherPhoto5;
  private String tpMerId;
  private String tpAccountStatus;
  private String tpAuditStatus;
  private String tpAuditMsg;
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:SS")
  @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:SS")
  private java.time.LocalDateTime auditDate;
  private String auditMsg;
  private String busAccountId;
  private String status;
  private Long updUserId;
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:SS")
  private java.time.LocalDateTime updDate;
  private String licenceOpenSubBankName;
  private String legalPhone;
  private String bankPhone;

  public String getGkId() {
    return gkId;
  }

  public void setGkId(String gkId) {
    this.gkId = gkId;
  }


  public String getMerchantType() {
    return merchantType;
  }

  public void setMerchantType(String merchantType) {
    this.merchantType = merchantType;
  }


  public String getMerchantName() {
    return merchantName;
  }

  public void setMerchantName(String merchantName) {
    this.merchantName = merchantName;
  }


  public String getShortName() {
    return shortName;
  }

  public void setShortName(String shortName) {
    this.shortName = shortName;
  }


  public Long getMcc() {
    return mcc;
  }

  public void setMcc(Long mcc) {
    this.mcc = mcc;
  }

  public Long getProvinceId() {
    return provinceId;
  }

  public void setProvinceId(Long provinceId) {
    this.provinceId = provinceId;
  }

  public Long getCityId() {
    return cityId;
  }

  public void setCityId(Long cityId) {
    this.cityId = cityId;
  }


  public Long getCountyId() {
    return countyId;
  }

  public void setCountyId(Long countyId) {
    this.countyId = countyId;
  }


  public String getStoreHeadPhoto() {
    return storeHeadPhoto;
  }

  public void setStoreHeadPhoto(String storeHeadPhoto) {
    this.storeHeadPhoto = storeHeadPhoto;
  }


  public String getStoreHallPhoto() {
    return storeHallPhoto;
  }

  public void setStoreHallPhoto(String storeHallPhoto) {
    this.storeHallPhoto = storeHallPhoto;
  }


  public String getIntroduce() {
    return introduce;
  }

  public void setIntroduce(String introduce) {
    this.introduce = introduce;
  }


  public String getContactPerson() {
    return contactPerson;
  }

  public void setContactPerson(String contactPerson) {
    this.contactPerson = contactPerson;
  }


  public String getContactPhone() {
    return contactPhone;
  }

  public void setContactPhone(String contactPhone) {
    this.contactPhone = contactPhone;
  }


  public String getServiceTel() {
    return serviceTel;
  }

  public void setServiceTel(String serviceTel) {
    this.serviceTel = serviceTel;
  }


  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }


  public String getLawyerName() {
    return lawyerName;
  }

  public void setLawyerName(String lawyerName) {
    this.lawyerName = lawyerName;
  }


  public String getLawyerCertType() {
    return lawyerCertType;
  }

  public void setLawyerCertType(String lawyerCertType) {
    this.lawyerCertType = lawyerCertType;
  }


  public String getLawyerCertNo() {
    return lawyerCertNo;
  }

  public void setLawyerCertNo(String lawyerCertNo) {
    this.lawyerCertNo = lawyerCertNo;
  }


  public String getLawyerCertPhotoFront() {
    return lawyerCertPhotoFront;
  }

  public void setLawyerCertPhotoFront(String lawyerCertPhotoFront) {
    this.lawyerCertPhotoFront = lawyerCertPhotoFront;
  }


  public String getLawyerCertPhotoBack() {
    return lawyerCertPhotoBack;
  }

  public void setLawyerCertPhotoBack(String lawyerCertPhotoBack) {
    this.lawyerCertPhotoBack = lawyerCertPhotoBack;
  }


  public String getCertificateName() {
    return certificateName;
  }

  public void setCertificateName(String certificateName) {
    this.certificateName = certificateName;
  }


  public java.time.LocalDate getCertificateFrom() {
    return certificateFrom;
  }

  public void setCertificateFrom(java.time.LocalDate certificateFrom) {
    this.certificateFrom = certificateFrom;
  }


  public java.time.LocalDate getCertificateTo() {
    return certificateTo;
  }

  public void setCertificateTo(java.time.LocalDate certificateTo) {
    this.certificateTo = certificateTo;
  }


  public String getBusinessLicenseCode() {
    return businessLicenseCode;
  }

  public void setBusinessLicenseCode(String businessLicenseCode) {
    this.businessLicenseCode = businessLicenseCode;
  }


  public String getBusinessLicenseName() {
    return businessLicenseName;
  }

  public void setBusinessLicenseName(String businessLicenseName) {
    this.businessLicenseName = businessLicenseName;
  }


  public String getBusinessLicensePhoto() {
    return businessLicensePhoto;
  }

  public void setBusinessLicensePhoto(String businessLicensePhoto) {
    this.businessLicensePhoto = businessLicensePhoto;
  }


  public java.time.LocalDate getBusinessLicenseFrom() {
    return businessLicenseFrom;
  }

  public void setBusinessLicenseFrom(java.time.LocalDate businessLicenseFrom) {
    this.businessLicenseFrom = businessLicenseFrom;
  }


  public java.time.LocalDate getBusinessLicenseTo() {
    return businessLicenseTo;
  }

  public void setBusinessLicenseTo(java.time.LocalDate businessLicenseTo) {
    this.businessLicenseTo = businessLicenseTo;
  }


  public String getBusinessScope() {
    return businessScope;
  }

  public void setBusinessScope(String businessScope) {
    this.businessScope = businessScope;
  }


  public String getRegisterAddress() {
    return registerAddress;
  }

  public void setRegisterAddress(String registerAddress) {
    this.registerAddress = registerAddress;
  }


  public String getLicenceAccount() {
    return licenceAccount;
  }

  public void setLicenceAccount(String licenceAccount) {
    this.licenceAccount = licenceAccount;
  }


  public String getLicenceAccountNo() {
    return licenceAccountNo;
  }

  public void setLicenceAccountNo(String licenceAccountNo) {
    this.licenceAccountNo = licenceAccountNo;
  }


  public String getLicenceOpenBank() {
    return licenceOpenBank;
  }

  public void setLicenceOpenBank(String licenceOpenBank) {
    this.licenceOpenBank = licenceOpenBank;
  }


  public String getLicenceOpenSubBank() {
    return licenceOpenSubBank;
  }

  public void setLicenceOpenSubBank(String licenceOpenSubBank) {
    this.licenceOpenSubBank = licenceOpenSubBank;
  }


  public String getOpeningLicenseAccountPhoto() {
    return openingLicenseAccountPhoto;
  }

  public void setOpeningLicenseAccountPhoto(String openingLicenseAccountPhoto) {
    this.openingLicenseAccountPhoto = openingLicenseAccountPhoto;
  }


  public String getSettleCycle() {
    return settleCycle;
  }

  public void setSettleCycle(String settleCycle) {
    this.settleCycle = settleCycle;
  }


  public String getSettleAccountType() {
    return settleAccountType;
  }

  public void setSettleAccountType(String settleAccountType) {
    this.settleAccountType = settleAccountType;
  }


  public String getSettleAccountNo() {
    return settleAccountNo;
  }

  public void setSettleAccountNo(String settleAccountNo) {
    this.settleAccountNo = settleAccountNo;
  }


  public String getSettleAccount() {
    return settleAccount;
  }

  public void setSettleAccount(String settleAccount) {
    this.settleAccount = settleAccount;
  }


  public String getSettleAttachment() {
    return settleAttachment;
  }

  public void setSettleAttachment(String settleAttachment) {
    this.settleAttachment = settleAttachment;
  }


  public String getOpenBank() {
    return openBank;
  }

  public void setOpenBank(String openBank) {
    this.openBank = openBank;
  }


  public String getOpenSubBank() {
    return openSubBank;
  }

  public void setOpenSubBank(String openSubBank) {
    this.openSubBank = openSubBank;
  }


  public String getOpenBankCode() {
    return openBankCode;
  }

  public void setOpenBankCode(String openBankCode) {
    this.openBankCode = openBankCode;
  }


  public String getOtherPhoto1() {
    return otherPhoto1;
  }

  public void setOtherPhoto1(String otherPhoto1) {
    this.otherPhoto1 = otherPhoto1;
  }


  public String getOtherPhoto2() {
    return otherPhoto2;
  }

  public void setOtherPhoto2(String otherPhoto2) {
    this.otherPhoto2 = otherPhoto2;
  }


  public String getOtherPhoto3() {
    return otherPhoto3;
  }

  public void setOtherPhoto3(String otherPhoto3) {
    this.otherPhoto3 = otherPhoto3;
  }


  public String getOtherPhoto4() {
    return otherPhoto4;
  }

  public void setOtherPhoto4(String otherPhoto4) {
    this.otherPhoto4 = otherPhoto4;
  }


  public String getOtherPhoto5() {
    return otherPhoto5;
  }

  public void setOtherPhoto5(String otherPhoto5) {
    this.otherPhoto5 = otherPhoto5;
  }


  public String getTpMerId() {
    return tpMerId;
  }

  public void setTpMerId(String tpMerId) {
    this.tpMerId = tpMerId;
  }


  public String getTpAccountStatus() {
    return tpAccountStatus;
  }

  public void setTpAccountStatus(String tpAccountStatus) {
    this.tpAccountStatus = tpAccountStatus;
  }


  public String getTpAuditStatus() {
    return tpAuditStatus;
  }

  public void setTpAuditStatus(String tpAuditStatus) {
    this.tpAuditStatus = tpAuditStatus;
  }


  public String getTpAuditMsg() {
    return tpAuditMsg;
  }

  public void setTpAuditMsg(String tpAuditMsg) {
    this.tpAuditMsg = tpAuditMsg;
  }


  public java.time.LocalDateTime getAuditDate() {
    return auditDate;
  }

  public void setAuditDate(java.time.LocalDateTime auditDate) {
    this.auditDate = auditDate;
  }


  public String getAuditMsg() {
    return auditMsg;
  }

  public void setAuditMsg(String auditMsg) {
    this.auditMsg = auditMsg;
  }


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }


  public Long getUpdUserId() {
    return updUserId;
  }

  public void setUpdUserId(Long updUserId) {
    this.updUserId = updUserId;
  }


  public java.time.LocalDateTime getUpdDate() {
    return updDate;
  }

  public void setUpdDate(java.time.LocalDateTime updDate) {
    this.updDate = updDate;
  }

  public String getPlatCode() {
    return platCode;
  }

  public void setPlatCode(String platCode) {
    this.platCode = platCode;
  }

  public String getExtendOrgId() {
    return extendOrgId;
  }

  public void setExtendOrgId(String extendOrgId) {
    this.extendOrgId = extendOrgId;
  }

  public String getExtendMerId() {
    return extendMerId;
  }

  public void setExtendMerId(String extendMerId) {
    this.extendMerId = extendMerId;
  }

  public String getCusMgrId() {
    return cusMgrId;
  }

  public void setCusMgrId(String cusMgrId) {
    this.cusMgrId = cusMgrId;
  }

  public String getBusAccountId() {
    return busAccountId;
  }

  public void setBusAccountId(String busAccountId) {
    this.busAccountId = busAccountId;
  }

  public String getAccountType() {
    return accountType;
  }

  public void setAccountType(String accountType) {
    this.accountType = accountType;
  }

  public String getLicenceOpenSubBankName() {
    return licenceOpenSubBankName;
  }

  public void setLicenceOpenSubBankName(String licenceOpenSubBankName) {
    this.licenceOpenSubBankName = licenceOpenSubBankName;
  }

  public String getLegalPhone() {
    return legalPhone;
  }

  public void setLegalPhone(String legalPhone) {
    this.legalPhone = legalPhone;
  }

  public String getBankPhone() {
    return bankPhone;
  }

  public void setBankPhone(String bankPhone) {
    this.bankPhone = bankPhone;
  }

  public String getSettleBankPhone() {
    return settleBankPhone;
  }

  public void setSettleBankPhone(String settleBankPhone) {
    this.settleBankPhone = settleBankPhone;
  }

  public String getSettleAccountBindStatus() {
    return settleAccountBindStatus;
  }

  public void setSettleAccountBindStatus(String settleAccountBindStatus) {
    this.settleAccountBindStatus = settleAccountBindStatus;
  }
}
