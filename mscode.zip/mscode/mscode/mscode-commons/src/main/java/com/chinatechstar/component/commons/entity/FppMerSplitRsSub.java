package com.chinatechstar.component.commons.entity;


import java.math.BigDecimal;

public class FppMerSplitRsSub {

  private String splitSubSerialNo;
  private String splitSerialNo;
  private String gkId;
  private String paySerialNo;
  private String platCode;
  private String channelCode;
  private String payType;
  private String busAccountId;
  private String splitGkId;
  private String tpMerId;
  private String splitOrgType;
  private String splitOrgId;
  private String splitType;
  private BigDecimal splitMerRate;
  private BigDecimal splitMerAmount;


  public String getGkId() {
    return gkId;
  }

  public void setGkId(String gkId) {
    this.gkId = gkId;
  }


  public String getPaySerialNo() {
    return paySerialNo;
  }

  public void setPaySerialNo(String paySerialNo) {
    this.paySerialNo = paySerialNo;
  }


  public String getPlatCode() {
    return platCode;
  }

  public void setPlatCode(String platCode) {
    this.platCode = platCode;
  }


  public String getChannelCode() {
    return channelCode;
  }

  public void setChannelCode(String channelCode) {
    this.channelCode = channelCode;
  }


  public String getPayType() {
    return payType;
  }

  public void setPayType(String payType) {
    this.payType = payType;
  }


  public String getSplitGkId() {
    return splitGkId;
  }

  public void setSplitGkId(String splitGkId) {
    this.splitGkId = splitGkId;
  }


  public String getTpMerId() {
    return tpMerId;
  }

  public void setTpMerId(String tpMerId) {
    this.tpMerId = tpMerId;
  }


  public String getSplitOrgType() {
    return splitOrgType;
  }

  public void setSplitOrgType(String splitOrgType) {
    this.splitOrgType = splitOrgType;
  }


  public String getSplitOrgId() {
    return splitOrgId;
  }

  public void setSplitOrgId(String splitOrgId) {
    this.splitOrgId = splitOrgId;
  }


  public String getSplitType() {
    return splitType;
  }

  public void setSplitType(String splitType) {
    this.splitType = splitType;
  }


  public BigDecimal getSplitMerRate() {
    return splitMerRate;
  }

  public void setSplitMerRate(BigDecimal splitMerRate) {
    this.splitMerRate = splitMerRate;
  }

  public String getSplitSerialNo() {
    return splitSerialNo;
  }

  public void setSplitSerialNo(String splitSerialNo) {
    this.splitSerialNo = splitSerialNo;
  }

  public String getBusAccountId() {
    return busAccountId;
  }

  public void setBusAccountId(String busAccountId) {
    this.busAccountId = busAccountId;
  }

  public String getSplitSubSerialNo() {
    return splitSubSerialNo;
  }

  public void setSplitSubSerialNo(String splitSubSerialNo) {
    this.splitSubSerialNo = splitSubSerialNo;
  }

  public BigDecimal getSplitMerAmount() {
    return splitMerAmount;
  }

  public void setSplitMerAmount(BigDecimal splitMerAmount) {
    this.splitMerAmount = splitMerAmount;
  }
}
