package com.chinatechstar.component.commons.entity;


import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class FppPayOrder {

  private String orderNo;
  @DateTimeFormat(pattern = "yyyy-MM-dd")
  private LocalDate sysdate;
  private String platCode;
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:SS")
  @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:SS")
  private LocalDateTime transDate;
  private String transType;
  private String gkId;
  private String tpMerId;
  private String merchantName;
  private String orderTitle;
  private String orderDesc;
  private BigDecimal orderAmount;
  private String currency;
  private String merNotifyUrl;
  private String receiptName;
  private String phone;
  private String address;
  private String status;
  private String devNo;
  private String attach;


  public String getOrderNo() {
    return orderNo;
  }

  public void setOrderNo(String orderNo) {
    this.orderNo = orderNo;
  }

  public LocalDate getSysdate() {
    return sysdate;
  }

  public void setSysdate(LocalDate sysdate) {
    this.sysdate = sysdate;
  }

  public String getPlatCode() {
    return platCode;
  }

  public void setPlatCode(String platCode) {
    this.platCode = platCode;
  }


  public LocalDateTime getTransDate() {
    return transDate;
  }

  public void setTransDate(LocalDateTime transDate) {
    this.transDate = transDate;
  }


  public String getTransType() {
    return transType;
  }

  public void setTransType(String transType) {
    this.transType = transType;
  }


  public String getGkId() {
    return gkId;
  }

  public void setGkId(String gkId) {
    this.gkId = gkId;
  }


  public String getTpMerId() {
    return tpMerId;
  }

  public void setTpMerId(String tpMerId) {
    this.tpMerId = tpMerId;
  }


  public String getMerchantName() {
    return merchantName;
  }

  public void setMerchantName(String merchantName) {
    this.merchantName = merchantName;
  }


  public String getOrderTitle() {
    return orderTitle;
  }

  public void setOrderTitle(String orderTitle) {
    this.orderTitle = orderTitle;
  }


  public String getOrderDesc() {
    return orderDesc;
  }

  public void setOrderDesc(String orderDesc) {
    this.orderDesc = orderDesc;
  }


  public BigDecimal getOrderAmount() {
    return orderAmount;
  }

  public void setOrderAmount(BigDecimal orderAmount) {
    this.orderAmount = orderAmount;
  }


  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }


  public String getMerNotifyUrl() {
    return merNotifyUrl;
  }

  public void setMerNotifyUrl(String merNotifyUrl) {
    this.merNotifyUrl = merNotifyUrl;
  }


  public String getReceiptName() {
    return receiptName;
  }

  public void setReceiptName(String receiptName) {
    this.receiptName = receiptName;
  }


  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }


  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }


  public String getDevNo() {
    return devNo;
  }

  public void setDevNo(String devNo) {
    this.devNo = devNo;
  }

  public String getAttach() {
    return attach;
  }

  public void setAttach(String attach) {
    this.attach = attach;
  }

}
