package com.chinatechstar.component.commons.utils;

import com.tencent.WXPay;
import com.thoughtworks.xstream.XStream;

/**
 * @author lixu
 */
public class PayZIUtil {

    public static void initSDK() {
        WXPay.initSDKConfiguration(
                "0123456789ABCDEFGHIJKLMNOPQRSTUV",
                "wx8e502e1cea6086ad",
                "1494503912",
                "",
                "",
                "/home/sfzf/cert/apiclient_cert.p12",
//                "d:/temp/apiclient_cert.p12",
                "1494503912");
    }

    public static Object getObjectFromXML(String xml, Class tClass) {
        XStream xStream = new XStream();
        XStream.setupDefaultSecurity(xStream);
        xStream.alias("xml", tClass);
        xStream.ignoreUnknownElements();
        xStream.allowTypes(new Class[]{tClass});
        return xStream.fromXML(xml);
        //xStream.allowTypesByRegExp(new String[] { ".*" });
    }
}
