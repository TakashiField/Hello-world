package com.chinatechstar.component.commons.dto;

import java.math.BigDecimal;

/**
 * @author lixu
 */
public class WithdrawalToCardDTO {
    //提现金额
    private BigDecimal payAmount;
    //开户人姓名
    private String bankUserName;
    //开户人身份证
    private String bankUserCert;
    //银行卡号
    private String bankCardNo;
    //银行名称
    private String bankName;
    //开户行省
    private String bankProvince;
    //开户行市
    private String bankCity;
    //开户行支行
    private String bankSub;
    //联行号
    private String bankNo;


    public BigDecimal getPayAmount() {
        return payAmount;
    }

    public void setPayAmount(BigDecimal payAmount) {
        this.payAmount = payAmount;
    }

    public String getBankUserName() {
        return bankUserName;
    }

    public void setBankUserName(String bankUserName) {
        this.bankUserName = bankUserName;
    }

    public String getBankUserCert() {
        return bankUserCert;
    }

    public void setBankUserCert(String bankUserCert) {
        this.bankUserCert = bankUserCert;
    }

    public String getBankCardNo() {
        return bankCardNo;
    }

    public void setBankCardNo(String bankCardNo) {
        this.bankCardNo = bankCardNo;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankProvince() {
        return bankProvince;
    }

    public void setBankProvince(String bankProvince) {
        this.bankProvince = bankProvince;
    }

    public String getBankCity() {
        return bankCity;
    }

    public void setBankCity(String bankCity) {
        this.bankCity = bankCity;
    }

    public String getBankSub() {
        return bankSub;
    }

    public void setBankSub(String bankSub) {
        this.bankSub = bankSub;
    }

    public String getBankNo() {
        return bankNo;
    }

    public void setBankNo(String bankNo) {
        this.bankNo = bankNo;
    }
}
