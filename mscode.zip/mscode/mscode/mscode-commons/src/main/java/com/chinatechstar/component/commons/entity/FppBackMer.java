package com.chinatechstar.component.commons.entity;


import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

public class FppBackMer {

  private String gkId;
  private String platCode;
  private String riskStatus;
  private String riskLevel;
  @DateTimeFormat(pattern = "yyyy-MM-dd")
  private java.time.LocalDate riskDate;
  private String riskReason;
  private Long createUserId;
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:SS")
  private java.time.LocalDateTime createDate;
  private Long updUserId;
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:SS")
  private java.time.LocalDateTime updDate;


  public String getGkId() {
    return gkId;
  }

  public void setGkId(String gkId) {
    this.gkId = gkId;
  }


  public String getPlatCode() {
    return platCode;
  }

  public void setPlatCode(String platCode) {
    this.platCode = platCode;
  }


  public String getRiskStatus() {
    return riskStatus;
  }

  public void setRiskStatus(String riskStatus) {
    this.riskStatus = riskStatus;
  }


  public String getRiskLevel() {
    return riskLevel;
  }

  public void setRiskLevel(String riskLevel) {
    this.riskLevel = riskLevel;
  }


  public java.time.LocalDate getRiskDate() {
    return riskDate;
  }

  public void setRiskDate(java.time.LocalDate riskDate) {
    this.riskDate = riskDate;
  }


  public String getRiskReason() {
    return riskReason;
  }

  public void setRiskReason(String riskReason) {
    this.riskReason = riskReason;
  }


  public Long getCreateUserId() {
    return createUserId;
  }

  public void setCreateUserId(Long createUserId) {
    this.createUserId = createUserId;
  }


  public java.time.LocalDateTime getCreateDate() {
    return createDate;
  }

  public void setCreateDate(java.time.LocalDateTime createDate) {
    this.createDate = createDate;
  }


  public Long getUpdUserId() {
    return updUserId;
  }

  public void setUpdUserId(Long updUserId) {
    this.updUserId = updUserId;
  }


  public java.time.LocalDateTime getUpdDate() {
    return updDate;
  }

  public void setUpdDate(java.time.LocalDateTime updDate) {
    this.updDate = updDate;
  }

}
