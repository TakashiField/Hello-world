package com.chinatechstar.component.commons.utils;

import com.alibaba.fastjson.JSONObject;
import com.chinatechstar.component.commons.pojo.SendCtyunSmsRequest;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author lixu
 */
public class TianYiSmsUtil {

    public static void main(String[] args) {
        SendCtyunSmsRequest sendCtyunSmsRequest = new SendCtyunSmsRequest();
        sendCtyunSmsRequest.setPhoneNumber("19907766872");
        sendCtyunSmsRequest.setSignName("吉弘川五金商城");
//        sendCtyunSmsRequest.setTemplateCode("SMS64124870510");
        sendCtyunSmsRequest.setTemplateCode("SMS11264434799");
        String code = "123678";
//        sendCtyunSmsRequest.setTemplateParam("{\"code\":\"456789\"}");
        sendCtyunSmsRequest.setTemplateParam("{\"code\":\""+code+"\"}");
        sendSms(sendCtyunSmsRequest);
    }

    public static String sendSms(SendCtyunSmsRequest sendCtyunSmsRequest) {
        // 获取accessKey和securityKey
        String accessKey = "251f420a1bd24435a7c95fbb80d23689";  // 填写控制台->个人中心->用户AccessKey->查看->AccessKey
        String securityKey ="db5a298a3a394a7f8aec5fbed001ad25"; // 填写控制台->个人中心->用户AccessKey->查看->SecurityKey

        // 构造body请求参数
        Map<String, String> params = buildParams(sendCtyunSmsRequest);
        String body = JSONObject.toJSONString(params);
//        String body = JsonTool.serialize(params);
        try {
            // 构造时间戳
            SimpleDateFormat timeFormat = new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'");
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
            Date now = new Date();
            String signatureTime = timeFormat.format(now);
            String signatureDate = dateFormat.format(now);

            // 构造请求流水号
            String uuId = UUID.randomUUID().toString();

            // 构造待签名字符串
            String campHeader = String.format("ctyun-eop-request-id:%s\neop-date:%s\n", uuId, signatureTime);
            // header的key按照26字母进行排序, 以&作为连接符连起来
            URL url = new URL("https://sms-global.ctapi.ctyun.cn/sms/api/v1");
            String query = url.getQuery();
            StringBuilder afterQuery = new StringBuilder();
            if (query != null) {
                String[] param = query.split("&");
                Arrays.sort(param);
                for (String str : param) {
                    if (afterQuery.length() < 1){
                        afterQuery.append(str);
                    }else{
                        afterQuery.append("&").append(str);
                    }
                }
            }

            // 报文原封不动进行sha256摘要
            String calculateContentHash = getSHA256(body);
            String signatureStr = campHeader + "\n" + afterQuery + "\n" + calculateContentHash;

            // 构造签名
            byte[] kTime = hmacSHA256(signatureTime.getBytes(), securityKey.getBytes());
            byte[] kAk = hmacSHA256(accessKey.getBytes(), kTime);
            byte[] kDate = hmacSHA256(signatureDate.getBytes(), kAk);
            String signature = Base64.getEncoder().encodeToString(hmacSHA256(signatureStr.getBytes(StandardCharsets.UTF_8), kDate));

            // 构造请求头
            HttpPost httpPost = new HttpPost(String.valueOf(url));
            httpPost.setHeader("Content-Type", "application/json;charset=UTF-8");
            httpPost.setHeader("ctyun-eop-request-id", uuId);
            httpPost.setHeader("Eop-date", signatureTime);
            String signHeader = String.format("%s Headers=ctyun-eop-request-id;eop-date Signature=%s", accessKey, signature);
            httpPost.setHeader("Eop-Authorization", signHeader);

            httpPost.setEntity(new StringEntity(body, ContentType.create("application/json", "utf-8")));

            HashMap<String, Object> map = new HashMap<>();
            map.put("phone",sendCtyunSmsRequest.getPhoneNumber());
            map.put("url",url);
            map.put("serialNumber",uuId);
            map.put("templateCode",sendCtyunSmsRequest.getTemplateCode());
            map.put("param",sendCtyunSmsRequest.getTemplateParam());
            System.out.println("请求报文：" + JSONObject.toJSONString(map));
            String result = null;
            try (CloseableHttpClient httpClient = HttpClients.createDefault();
                 CloseableHttpResponse response = httpClient.execute(httpPost) ) {
                result = EntityUtils.toString(response.getEntity(), "utf-8");
                System.out.println("返回结果：" + result);
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
            return result;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    /**
     * 构造请求参数
     * @param sendCtyunSmsRequest 请求参数
     * @return Map
     */
    private static Map<String, String> buildParams(SendCtyunSmsRequest sendCtyunSmsRequest) {
        Map<String, String> params = new HashMap<>(16);
        params.put("action", "SendSms");
        params.put("phoneNumber", sendCtyunSmsRequest.getPhoneNumber());
        params.put("signName", sendCtyunSmsRequest.getSignName());
        params.put("templateCode", sendCtyunSmsRequest.getTemplateCode());
        params.put("templateParam", sendCtyunSmsRequest.getTemplateParam());
        params.put("extendCode", sendCtyunSmsRequest.getExtendCode());
        params.put("sessionId", sendCtyunSmsRequest.getSessionId());
        return params;
    }

    private static String toHex(byte[] data) {
        StringBuilder sb = new StringBuilder(data.length * 2);
        byte[] var2 = data;
        int var3 = data.length;
        for (int var4 = 0; var4 < var3; ++var4) {
            byte b = var2[var4];
            String hex = Integer.toHexString(b);
            if (hex.length() == 1) {
                sb.append("0");
            } else if (hex.length() == 8) {
                hex = hex.substring(6);
            }
            sb.append(hex);
        }
        return sb.toString().toLowerCase(Locale.getDefault());
    }

    private static String getSHA256(String text) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(text.getBytes(StandardCharsets.UTF_8));
            return toHex(md.digest());
        } catch (NoSuchAlgorithmException var3) {
            return null;
        }
    }

    private static byte[] hmacSHA256(byte[] data, byte[] key) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(key, "HmacSHA256"));
            return mac.doFinal(data);
        } catch (Exception e) {
            return new byte[0];
        }
    }


    /**
     * 生成数字验证码
     * @param number
     * @return
     */
    public static String getRandomNumCode(int number){
        int codeNum = (int)((Math.random()*9+1)*100000);
        String code = Integer.valueOf(codeNum).toString();
        System.out.println("smsCode:"+code);
        return code;
    }

}
