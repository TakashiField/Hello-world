package com.chinatechstar.component.commons.entity;


import java.time.LocalDateTime;

public class FppChannelParam {

  private String channelCode;
  private String platCode;
  private String paramName;
  private String paramValue;
  private String paramDesc;
  private Long createUserId;
  private LocalDateTime createDate;
  private Long updUserId;
  private LocalDateTime updDate;


  public String getChannelCode() {
    return channelCode;
  }

  public void setChannelCode(String channelCode) {
    this.channelCode = channelCode;
  }


  public String getPlatCode() {
    return platCode;
  }

  public void setPlatCode(String platCode) {
    this.platCode = platCode;
  }


  public String getParamName() {
    return paramName;
  }

  public void setParamName(String paramName) {
    this.paramName = paramName;
  }


  public String getParamValue() {
    return paramValue;
  }

  public void setParamValue(String paramValue) {
    this.paramValue = paramValue;
  }


  public String getParamDesc() {
    return paramDesc;
  }

  public void setParamDesc(String paramDesc) {
    this.paramDesc = paramDesc;
  }


  public Long getCreateUserId() {
    return createUserId;
  }

  public void setCreateUserId(Long createUserId) {
    this.createUserId = createUserId;
  }


  public LocalDateTime getCreateDate() {
    return createDate;
  }

  public void setCreateDate(LocalDateTime createDate) {
    this.createDate = createDate;
  }


  public Long getUpdUserId() {
    return updUserId;
  }

  public void setUpdUserId(Long updUserId) {
    this.updUserId = updUserId;
  }


  public LocalDateTime getUpdDate() {
    return updDate;
  }

  public void setUpdDate(LocalDateTime updDate) {
    this.updDate = updDate;
  }

}
