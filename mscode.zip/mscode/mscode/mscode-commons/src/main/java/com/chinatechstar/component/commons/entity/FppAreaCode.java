package com.chinatechstar.component.commons.entity;


public class FppAreaCode {

  private Long id;
  private Long pId;
  private String areaName;
  private String lvl;


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }


  public Long getPId() {
    return pId;
  }

  public void setPId(Long pId) {
    this.pId = pId;
  }


  public String getAreaName() {
    return areaName;
  }

  public void setAreaName(String areaName) {
    this.areaName = areaName;
  }


  public String getLvl() {
    return lvl;
  }

  public void setLvl(String lvl) {
    this.lvl = lvl;
  }

}
