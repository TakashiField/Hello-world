package com.chinatechstar.component.commons.entity;


import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

public class FppUsers {

  private String gkId;
  private String platCode;
  private String regType;
  private String accountType;
  private String account;
  private String accountName;
  private String regSrc;
  private String preGkId;
  private String password;
  private String telno;
  private String nickName;
  @DateTimeFormat(pattern = "yyyy-MM-dd")
  private java.time.LocalDate birthday;
  private String sex;
  private String email;
  private String logo;
  private String status;
  private String busAccountId;
  private String tpUserId;
  private String openid;
  private String cusMgrId;
  private String regFlag;
  private String backUrl;
  private String acctType;
  private Long regUserId;
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:SS")
  @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:SS")
  private java.time.LocalDateTime regDate;
  private Long updUserId;
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:SS")
  private java.time.LocalDateTime updDate;


  public String getGkId() {
    return gkId;
  }

  public void setGkId(String gkId) {
    this.gkId = gkId;
  }


  public String getPlatCode() {
    return platCode;
  }

  public void setPlatCode(String platCode) {
    this.platCode = platCode;
  }


  public String getRegType() {
    return regType;
  }

  public void setRegType(String regType) {
    this.regType = regType;
  }


  public String getAccount() {
    return account;
  }

  public void setAccount(String account) {
    this.account = account;
  }


  public String getAccountName() {
    return accountName;
  }

  public void setAccountName(String accountName) {
    this.accountName = accountName;
  }


  public String getRegSrc() {
    return regSrc;
  }

  public void setRegSrc(String regSrc) {
    this.regSrc = regSrc;
  }


  public String getPreGkId() {
    return preGkId;
  }

  public void setPreGkId(String preGkId) {
    this.preGkId = preGkId;
  }


  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }


  public String getNickName() {
    return nickName;
  }

  public void setNickName(String nickName) {
    this.nickName = nickName;
  }


  public java.time.LocalDate getBirthday() {
    return birthday;
  }

  public void setBirthday(java.time.LocalDate birthday) {
    this.birthday = birthday;
  }


  public String getSex() {
    return sex;
  }

  public void setSex(String sex) {
    this.sex = sex;
  }


  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }


  public String getLogo() {
    return logo;
  }

  public void setLogo(String logo) {
    this.logo = logo;
  }


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }


  public Long getRegUserId() {
    return regUserId;
  }

  public void setRegUserId(Long regUserId) {
    this.regUserId = regUserId;
  }


  public java.time.LocalDateTime getRegDate() {
    return regDate;
  }

  public void setRegDate(java.time.LocalDateTime regDate) {
    this.regDate = regDate;
  }


  public Long getUpdUserId() {
    return updUserId;
  }

  public void setUpdUserId(Long updUserId) {
    this.updUserId = updUserId;
  }


  public java.time.LocalDateTime getUpdDate() {
    return updDate;
  }

  public void setUpdDate(java.time.LocalDateTime updDate) {
    this.updDate = updDate;
  }


  public String getAccountType() {
    return accountType;
  }

  public void setAccountType(String accountType) {
    this.accountType = accountType;
  }

  public String getTelno() {
    return telno;
  }

  public void setTelno(String telno) {
    this.telno = telno;
  }

  public String getBusAccountId() {
    return busAccountId;
  }

  public void setBusAccountId(String busAccountId) {
    this.busAccountId = busAccountId;
  }

  public String getTpUserId() {
    return tpUserId;
  }

  public void setTpUserId(String tpUserId) {
    this.tpUserId = tpUserId;
  }

  public String getOpenid() {
    return openid;
  }

  public void setOpenid(String openid) {
    this.openid = openid;
  }

  public String getCusMgrId() {
    return cusMgrId;
  }

  public void setCusMgrId(String cusMgrId) {
    this.cusMgrId = cusMgrId;
  }

  public String getRegFlag() {
    return regFlag;
  }

  public void setRegFlag(String regFlag) {
    this.regFlag = regFlag;
  }

  public String getBackUrl() {
    return backUrl;
  }

  public void setBackUrl(String backUrl) {
    this.backUrl = backUrl;
  }

  public String getAcctType() {
    return acctType;
  }

  public void setAcctType(String acctType) {
    this.acctType = acctType;
  }
}
