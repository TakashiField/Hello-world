package com.chinatechstar.component.commons.result;

import org.apache.poi.ss.formula.functions.T;

import java.io.Serializable;

/**
 * @author lixu
 */
public class PayGatewayResult<T> implements Serializable {
    private static final long serialVersionUID = -1363110948594521401L;

    private Head head;// 请求头
    private T data;// 数据 NOSONAR

    public PayGatewayResult() {
        super();
    }

    public PayGatewayResult(Head head, T data) {
        super();
        this.head = head;
        this.data = data;
    }

    public Head getHead() {
        return head;
    }

    public void setHead(Head head) {
        this.head = head;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
