package com.chinatechstar.component.commons.validator;

/**
 * 编辑详细信息验证器
 * 
 * @版权所有 广东国星科技有限公司 www.mscodecloud.com
 */
public interface UpdateDetailValidator {

}
