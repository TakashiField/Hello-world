package com.chinatechstar.component.commons.utils;
/*
 * 
 *  Copyright 2012, China UnionPay Co., Ltd.  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF CHINA UNIONPAY CO.,
 *  LTD.  THE CONTENTS OF THIS FILE MAY NOT BE DISCLOSED TO THIRD
 *  PARTIES, COPIED OR DUPLICATED IN ANY FORM, IN WHOLE OR IN PART,
 *  WITHOUT THE PRIOR WRITTEN PERMISSION OF CHINA UNIONPAY CO., LTD.
 *  
 *   $Id: StringUtils.java,v 1.4 2018/01/30 12:34:05  Exp $
 *
 *  Function:
 *
 *    字符串工具类
 *
 *  Edit History:
 *
 */

import com.alibaba.fastjson.JSON;
import org.apache.commons.lang.ArrayUtils;
import org.apache.http.message.BasicNameValuePair;

import java.io.*;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 字符串工具类
 * 
 * @author szwang
 * @version
 * @since
 * 
 */
public abstract class StringUtils extends org.apache.commons.lang.StringUtils {

	/** 空字符串 */
	private static final String NULL_STRING = "";
	final static char[] digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g',
			'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };

	public static String formatMessage(String msg, Object... args) {
		if (isBlank(msg) || ArrayUtils.getLength(args) == 0) {
			return msg;
		} else {
			return MessageFormat.format(msg, args);
		}
	}

	/**
	 * 判断字符串为null或恐字符串
	 * 
	 * @since
	 * @param str
	 * @return
	 */
	public static boolean isEmpty(String str) {
		return str == null || str.trim().equals("");
	}

	/**
	 * 获取非null字符串
	 * 
	 * @since
	 * @param str
	 * @return
	 */
	public static String nullSafeGet(String str) {
		return str == null ? NULL_STRING : str;
	}

	/**
	 * 判断有值且相等
	 * 
	 * @since
	 * @param str1
	 * @param str2
	 * @return
	 */
	public static boolean notNullEqual(String str1, String str2) {
		if (isEmpty(str1) || isEmpty(str2)) {
			return false;
		}

		return str1.equals(str2);
	}

	/**
	 * 判断是否包含
	 * 
	 * @since
	 * @param ary
	 * @param s
	 * @return
	 */
	public static boolean contains(String[] ary, String s) {
		if (ary == null || ary.length == 0 || s == null) {
			return false;
		}

		for (String s1 : ary) {
			if (s1.equals(s)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 获取String
	 * 
	 * @since
	 * @param obj
	 * @return
	 */
	public static String getString(Object obj) {
		// TODO 根据类型分别处理
		if (obj == null) {
			return NULL_STRING;
		}
		if (obj instanceof String) {
			return (String) obj;
		}
		if (obj instanceof Number) {
			return obj.toString();
		}
		if (obj instanceof String[]) {
			String[] tmp = (String[]) obj;
			String result = NULL_STRING;
			for (String i : tmp) {
				result += i;
			}
			return result;
		}
		return obj.toString();
	}

	/**
	 * 判断是否为真
	 * 
	 * @since
	 * @param s
	 * @return
	 */
	public static boolean isTrue(String s) {
		if (s == null) {
			return false;
		}

		s = s.trim();
		return s.equalsIgnoreCase("true") || s.equalsIgnoreCase("t") || s.equals("1");
	}

	/**
	 * 判断是否为真
	 * 
	 * @since
	 * @param ch
	 * @return
	 */
	public static boolean isTrue(final char ch) {
		return ch == '1' || ch == 't' || ch == 'T';
	}

	/**
	 * 字符串转数组
	 * 
	 * @since
	 * @param s
	 * @param seperator
	 * @return
	 */
	public static String[] toArray(String s, String seperator) {
		return s.split(seperator);
	}

	/**
	 * 字符串数组转字符串
	 * 
	 * @since
	 * @param ary
	 * @param seperator
	 * @return
	 */
	public static String toString(int[] ary, String seperator) {
		if (ary == null) {
			return "";
		}

		int l = ary.length;
		if (l == 0) {
			return "";
		}

		StringBuilder sb = new StringBuilder(ary[0] + "");
		for (int i = 1; i < l; i++) {
			sb.append(seperator).append(ary[i] + "");
		}
		return sb.toString();
	}

	/**
	 * 字符串数组转字符串
	 * 
	 * @since
	 * @param ary
	 * @param seperator
	 * @return
	 */
	public static String toString(String[] ary, String seperator) {
		if (ary == null) {
			return "";
		}

		int l = ary.length;
		if (l == 0) {
			return "";
		}

		StringBuilder sb = new StringBuilder(ary[0]);
		for (int i = 1; i < l; i++) {
			sb.append(seperator).append(ary[i]);
		}
		return sb.toString();
	}

	/**
	 * 字符串数组转字符串
	 * 
	 * @since
	 * @param ary
	 * @param seperator
	 * @param wrapStr
	 * @return
	 */
	public static String toString(String[] ary, String seperator, String wrapStr) {
		if (wrapStr == null) {
			return toString(ary, seperator);
		}

		int l = ary.length;
		if (l == 0) {
			return "";
		}

		StringBuilder sb = new StringBuilder(wrapStr).append(ary[0]).append(wrapStr);
		for (int i = 1; i < l; i++) {
			sb.append(seperator).append(wrapStr).append(ary[i]).append(wrapStr);
		}
		return sb.toString();
	}

	/**
	 * 字符串集合转字符串
	 * 
	 * @since
	 * @param strs
	 * @param seperator
	 */
	public static String toString(Collection<String> strs, String seperator) {
		if (strs == null) {
			return null;
		}

		boolean first = true;
		StringBuilder sb = new StringBuilder();
		for (String s : strs) {
			if (first) {
				first = false;
			} else {
				sb.append(seperator);
			}

			sb.append(s);
		}
		return sb.toString();
	}

	/**
	 * 字符串集合转字符串
	 * 
	 * @since
	 * @param strs
	 * @param seperator
	 * @param wrapStr
	 */
	public static String toString(Collection<String> strs, String seperator, String wrapStr) {
		if (wrapStr == null) {
			return toString(strs, seperator);
		}

		boolean first = true;
		StringBuilder sb = new StringBuilder();
		for (String s : strs) {
			if (first) {
				first = false;
			} else {
				sb.append(seperator);
			}

			sb.append(wrapStr).append(s).append(wrapStr);
		}
		return sb.toString();
	}

	/**
	 * 字符串数组转列表
	 * 
	 * @since
	 * @param strAry
	 * @return
	 */
	public static List<String> toList(String[] strAry) {
		return Arrays.asList(strAry);
	}

	/**
	 * 字符串比较
	 * 
	 * @since
	 * @param str1
	 * @param str2
	 * @return
	 */
	public static int compare(String str1, String str2) {
		if (str1 == null) {
			return str2 == null ? 0 : -1;
		}

		return str2 == null ? 1 : str1.compareTo(str2);
	}

	/**
	 * 分割
	 * 
	 * @since
	 * @param str
	 * @param sepreator
	 * @return
	 */
	public static String[] split(String str, String sepreator) {
		if (str == null) {
			return null;
		}

		return str.split(sepreator);
	}

	/**
	 * 字符串截取
	 * 
	 * @param source
	 * @param beginIndex
	 * @return
	 * @since 2017年3月30日
	 */
	public static String subString(String source, int beginIndex) {
		return source == null ? null : subString(source, beginIndex, source.length());
	}

	/**
	 * 字符串截取。 防止JDK16内存泄漏
	 * 
	 * @param source
	 * @param beginIndex
	 * @param endIndex
	 * @return
	 * @since 2017年3月30日
	 */
	public static String subString(String source, int beginIndex, int endIndex) {
		return source == null ? null : new String(source.substring(beginIndex, endIndex));
	}

	/**
	 * 判断是否是正整数
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isPosInt(String str) {
		if (str == null) {
			return false;
		}

		Pattern pattern = Pattern.compile("[0-9]+");
		return pattern.matcher(str).matches();
	}

	/**
	 * 判断是否是正double数字类型
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isPosDouble(String str) {
		if (str == null) {
			return false;
		}

		Pattern pattern = Pattern.compile("[+]?([1-9]\\d*|0)(\\.\\d+)?");
		return pattern.matcher(str).matches();
	}

	/**
	 * 判断是否是YYYYMMDD格式
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isYYYYMMDD(String str) {
		if (str == null) {
			return false;
		}

		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		try {
			df.setLenient(false);
			df.parse(str);
			return true;
		} catch (ParseException e) {
			return false;
		}
	}

	/**
	 * 是否合法的主键
	 * 
	 * @param key
	 * @return
	 */
	public static boolean isValidKey(String key) {
		return key == null ? false : !key.contains("'");
	}

	/**
	 * 编码html字符
	 * 
	 * @param str
	 * @return
	 */
	public static String encodeForHTML(String str) {
		StringBuilder sb = new StringBuilder();
		if (str != null) {
			for (int i = 0; i < str.length(); i++) {
				char c = str.charAt(i);
				switch (c) {
				case '&':
					sb.append("&amp;");
					break;
				case '<':
					sb.append("&lt;");
					break;
				case '>':
					sb.append("&gt;");
					break;
				case '"':
					sb.append("&quot;");
					break;
				case '\'':
					sb.append("&#x27;");
					break;
				case '/':
					sb.append("&#x2f;");
					break;
				default:
					sb.append(c);
				}
			}
		}
		return sb.toString();
	}

	/**
	 * 编码带换行的html字符
	 * 
	 * @param str
	 * @return
	 */
	public static String encodeForHTMLWithBR(String str) {
		if (str == null) {
			return "";
		}

		String[] arrMsg = str.split("<br\\s*/?>");
		for (int i = 0; i < arrMsg.length; i++) {
			arrMsg[i] = encodeForHTML(arrMsg[i]);
		}
		return toString(arrMsg, "<br>");
	}

	@SuppressWarnings("rawtypes")
	public static String convMapToString(Map maps) {
		StringBuilder sb = new StringBuilder();
		for (Object ob : maps.keySet()) {
			sb.append("\nkey:" + ob);
		}
		for (Object ob : maps.keySet()) {
			sb.append("[" + maps + "]:" + maps.get(ob) + "\n");
		}

		return sb.toString();
	}

	/**
	 * 将map转成key=val&key=val的形式
	 * 
	 * @param map
	 * @return
	 */
	public static String convMapToResultString(Map<String, String> map) {

		if (map == null) {
			return null;
		}
		int len = map.size();
		StringBuffer sb = new StringBuffer();
		for (Object ob : map.keySet()) {
			len--;
			if (len == 0) {
				sb.append(ob + "=" + map.get(ob));
			} else {
				sb.append(ob + "=" + map.get(ob) + "&");
			}
		}
		return sb.toString();
	}

	/**
	 * 将HEX字符串转为四位的0/1字符串
	 * 
	 * @param hex
	 * @return
	 */
	public static String convHexCharToBinStr(char hex) {
		char hexUpper = Character.toUpperCase(hex);
		switch (hexUpper) {
		case '0':
			return "0000";
		case '1':
			return "0001";
		case '2':
			return "0010";
		case '3':
			return "0011";
		case '4':
			return "0100";
		case '5':
			return "0101";
		case '6':
			return "0110";
		case '7':
			return "0111";
		case '8':
			return "1000";
		case '9':
			return "1001";
		case 'A':
			return "1010";
		case 'B':
			return "1011";
		case 'C':
			return "1100";
		case 'D':
			return "1101";
		case 'E':
			return "1110";
		case 'F':
			return "1111";
		default:
			return "0000";
		}
	}

	/**
	 * 将HEX二进制值转为八位的0/1字符串
	 * 
	 * @param val
	 * @return
	 */
	public static String convHexByteToBinStr(byte val) {
		char[] buf = new char[8];
		int charPos = 8;
		int radix = 1 << 1;
		int mask = radix - 1;
		do {
			buf[--charPos] = digits[val & mask];
			val >>>= 1;
		} while (charPos > 0);
		return new String(buf);
	}

	/**
	 * 将HEX字符串转为四倍长的0/1字符串
	 * 
	 * @param hexStr
	 * @return
	 */
	public static String convHexStrToBinStr(String hexStr) {

		StringBuilder sb = new StringBuilder();
		for (char ch : hexStr.toCharArray()) {
			sb.append(convHexCharToBinStr(ch));
		}
		return sb.toString();
	}

	/**
	 * HEX字符转化为一个byte
	 * 
	 * @param c
	 * @return
	 */
	public static byte convHexCharToByte(char leftChar, char rightChar) {
		byte leftByte = (byte) "0123456789ABCDEF".indexOf(leftChar);
		byte rightByte = (byte) "0123456789ABCDEF".indexOf(rightChar);
		return (byte) ((leftByte << 4) | rightByte);
	}

	/**
	 * 将hex字符串转化为byte,长度缩短一倍
	 * 
	 * @param hexStr
	 * @return
	 */
	public static byte[] convHexStrToBytes(String hexStr) {

		if (hexStr == null || hexStr.equals("")) {
			return null;
		}
		hexStr = hexStr.toUpperCase();
		int length = hexStr.length() / 2;
		char[] hexChars = hexStr.toCharArray();
		byte[] retBytes = new byte[length];

		for (int i = 0; i < length; i++) {
			int pos = i * 2;

			retBytes[i] = convHexCharToByte(hexChars[pos], hexChars[pos + 1]);
		}

		return retBytes;
	}

	/**
	 * 将HEX byte[]转为四倍长的0/1字符串
	 * 
	 * @param hexStr
	 * @return
	 */
	public static String convHexByteArrayToBinStr(byte[] hexArray) {

		StringBuilder sb = new StringBuilder();
		for (byte ch : hexArray) {
			sb.append(convHexByteToBinStr(ch));
		}
		return sb.toString();
	}

	/**
	 * byte转16进制字符串
	 * 
	 * @param bb
	 * @return
	 */
	public static String convHexByteArrayToStr(byte[] bb) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < bb.length; i++) {
			String hex = Integer.toHexString(bb[i] & 0xFF).toUpperCase();
			if (hex.length() == 1) {
				hex = '0' + hex;
			}
			sb.append(hex);
		}
		return sb.toString();
	}

	/***
	 * 将0/1字符串转换为LIST，LIST中为该位为1的位值，从1开始。
	 * 
	 * @param binStr
	 * @return
	 */
	public static List<Integer> convBinToIndexList(String binStr) {
		List<Integer> buf = new LinkedList<Integer>();
		char[] charSet = binStr.toCharArray();
		for (int index = 0; index < charSet.length; index++) {
			if (charSet[index] == '1') {
				buf.add(index + 1);
			}
		}

		return buf;
	}

	/***
	 * 将HEX字符串转换为LIST，LIST中为该位为1的位值，从1开始。
	 * 
	 * @param hexStr
	 * @return
	 */
	public static List<Integer> convHexStrToIndexList(String hexStr) {

		return convBinToIndexList(convHexStrToBinStr(hexStr));
	}

	/***
	 * 将HEX字符串转换为LIST，LIST中为该位为1的位值，从1开始。
	 * 
	 * @param hexStr
	 * @return
	 */
	public static List<Integer> convHexByteArrayToIndexList(byte[] hexArray) {

		return convBinToIndexList(convHexByteArrayToBinStr(hexArray));
	}

	/***
	 * 输入整数，获取字长串长度
	 * 
	 * @since
	 * @param value
	 * @return
	 */
	public static int calIntegerLen(int value) {
		return (value < 10 ? 1
				: (value < 100 ? 2
						: (value < 1000 ? 3
								: (value < 10000 ? 4
										: (value < 100000 ? 5
												: (value < 1000000 ? 6
														: (value < 10000000 ? 7 : (value < 100000000 ? 8 : (9)))))))));
	}

	/****
	 * 格式化整数为STRING
	 * 
	 * @since
	 * @param value
	 * @param len
	 * @return
	 */
	public static String formatInteger(int value, int len) {
		int valueLen = calIntegerLen(value);
		if (valueLen > len) {
			return null;
		}
		int zeroNum = len - valueLen;
		char[] zeros = new char[zeroNum];
		for (int i = 0; i < zeroNum; i++) {
			zeros[i] = '0';
		}
		String zeroString = new String(zeros);
		return zeroString + len;
	}

	/****
	 * 格式化整数为BYTE[]
	 * 
	 * @since
	 * @param value
	 * @param len
	 * @return
	 */
	public static byte[] formatIntegerToByte(int value, int len) {
		int valueLen = calIntegerLen(value);
		if (valueLen > len) {
			return null;
		}
		int zeroNum = len - valueLen;
		byte[] zeros = new byte[zeroNum + valueLen];
		for (int i = 0; i < zeroNum; i++) {
			zeros[i] = '0';
		}
		char[] intChar = (value + "").toString().toCharArray();
		for (int i = 0; i < valueLen; i++) {
			zeros[i + zeroNum] = (byte) intChar[i];
		}
		return zeros;

	}

	/**
	 * 截取字符串首位空格
	 * 
	 * @since
	 * @param str
	 * @return
	 */
	public static String trim(String str) {
		return str == null ? "" : str.trim();
	}

	/**
	 * 判断对象为空
	 * 
	 * @since
	 * @param str
	 * @return
	 */
	public static boolean isEmpty(Object msg) {
		if (msg instanceof String)
			return isEmpty((String) msg);
		return msg == null;
	}

	public static String concat(Object... pieces) {
		StringBuilder sb = new StringBuilder();
		for (Object piece : pieces) {
			sb.append(isEmpty(piece) ? "" : piece);
		}
		return sb.toString();
	}

	private static final char SEPARATOR = '_';

	/**
	 * 驼峰转下划线
	 * 
	 * @param s
	 * @return
	 */
	public static String toUnderlineName(String s) {
		if (s == null) {
			return null;
		}

		StringBuilder sb = new StringBuilder();
		boolean upperCase = false;
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);

			boolean nextUpperCase = true;

			if (i < (s.length() - 1)) {
				nextUpperCase = Character.isUpperCase(s.charAt(i + 1));
			}

			if ((i >= 0) && Character.isUpperCase(c)) {
				if (!upperCase || !nextUpperCase) {
					if (i > 0)
						sb.append(SEPARATOR);
				}
				upperCase = true;
			} else {
				upperCase = false;
			}

			sb.append(Character.toLowerCase(c));
		}

		return sb.toString();
	}

	/**
	 * 下划线转驼峰
	 * 
	 * @param s
	 * @return
	 */
	public static String toCamelCase(String s) {
		if (s == null) {
			return null;
		}

		s = s.toLowerCase();

		StringBuilder sb = new StringBuilder(s.length());
		boolean upperCase = false;
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);

			if (c == SEPARATOR) {
				upperCase = true;
			} else if (upperCase) {
				sb.append(Character.toUpperCase(c));
				upperCase = false;
			} else {
				sb.append(c);
			}
		}

		return sb.toString();
	}

	public static String toCapitalizeCamelCase(String s) {
		if (s == null) {
			return null;
		}
		s = toCamelCase(s);
		return s.substring(0, 1).toUpperCase() + s.substring(1);
	}

	/** short 类型转化为byte数组函数 */
	public static byte[] shortToByteArray(short n) {
		byte[] b = new byte[2];
		b[1] = (byte) (n & 0xff);
		b[0] = (byte) (n >> 8 & 0xff);
		return b;
	}

	public static byte byteAscToBcd(byte asc) {
		byte bcd;

		if ((asc >= '0') && (asc <= '9'))
			bcd = (byte) (asc - '0');
		else if ((asc >= 'A') && (asc <= 'F'))
			bcd = (byte) (asc - 'A' + 10);
		else if ((asc >= 'a') && (asc <= 'f'))
			bcd = (byte) (asc - 'a' + 10);
		else
			bcd = (byte) (asc - 48);
		return bcd;
	}

	public static byte[] bytesAscToBcd(byte[] ascii, int asc_len) {
		byte[] bcd = new byte[(asc_len + 1) / 2];
		int j = 0;
		for (int i = 0; i < (asc_len + 1) / 2; i++) {
			bcd[i] = byteAscToBcd(ascii[j++]);
			bcd[i] = (byte) (((j >= asc_len) ? 0x00 : byteAscToBcd(ascii[j++])) + (bcd[i] << 4));
		}
		return bcd;
	}

	/**
	 * 匹配第一个{}，返回{}中间内容
	 * 
	 * @param source
	 * @return
	 * @since 2017年3月15日
	 */
	public static String matchBraces(String source) {
		if (source == null) {
			return null;
		}
		Pattern r = Pattern.compile("(\\{)([\\s|\\w|\\-|\\+|,|\\||:|/|%|\\.]*)(\\})");
		Matcher m = r.matcher(source);
		if (m.find()) {
			return m.group(2);
		}
		return null;
	}

	/**
	 * 匹配所有{}，返回所有{}中内容
	 * 
	 * @param source
	 * @return
	 * @since 2017年3月15日
	 */
	public static List<String> matchAllBraces(String source) {
		if (source == null) {
			return null;
		}
		Pattern r = Pattern.compile("(\\{)([\\s|\\w|\\-|\\+|,|\\||:|/|%|\\.]*)(\\})");
		Matcher m = r.matcher(source);
		List<String> result = new ArrayList<String>();
		while (m.find()) {
			result.add(m.group(2));
		}
		return result;
	}

	/**
	 * 将字符串转化为二维数组
	 * 
	 * @param s
	 * @return arr[][]
	 */
	public static String[][] getErArray(String s) {
		String[] s1 = s.replaceAll("],", "]@").split("@");
		System.out.println("s1:" + s1);
		String[][] arr = new String[s1.length][];
		for (int i = 0; i < arr.length; i++) {
			String[] s2 = s1[i].split(",");
			arr[i] = new String[s2.length];
			for (int j = 0; j < s2.length; j++) {
				arr[i][j] = s2[j].replaceAll("\\[|\\]", "");
				arr[i][j] = arr[i][j].replace("\\\"", "@");// 将转译字符\",转换成@
				arr[i][j] = arr[i][j].replaceAll("\"", "");// 去掉所有"
				arr[i][j] = arr[i][j].replaceAll("@", "\"");// 将@转为"
			}
		}
		return arr;
	}

	/**
	 * 替换字符串source第一个{}和值替换成指定的值。
	 * 
	 * @param source
	 * @param replace
	 * @return
	 * @since 2017年3月15日
	 */
	public static String replaceBraces(String source, String replace) {
		if (source == null) {
			return null;
		}
		Pattern r = Pattern.compile("(\\{)(\\w*)(\\})");
		Matcher m = r.matcher(source);
		return m.replaceFirst(replace);
	}

	/**
	 * 替换字符串source中包括{origin}的内容为replace
	 * 
	 * @param source
	 * @param origin
	 * @param replace
	 * @return
	 * @since 2017年3月15日
	 */
	public static String replaceBraces(String source, String origin, String replace) {
		if (source == null) {
			return null;
		}
		Pattern r = Pattern.compile("(\\{)(" + origin + ")(\\})");
		Matcher m = r.matcher(source);
		return m.replaceAll(replace);
	}

	/**
	 * 解析表达式，只支持一个参数，如func(var)，返回[func,var]
	 * 
	 * @param expression
	 * @return
	 * @since 2017年3月15日
	 */
	public static String[] parseExpression(String expression) {
		if (expression == null) {
			return null;
		}
		Pattern r = Pattern.compile("(\\w*)\\(([\\w|\\-|\\+|,|\\||:]*)\\)");
		Matcher m = r.matcher(expression);
		String[] result = null;
		if (m.find()) {
			result = new String[2];
			result[0] = m.group(1);
			result[1] = m.group(2);
		} else {
			result = new String[2];
			result[0] = expression;
			result[1] = null;
		}
		return result;
	}

	/**
	 * 解析多个逗号分隔的表达式，每个表达式返回一个List<String><br>
	 * 如func1(aaa,bbb),func2(bbb),func3()<br>
	 * 则返回三个List<String> <br>
	 * [func1,aaa,bbb]<br>
	 * [func2,bbbb]<br>
	 * [func3]<br>
	 * 
	 * @param expression
	 * @return
	 * @since 2017年3月15日
	 */
	public static List<List<String>> parseMultiExpressionWithParams(String expression) {
		if (expression == null) {
			return null;
		}
		List<List<String>> result = new LinkedList<List<String>>();
		Pattern r = Pattern.compile("(\\w*)\\(([\\w|\\-|\\+|,|\\||:]*)\\)");
		Pattern inr = Pattern.compile("([\\w|\\-|\\+|\\||:]+)(,)*");
		Matcher m = r.matcher(expression);
		Matcher inm = null;
		while (m.find()) {
			List<String> oneResult = new LinkedList<String>();
			oneResult.add(m.group(1));
			inm = inr.matcher(m.group(2));
			while (inm.find()) {
				oneResult.add(inm.group(1));
			}
			result.add(oneResult);
		}
		return result;
	}

	public static void main(String[] args) {
		// List<String> ss =
		// matchAllBraces("({logNo.hostEle.det.val} / 6 ) % 2 + 1");
		// String ss = replaceBraces("tbl_clxcvsdf{hostEle}SDFSDFSDF","DDDDD");
		// System.out.println(ss);
//		List<List<String>> ss = parseMultiExpressionWithParams("func1(aaa,bbb),func2(bbb),func3()");
//		for (List<String> l : ss) {
//			System.out.println(l);
//		}
		// System.out.println(ss);
		// String jsonData =
		// "{\"person\":{\"name\":\"www\",\"age\":29},\"loc\":\"sh\"}";
		// String jsonData = "{\"person\":\"name\",\"loc\":\"sh\"}";
		// Map m = jsonToObj(jsonData, Map.class, mapClass);
		// System.out.println(m);
		// List<List<String>> rr =
		// parseMultiExpressionWithParams("subStr(df(),dateTime(yyyyMMddHHmmss,HH:mm:ss),dropdown(succSt)");
		//
		// for (List<String> l : rr) {
		// for (String s : l) {
		// System.out.println(s);
		// }
		// }
		// rr =
		// parseMultiExpressionWithParams("subStr(df(),dateTime(yyyyMMddHHmmss,HH:mm:ss),dropdown(succSt)");
		//
		// for (List<String> l : rr) {
		// for (String s : l) {
		// System.out.println(s);
		// }
		// }
		// rr =
		// parseMultiExpressionWithParams("dateTime(yyyyMMddHHmmss,HH:mm:ss),mfff,subStr(0,1),dropdown(succSt)");
		//
		// for (List<String> l : rr) {
		// for (String s : l) {
		// System.out.println(s);
		// }
		// }

		/*
		 * Map<String, String> map = new HashMap<String, String>(); map.put("key1",
		 * "123"); map.put("key2", "456");
		 * 
		 * String rlt = convMapToResultString(map); System.out.println(rlt);
		 */
//		int len = map.size();
//		StringBuffer sb = new StringBuffer();
//		for(Object ob: map.keySet()){
//			len --;
//			if(len == 0){
//				sb.append(ob+"="+map.get(ob));
//			}else{
//			sb.append(ob+"="+map.get(ob)+"&");
//			}
//			
//		}
//		
//		System.out.println(sb.toString());
//		System.out.println(map.toString());
//		
//		String t = map.toString();
//		
//		t.toCharArray();
//		
//		
//		
//		List<String> list =  new LinkedList<String>();
//		list.add("123");
//		list.add("456");
//		StringUtils.toString(list, "&");
//		System.out.println(StringUtils.toString(list, "&"));
		/*
		 * Map<String,String> map=new HashMap<String,String>();
		 * System.out.println("map.size()1:"+map.size()); for(int i=0;i<5000;i++) {
		 * String a=getOrderNo("INO"); System.out.println("a:"+a); map.put(a, a); }
		 * System.out.println("map.size()2:"+map.size()); long timestamp=new
		 * Date().getTime();//结果：1280977330748
		 * System.out.println("timestamp:"+timestamp);
		 */
	}

	private static void putKeyValueToMap(StringBuilder temp, boolean isKey, String key, Map<String, String> map)
			throws UnsupportedEncodingException {
		if (isKey) {
			key = temp.toString();
			if (key.length() == 0) {
				throw new RuntimeException("QString format illegal");
			}
			map.put(key, "");
		} else {
			if (key.length() == 0) {
				throw new RuntimeException("QString format illegal");
			}
			map.put(key, temp.toString());
		}
	}

	/**
	 * 解析应答字符串，生成应答要素
	 * 
	 * @param str 需要解析的字符串
	 * @return 解析的结果map
	 * @throws UnsupportedEncodingException
	 */
	public static Map<String, String> parseQString(String str) throws UnsupportedEncodingException {

		Map<String, String> map = new HashMap<String, String>();
		int len = str.length();
		StringBuilder temp = new StringBuilder();
		char curChar;
		String key = null;
		boolean isKey = true;
		boolean isOpen = false;// 值里有嵌套
		char openName = 0;
		if (len > 0) {
			for (int i = 0; i < len; i++) {// 遍历整个带解析的字符串
				curChar = str.charAt(i);// 取当前字符
				if (isKey) {// 如果当前生成的是key

					if (curChar == '=') {// 如果读取到=分隔符
						key = temp.toString();
						temp.setLength(0);
						isKey = false;
					} else {
						temp.append(curChar);
					}
				} else {// 如果当前生成的是value
					if (isOpen) {
						if (curChar == openName) {
							isOpen = false;
						}

					} else {// 如果没开启嵌套
						if (curChar == '{') {// 如果碰到，就开启嵌套
							isOpen = true;
							openName = '}';
						}
						if (curChar == '[') {
							isOpen = true;
							openName = ']';
						}
					}
					if (curChar == '&' && !isOpen) {// 如果读取到&分割符,同时这个分割符不是值域，这时将map里添加
						putKeyValueToMap(temp, isKey, key, map);
						temp.setLength(0);
						isKey = true;
					} else {
						temp.append(curChar);
					}
				}

			}
			putKeyValueToMap(temp, isKey, key, map);
		}
		return map;
	}

	/**
	 * 将形如key=value&key=value的字符串转换为相应的Map对象，如果首位有大括号{}，则去掉
	 * 
	 * @param result
	 * @return
	 */
	public static Map<String, String> convertResultStringToMap(String result) {
		Map<String, String> map = null;
		try {

			if (StringUtils.isNotBlank(result)) {
				if (result.startsWith("{") && result.endsWith("}")) {
					result = result.substring(1, result.length() - 1);
				}
				map = parseQString(result);
			}

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return map;
	}

	/**
	 * 字符串编码转换的实现方法
	 * 
	 * @param str        待转换编码的字符串
	 * @param newCharset 目标编码
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static String changeCharset(String str, String newCharset) throws UnsupportedEncodingException {
		if (str != null) {
			// 用默认字符编码解码字符串。
			byte[] bs = str.getBytes();
			// 用新的字符编码生成字符串
			return new String(bs, newCharset);
		}
		return null;
	}

	/**
	 * ID String数组 转 Long数组 @param inList 待转换字符串数组 @return @throws
	 */
	public static List<Long> stringtoLongArray(String ids) {
		String[] id_array = ids.split(",");
		List<Long> result = new ArrayList<Long>();

		for (int i = 0; i < id_array.length; i++) {
			result.add(Long.parseLong(id_array[i]));
		}

		return result;
	}

	// String [1,2,3,4]转list
	public static List<Long> stringToList(String str) {
		str = str.replaceAll("\\[|\\]", "");
		return stringtoLongArray(str);
	}

	// 根据指定前后缀生成字符串
	public static String getOrderNo(final String prefix) {// ,final String suffix
		SimpleDateFormat sfDate = new SimpleDateFormat("yyMMddHHmmsss");
		String MI = "";
		String strDate = "";
		String random = "";
		synchronized (sfDate) {
			// 格式化当前时间
			strDate = sfDate.format(new Date());
			Calendar CD = Calendar.getInstance();
			MI = CD.get(Calendar.MILLISECOND) + "";
			if (MI.length() < 3) {
				Random randomT = new Random();
				MI = (randomT.nextInt(999 - 100 + 1) + 100) + "";
			}
			// 得到17位时间如：20170411094039080
			// System.out.println("时间17位：" + strDate);
			// 为了防止高并发重复,再获取3个随机数
			random = getRandom620(4);
		}
		return prefix + strDate + MI + random;
	}

	/**
	 * 获取6-10 的随机位数数字
	 * 
	 * @param length 想要生成的长度
	 * @return result
	 */
	public static String getRandom620(Integer length) {
		String result = "";
		Random rand = new Random();
		int n = 20;
		if (null != length && length > 0) {
			n = length;
		}
		int randInt = 0;
		for (int i = 0; i < n; i++) {
			randInt = rand.nextInt(10);
			result += randInt;
		}
		return result;
	}

	// List类型数据深拷贝
	public static <T> List<T> deepCopy(List<T> src) throws IOException, ClassNotFoundException {

		ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
		ObjectOutputStream out = new ObjectOutputStream(byteOut);
		out.writeObject(src);

		ByteArrayInputStream byteIn = new ByteArrayInputStream(byteOut.toByteArray());
		ObjectInputStream in = new ObjectInputStream(byteIn);
		@SuppressWarnings("unchecked")
		List<T> dest = (List<T>) in.readObject();
		return dest;
	}

	// json字符串转List<Map<String, Object>>
	public static List<Map<String, Object>> toListMap(String json) {
		List<Object> list = JSON.parseArray(json);

		List<Map<String, Object>> listw = new ArrayList<Map<String, Object>>();
		for (Object object : list) {
			Map<String, Object> ageMap = new HashMap<String, Object>();
			Map<String, Object> ret = (Map<String, Object>) object;// 取出list里面的值转为map
			listw.add(ret);
		}
		return listw;

	}

	// map转NameValuePair
	public static BasicNameValuePair[] convertMap2NameValuePairs(Map<String, String> data) {
		return data.entrySet().stream().map(entry -> new BasicNameValuePair(entry.getKey(), entry.getValue()))
				.toArray(BasicNameValuePair[]::new);
	}
}
