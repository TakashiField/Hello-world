// This file is auto-generated, don't edit it. Thanks.
package com.chinatechstar.component.commons.utils;


import com.alibaba.fastjson.JSONObject;
import com.aliyun.dysmsapi20170525.models.SendSmsResponse;
import com.aliyun.tea.TeaException;
import com.aliyun.teautil.models.RuntimeOptions;

public class ALiYunSmsUtil {

    /**
     * 使用AK&SK初始化账号Client
     * @param accessKeyId
     * @param accessKeySecret
     * @return Client
     * @throws Exception
     */
    public static com.aliyun.dysmsapi20170525.Client createClient(String accessKeyId, String accessKeySecret) throws Exception {
        com.aliyun.teaopenapi.models.Config config = new com.aliyun.teaopenapi.models.Config()
                // 必填，您的 AccessKey ID
                .setAccessKeyId(accessKeyId)
                // 必填，您的 AccessKey Secret
                .setAccessKeySecret(accessKeySecret);
        // Endpoint 请参考 https://api.aliyun.com/product/Dysmsapi
        config.endpoint = "dysmsapi.aliyuncs.com";
        return new com.aliyun.dysmsapi20170525.Client(config);
    }


    public static JSONObject sendSms(String accessKeyId, String accessKeySecret) throws Exception {
        String randomNumCode = ALiYunSmsUtil.getRandomNumCode(6);
        System.out.println(System.getenv("ALIBABA_CLOUD_ACCESS_KEY_ID"));
        System.out.println(System.getenv("ALIBABA_CLOUD_ACCESS_KEY_SECRET"));
        com.aliyun.dysmsapi20170525.Client client = ALiYunSmsUtil.createClient("LTAI5tDHLGfaPWLPtstv4y5s", "OCliJpIb53s1nGEAeAgqbsPlfUHwMX");
        com.aliyun.dysmsapi20170525.models.SendSmsRequest sendSmsRequest = new com.aliyun.dysmsapi20170525.models.SendSmsRequest()
                .setPhoneNumbers("18677055373")
                .setSignName("阿里云短信测试")
                .setTemplateCode("SMS_154950909")
                .setTemplateParam("{\"code\":\""+randomNumCode+"\"}");
        try {
            // 复制代码运行请自行打印 API 的返回值
            SendSmsResponse sendSmsResponse = client.sendSmsWithOptions(sendSmsRequest, new RuntimeOptions());
            JSONObject jsonObject = JSONObject.parseObject(JSONObject.toJSONString(sendSmsResponse));
            return jsonObject;
        } catch (TeaException error) {
            // 如有需要，请打印 error
            com.aliyun.teautil.Common.assertAsString(error.message);
            System.out.println(error.message);
        } catch (Exception _error) {
            TeaException error = new TeaException(_error.getMessage(), _error);
            // 如有需要，请打印 error
            com.aliyun.teautil.Common.assertAsString(error.message);
            System.out.println(_error.getMessage());
        }
        return  null;
    }


    public static void main(String[] args_) throws Exception {
        java.util.List<String> args = java.util.Arrays.asList(args_);
        // 请确保代码运行环境设置了环境变量 ALIBABA_CLOUD_ACCESS_KEY_ID 和 ALIBABA_CLOUD_ACCESS_KEY_SECRET。
        // 工程代码泄露可能会导致 AccessKey 泄露，并威胁账号下所有资源的安全性。以下代码示例使用环境变量获取 AccessKey 的方式进行调用，仅供参考，建议使用更安全的 STS 方式，更多鉴权访问方式请参见：https://help.aliyun.com/document_detail/378657.html
        String randomNumCode = ALiYunSmsUtil.getRandomNumCode(6);
        System.out.println(System.getenv("ALIBABA_CLOUD_ACCESS_KEY_ID"));
        System.out.println(System.getenv("ALIBABA_CLOUD_ACCESS_KEY_SECRET"));
        com.aliyun.dysmsapi20170525.Client client = ALiYunSmsUtil.createClient("LTAI5tDHLGfaPWLPtstv4y5s", "OCliJpIb53s1nGEAeAgqbsPlfUHwMX");
        com.aliyun.dysmsapi20170525.models.SendSmsRequest sendSmsRequest = new com.aliyun.dysmsapi20170525.models.SendSmsRequest()
                .setPhoneNumbers("19907766872")
                .setSignName("阿里云短信测试")
                .setTemplateCode("SMS_154950909")
                .setTemplateParam("{\"code\":\""+randomNumCode+"\"}");
        try {
            // 复制代码运行请自行打印 API 的返回值
            SendSmsResponse sendSmsResponse = client.sendSmsWithOptions(sendSmsRequest, new RuntimeOptions());
            String string = JSONObject.toJSONString(sendSmsResponse);

            System.out.println(string);
        } catch (TeaException error) {
            // 如有需要，请打印 error
            com.aliyun.teautil.Common.assertAsString(error.message);
            System.out.println(error.message);
        } catch (Exception _error) {
            TeaException error = new TeaException(_error.getMessage(), _error);
            // 如有需要，请打印 error
            com.aliyun.teautil.Common.assertAsString(error.message);
            System.out.println(_error.getMessage());
        }
    }


    /**
     * 生成数字验证码
     * @param number
     * @return
     */
    public static String getRandomNumCode(int number){
        int codeNum = (int)((Math.random()*9+1)*100000);
        String code = Integer.valueOf(codeNum).toString();
        System.out.println("smsCode:"+code);
        return code;
    }
}