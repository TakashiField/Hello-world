package com.chinatechstar.component.commons.entity;


public class ImpSeqSys {

  private String seqName;
  private Long timeS;
  private Long id;


  public String getSeqName() {
    return seqName;
  }

  public void setSeqName(String seqName) {
    this.seqName = seqName;
  }


  public Long getTimeS() {
    return timeS;
  }

  public void setTimeS(Long timeS) {
    this.timeS = timeS;
  }


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

}
