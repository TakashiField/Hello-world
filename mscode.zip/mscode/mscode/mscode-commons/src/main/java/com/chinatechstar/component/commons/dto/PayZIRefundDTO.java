package com.chinatechstar.component.commons.dto;

import com.chinatechstar.component.commons.entity.FppPaySerial;

import java.math.BigDecimal;

/**
 * @author lixu
 */
public class PayZIRefundDTO {

    private String gkId;

    private String merOrderNo;

    private BigDecimal orderAmount;

    private String refundNo;

    private String channelCode;

    /**
     * 支付方式 支付宝、微信
     */
    private String payType;

    private FppPaySerial fppPaySerial;

    public String getGkId() {
        return gkId;
    }

    public void setGkId(String gkId) {
        this.gkId = gkId;
    }

    public String getMerOrderNo() {
        return merOrderNo;
    }

    public void setMerOrderNo(String merOrderNo) {
        this.merOrderNo = merOrderNo;
    }

    public BigDecimal getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    public String getRefundNo() {
        return refundNo;
    }

    public void setRefundNo(String refundNo) {
        this.refundNo = refundNo;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public FppPaySerial getFppPaySerial() {
        return fppPaySerial;
    }

    public void setFppPaySerial(FppPaySerial fppPaySerial) {
        this.fppPaySerial = fppPaySerial;
    }
}
