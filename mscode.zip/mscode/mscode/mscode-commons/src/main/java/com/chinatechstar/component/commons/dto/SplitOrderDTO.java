package com.chinatechstar.component.commons.dto;

/**
 * @author lixu
 */
public class SplitOrderDTO {
}
