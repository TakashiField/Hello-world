package com.chinatechstar.crm.schedule;

import com.chinatechstar.component.commons.utils.UUIDUtil;
import com.chinatechstar.crm.dao.CrmTaskNoticeDao;
import com.chinatechstar.crm.dao.CrmUserDao;
import com.chinatechstar.crm.entity.CrmTaskNotice;
import com.chinatechstar.crm.entity.CrmUser;
import com.chinatechstar.crm.schedule.runnable.BirthdayRunnable;
import com.chinatechstar.crm.vo.CrmUserVO;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.annotation.Schedules;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.schedule
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-15 15-32
 * @Description: TODO
 * @Version: 1.0
 */

@Component
class BirthdaySchedule {

    @Autowired
    CrmTaskNoticeDao crmTaskNoticeDao;
    @Autowired
    CrmUserDao crmUserDao;
    @Scheduled(cron = "00 00 01 * * *")
    public void birdayNOtice(){
        CrmTaskNotice birthday = crmTaskNoticeDao.queryById(UUIDUtil.snowflakeId());
        //获取提前的天数 和时间
        Integer time = birthday.getSendTime();
        Date date = DateUtils.addDays(new Date(), time);
        //获取通配符
        String character = birthday.getCharacters();
        //获取短信内容
        String sendContent = birthday.getSendContent();
        //查询生日为date的会员
        CrmUserVO userVO = new CrmUserVO();
        userVO.setBirthday(date);
        List<CrmUser> crmUsers = crmUserDao.queryAllByPage(userVO);
        //如果查询的数据不为空，则对数据进行短信通知
        if(crmUsers.size() > 0 && "1".equals(birthday.getSendSmsOn())){
            BirthdayRunnable runnable = new BirthdayRunnable(crmUsers,birthday);
            CrmExectors crmExectors = new CrmExectors(runnable);
            crmExectors.run();
        }
    }
}
