package com.chinatechstar.crm.dao;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.dao
 * @Author: zhengxiaolei
 * @CreateTime: 2024-06-25 11-30
 * @Description: TODO
 * @Version: 1.0
 */
public class BaseDao {


}
