package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmInvestment;
import com.chinatechstar.crm.vo.CrmInvestmentVO;
import com.chinatechstar.crm.vo.CrmMchtDataVO;

import java.util.List;

/**
 * 招商加盟表(CrmInvestment)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-16 09:50:30
 */
public interface CrmInvestmentService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmInvestment queryById(Long id);

    /**
     * 分页查询
     *
     * @param crmInvestment 筛选条件
     * @return 查询结果
     */
    List<CrmInvestment> queryByPage(CrmInvestmentVO crmInvestment);

    /**
     * 新增数据
     *
     * @param crmInvestment 实例对象
     * @return 实例对象
     */
    CrmInvestment insert(CrmInvestment crmInvestment);

    /**
     * 修改数据
     *
     * @param crmInvestment 实例对象
     * @return 实例对象
     */
    CrmInvestment update(CrmInvestment crmInvestment);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Long id);

}
