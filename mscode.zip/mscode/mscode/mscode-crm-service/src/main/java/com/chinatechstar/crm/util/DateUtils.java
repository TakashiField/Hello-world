package com.chinatechstar.crm.util;

import java.util.Date;
import java.sql.Timestamp;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.util
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-01 11-39
 * @Description: TODO
 * @Version: 1.0
 */
public class DateUtils {

    /**
     * 获取当前时间戳
     * @return
     */
    public static Timestamp timestamp(){
        return new Timestamp(new Date().getTime());
    }
}
