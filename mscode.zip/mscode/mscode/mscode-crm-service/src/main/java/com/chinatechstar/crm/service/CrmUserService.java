package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmUser;
import com.chinatechstar.crm.vo.CrmUserVO;

import java.util.List;
import java.util.Map;

/**
 * 会员基础信息表(CrmUser)表服务接口
 *
 * @author zhengxl
 * @since 2024-06-28 11:31:38
 */
public interface CrmUserService {

    /**
     * 通过ID查询单条数据
     *
     * @param userId 主键
     * @return 实例对象
     */
    CrmUser queryById(Long userId);

    /**
     * 分页查询
     *
     * @param crmUser 筛选条件
     * @return 查询结果
     */
    Map<String, Object> queryByPage(CrmUserVO crmUser);

    /**
     * 新增数据
     *
     * @param crmUser 实例对象
     * @return 实例对象
     */
    CrmUser insert(CrmUser crmUser);

    /**
     * 修改数据
     *
     * @param crmUser 实例对象
     * @return 实例对象
     */
    CrmUser update(CrmUser crmUser);

    /**
     * 通过主键删除数据
     *
     * @param userId 主键
     * @return 是否成功
     */
    boolean deleteById(Long userId);

    Boolean checkExists(CrmUser crmUser);

    CrmUserVO sync(CrmUserVO crmUser);
}
