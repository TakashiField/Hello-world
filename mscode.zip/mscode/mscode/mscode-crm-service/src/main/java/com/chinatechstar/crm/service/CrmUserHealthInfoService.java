package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmUserHealthInfo;

import java.util.List;

/**
 * 会员健康信息表(CrmUserHealthInfo)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:00
 */
public interface CrmUserHealthInfoService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmUserHealthInfo queryById(Integer id);

    /**
     * 分页查询
     *
     * @param crmUserHealthInfo 筛选条件
     * @return 查询结果
     */
    List<CrmUserHealthInfo> queryByPage(CrmUserHealthInfo crmUserHealthInfo);

    /**
     * 新增数据
     *
     * @param crmUserHealthInfo 实例对象
     * @return 实例对象
     */
    CrmUserHealthInfo insert(CrmUserHealthInfo crmUserHealthInfo);

    /**
     * 修改数据
     *
     * @param crmUserHealthInfo 实例对象
     * @return 实例对象
     */
    CrmUserHealthInfo update(CrmUserHealthInfo crmUserHealthInfo);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Integer id);

}
