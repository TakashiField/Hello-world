package com.chinatechstar.crm.service.impl;

import com.chinatechstar.component.commons.result.PaginationBuilder;
import com.chinatechstar.component.commons.utils.StringUtils;
import com.chinatechstar.component.commons.utils.UUIDUtil;
import com.chinatechstar.crm.entity.CrmParam;
import com.chinatechstar.crm.dao.CrmParamDao;
import com.chinatechstar.crm.service.CrmParamService;
import com.chinatechstar.crm.util.DateUtils;
import com.chinatechstar.crm.vo.CrmParamVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 选项参数表(CrmParam)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-18 16:49:16
 */
@Slf4j
@Service("crmParamService")
public class CrmParamServiceImpl implements CrmParamService {
    @Autowired
    private CrmParamDao crmParamDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmParam queryById(Long id) {
        return this.crmParamDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param crmParam 筛选条件
     * @return 查询结果
     */
    @Override
    public Map<String, Object> queryByPage(CrmParamVO vo) {
        if(StringUtils.isBlank(vo.getParentCode())){
            vo.setParentCode("0");
        }
        PageHelper.startPage(vo.getCurrentPage(),vo.getPageSize(),true);
        List<CrmParam> paramList = this.crmParamDao.queryAllByPage(vo);

        PageInfo<CrmParam> pageInfo = new PageInfo<>(paramList);
        return PaginationBuilder.buildResultObject(paramList, pageInfo.getTotal(), vo.getCurrentPage(), vo.getPageSize());

    }


    /**
     * 新增数据
     *
     * @param crmParam 实例对象
     * @return 实例对象
     */
    @Override
    public CrmParam insert(CrmParam crmParam) {
        //将父类
        if(StringUtils.isBlank(crmParam.getParentCode())){
            crmParam.setParentCode("0");
        }

        //根据code码查询是否存在
        CrmParam select = new CrmParam();
        select.setParamCode(crmParam.getParamCode());
        select.setParentCode(crmParam.getParentCode());
        select.setMchtId(crmParam.getMchtId());

        long total = this.crmParamDao.count(select);
        if(total > 0){
            throw new RuntimeException("该参数代码已存在");
        }else {
            crmParam.setId(UUIDUtil.snowflakeId());
            crmParam.setCreateTime(DateUtils.timestamp());
            this.crmParamDao.insert(crmParam);
            return crmParam;
        }
    }

    /**
     * 修改数据
     *
     * @param crmParam 实例对象
     * @return 实例对象
     */
    @Override
    public CrmParam update(CrmParam crmParam) {
        crmParam.setUpdateTime(DateUtils.timestamp());
        this.crmParamDao.update(crmParam);
        return this.queryById(crmParam.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return this.crmParamDao.deleteById(id) > 0;
    }

    /**
     * @param crmParam
     * @return
     */
    @Override
    public List<CrmParam> queryByPageParent(CrmParamVO crmParam) {
        log.info("查询的组别："+crmParam.getParamCode()+":"+crmParam.getParamValue());
        return this.crmParamDao.queryAllByPage(crmParam);
    }
}
