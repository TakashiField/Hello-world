package com.chinatechstar.crm.service.impl;

import com.chinatechstar.component.commons.utils.UUIDUtil;
import com.chinatechstar.crm.constants.CrmConstants;
import com.chinatechstar.crm.dao.CrmCooperationManagerDao;
import com.chinatechstar.crm.dao.CrmUserDao;
import com.chinatechstar.crm.entity.CrmCooperationManager;
import com.chinatechstar.crm.entity.CrmInvestment;
import com.chinatechstar.crm.dao.CrmInvestmentDao;
import com.chinatechstar.crm.service.CrmInvestmentService;
import com.chinatechstar.crm.util.DateUtils;
import com.chinatechstar.crm.vo.CrmInvestmentVO;
import org.springframework.stereotype.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 招商加盟表(CrmInvestment)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-16 09:50:30
 */
@Service("crmInvestmentService")
public class CrmInvestmentServiceImpl implements CrmInvestmentService {
    @Autowired
    private CrmInvestmentDao crmInvestmentDao;
    @Autowired
    private CrmUserDao crmUserDao;
    @Autowired
    private CrmCooperationManagerDao crmCooperationManagerDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmInvestment queryById(Long id) {
        return this.crmInvestmentDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param crmInvestment 筛选条件
     * @return 查询结果
     */
    @Override
    public List<CrmInvestment> queryByPage(CrmInvestmentVO crmInvestment) {
        //long total = this.crmInvestmentDao.count(crmInvestment);
        return (this.crmInvestmentDao.queryAllByPage(crmInvestment));
    }


    /**
     * 新增数据
     *
     * @param crmInvestment 实例对象
     * @return 实例对象
     */
    @Override
    public CrmInvestment insert(CrmInvestment crmInvestment) {
        //根据加盟类型、姓名和手机号码校验是否已申请
        long count = crmInvestmentDao.count(crmInvestment);
        if( count > 0){
            throw new RuntimeException("用户已申请该加盟类型，请勿重复申请");
        }else {
            crmInvestment.setId(UUIDUtil.snowflakeId());
            crmInvestment.setStatus(CrmConstants.STATUS_APPLY);
            this.crmInvestmentDao.insert(crmInvestment);
            return crmInvestment;
        }
    }

    /**
     * 修改数据
     *
     * @param crmInvestment 实例对象
     * @return 实例对象
     */
    @Override
    public CrmInvestment update(CrmInvestment crmInvestment) {
        this.crmInvestmentDao.update(crmInvestment);
        //如果审核通过，则在合作商管理表内 新增一条数据
        if(CrmConstants.STATUS_PASS.equals(crmInvestment.getStatus())){
            CrmCooperationManager crmCooperationManager = new CrmCooperationManager();
            crmCooperationManager.setMchtId(crmInvestment.getMchtId());
            crmCooperationManager.setName(crmInvestment.getName());
            crmCooperationManager.setMobile(crmInvestment.getMobile());
            crmCooperationManager.setCoopType(crmInvestment.getInvestType());
            crmCooperationManager.setCreateTime(DateUtils.timestamp());
            crmCooperationManager.setSex(crmInvestment.getSex());
            Long userId = crmUserDao.selectIdByNameMobileMchtId(crmInvestment.getName(), crmInvestment.getMobile(), crmInvestment.getMchtId());
            crmCooperationManager.setUserId(userId);
            crmCooperationManagerDao.insert(crmCooperationManager);
        }
        return this.queryById(crmInvestment.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return this.crmInvestmentDao.deleteById(id) > 0;
    }
}
