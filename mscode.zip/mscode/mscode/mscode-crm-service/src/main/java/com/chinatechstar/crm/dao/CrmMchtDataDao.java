package com.chinatechstar.crm.dao;

import com.chinatechstar.crm.entity.CrmMchtData;
import com.chinatechstar.crm.vo.CrmMchtDataVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 会员资料表(CrmMchtData)表数据库访问层
 *
 * @author makejava
 * @since 2024-06-19 16:57:40
 */
@Mapper
public interface CrmMchtDataDao {

    /**
     * 通过ID查询单条数据
     *
     * @param dataId 主键
     * @return 实例对象
     */
    CrmMchtData queryById(Long dataId);

    /**
     * 查询指定行数据
     *
     * @param crmMchtData 查询条件
     * @return 对象列表
     */

    List<CrmMchtData> queryByPage(CrmMchtDataVO crmMchtData);

    /**
     * 统计总行数
     *
     * @param crmMchtData 查询条件
     * @return 总行数
     */
    long count(CrmMchtData crmMchtData);

    /**
     * 新增数据
     *
     * @param crmMchtData 实例对象
     * @return 影响行数
     */
    int insert(CrmMchtData crmMchtData);

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmMchtData> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<CrmMchtData> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmMchtData> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<CrmMchtData> entities);

    /**
     * 修改数据
     *
     * @param crmMchtData 实例对象
     * @return 影响行数
     */
    int update(CrmMchtData crmMchtData);

    /**
     * 通过主键删除数据
     *
     * @param dataId 主键
     * @return 影响行数
     */
    int deleteById(Long dataId);

    List<CrmMchtData> queryAllByLimit(CrmMchtDataVO crmMchtDataVO);
}

