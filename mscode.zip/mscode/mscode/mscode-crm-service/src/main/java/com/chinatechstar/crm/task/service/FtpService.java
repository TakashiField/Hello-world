package com.chinatechstar.crm.task.service;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.task.service
 * @Author: zhengxiaolei
 * @CreateTime: 2024-11-25 16-58
 * @Description: TODO
 * @Version: 1.0
 */
import com.chinatechstar.crm.util.FtpUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Service
public class FtpService {

    FtpUtils ftpUtils = new FtpUtils();

    public void uploadFile(MultipartFile file, String remoteDirectory) throws IOException {
        String localFilePath = file.getOriginalFilename();
        String remoteFilePath = remoteDirectory + "/" + file.getOriginalFilename();
        FtpUtils.uploadFile(localFilePath, remoteFilePath);
    }

    public void downloadFile(String remoteFilePath, String localDirectory) throws IOException {
        String localFilePath = localDirectory + "/" + Paths.get(remoteFilePath).getFileName().toString();
        FtpUtils.downloadFile(remoteFilePath, localFilePath);
    }
}

