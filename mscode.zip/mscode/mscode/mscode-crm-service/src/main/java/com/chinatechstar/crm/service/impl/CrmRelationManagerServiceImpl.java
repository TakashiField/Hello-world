package com.chinatechstar.crm.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.chinatechstar.component.commons.utils.UUIDUtil;
import com.chinatechstar.crm.dao.CrmRelationNameDao;
import com.chinatechstar.crm.dao.CrmRelationTypeDao;
import com.chinatechstar.crm.dao.CrmUserDao;
import com.chinatechstar.crm.entity.CrmRelationManager;
import com.chinatechstar.crm.dao.CrmRelationManagerDao;
import com.chinatechstar.crm.entity.CrmRelationName;
import com.chinatechstar.crm.entity.CrmRelationSymbol;
import com.chinatechstar.crm.entity.CrmRelationType;
import com.chinatechstar.crm.service.CrmRelationManagerService;
import com.chinatechstar.crm.util.DateUtils;
import com.chinatechstar.crm.vo.CrmPersonInfo;
import com.chinatechstar.crm.vo.CrmRelationManagerVO;
import com.chinatechstar.crm.vo.CrmUserRelationVO;
import com.chinatechstar.crm.vo.CrmUserVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 会员关系管理表(CrmRelationManager)表服务实现类
 *
 * @author makejava
 * @since 2024-06-26 09:59:18
 */
@Service("crmRelationManagerService")
public class CrmRelationManagerServiceImpl implements CrmRelationManagerService {
    @Resource
    private CrmRelationManagerDao crmRelationManagerDao;
    @Resource
    private CrmRelationNameDao crmRelationNameDao;
    @Resource
    private CrmUserDao crmUserDao;
    @Resource
    private CrmRelationTypeDao crmRelationTypeDao;
    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmRelationManager queryById(Long id) {
        return this.crmRelationManagerDao.queryById(id);
    }

    /*
     * 分页查询
     *
     * @param crmRelationManager 筛选条件
     * @param pageRequest      分页对象
     * @return 查询结果
     */
    @Override
    public List<CrmRelationManager> queryByPage(CrmRelationManagerVO vo) {
        PageHelper.startPage(vo.getCurrentPage(),vo.getPageSize(),true);
        List<CrmRelationManager> managerList = this.crmRelationManagerDao.queryByPage(vo);
        for (CrmRelationManager crmRelationManager : managerList) {
            crmRelationManager.setRelationDataArr(crmRelationManager.getRelationData().split(","));
        }
        PageInfo<CrmRelationManager> pageInfo = new PageInfo<>(managerList);
        vo.setTotalSize( pageInfo.getTotal() );
        vo.setTotalPage( pageInfo.getPages() );
        return managerList;
    }


    /**
     * 新增数据
     *
     * @param crmRelationManager 实例对象
     * @return 实例对象
     */
    @Override
    public CrmRelationManager insert(CrmRelationManager crmRelationManager) {

        Long userId = crmUserDao.selectIdByNameMobileMchtId("", crmRelationManager.getMobile(), crmRelationManager.getMchtId());
        if (userId == null) {
            throw new RuntimeException("该用户非会员");
        }
        crmRelationManager.setUserId(userId);
        CrmRelationManager select = new CrmRelationManager();
        //根据手机号和关系名称查询是否已存在
        select.setMobile(crmRelationManager.getMobile());
        select.setRelationNameId(crmRelationManager.getRelationNameId());
        select.setMobileRelated(crmRelationManager.getMobileRelated());
        long count = this.crmRelationManagerDao.count(select);
        if(count > 0){
            throw new RuntimeException("该关系已存在");
        } else {
            //根据关系名称查询关系类别
            //CrmRelationType relationType = crmRelationTypeDao.query(crmRelationManager.getRelationTypeId());
            String relationData = String.join(",", crmRelationManager.getRelationDataArr());
            crmRelationManager.setRelationData(relationData);
            crmRelationManager.setCreateTime(DateUtils.timestamp());
            //crmRelationManager.setRelationType(relationType.getRelationType());
            crmRelationManager.setId(UUIDUtil.snowflakeId());
            this.crmRelationManagerDao.insert(crmRelationManager);
            return crmRelationManager;
        }
    }

    /**
     * 修改数据
     *
     * @param crmRelationManager 实例对象
     * @return 实例对象
     */
    @Override
    public CrmRelationManager update(CrmRelationManager crmRelationManager) {
        String relationData = String.join(",", crmRelationManager.getRelationDataArr());
        crmRelationManager.setRelationData(relationData);
        crmRelationManager.setUpdateTime(DateUtils.timestamp());
        this.crmRelationManagerDao.update(crmRelationManager);
        return this.queryById(crmRelationManager.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return this.crmRelationManagerDao.deleteById(id) > 0;
    }

    /**
     * @param vo
     * @return
     */
    @Override
    public List<CrmRelationManager> queryByMchtId(CrmRelationManagerVO vo) {
        PageHelper.startPage(vo.getCurrentPage(),vo.getPageSize(),true);
        List<CrmRelationManager> managerList = this.crmRelationManagerDao.queryByMchtId(vo);
        PageInfo<CrmRelationManager> pageInfo = new PageInfo<>(managerList);
        vo.setTotalSize( pageInfo.getTotal() );
        vo.setTotalPage( pageInfo.getPages() );
        return managerList;
    }

    /**
     * @param vo
     * @return
     */
    @Override
    public List<CrmRelationManager> queryRelationByUserId(CrmRelationManagerVO vo) {
        PageHelper.startPage(vo.getCurrentPage(),vo.getPageSize(),true);
        List<CrmRelationManager> managerList = this.crmRelationManagerDao.queryRelationByUserId(vo);
        PageInfo<CrmRelationManager> pageInfo = new PageInfo<>(managerList);
        vo.setTotalSize( pageInfo.getTotal() );
        vo.setTotalPage( pageInfo.getPages() );
        return managerList;
    }

    /**
     * @param vo
     * @return
     */
    @Override
    public List<CrmRelationManager> queryByUserIdRelationTypeRelationName(CrmRelationManagerVO vo) {
        PageHelper.startPage(vo.getCurrentPage(),vo.getPageSize(),true);
        List<CrmRelationManager> managerList = this.crmRelationManagerDao.queryByUserIdRelationTypeRelationName(vo);
        PageInfo<CrmRelationManager> pageInfo = new PageInfo<>(managerList);
        vo.setTotalSize( pageInfo.getTotal() );
        vo.setTotalPage( pageInfo.getPages() );
        return managerList;
    }

    @Override
    public List<CrmPersonInfo> selectIdNoByNameMchtId(CrmRelationManagerVO vo) {

        List<CrmPersonInfo> infoList = this.crmUserDao.selectIdNoByNameMchtId(vo.getName(), vo.getMchtId());
        if(infoList == null || infoList.size() == 0) {
            throw new RuntimeException("该用户非会员");
        }
        return infoList;
    }
}
