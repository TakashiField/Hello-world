package com.chinatechstar.crm.service.impl;

import com.chinatechstar.crm.entity.CrmUserAddress;
import com.chinatechstar.crm.dao.CrmUserAddressDao;
import com.chinatechstar.crm.service.CrmUserAddressService;
import org.springframework.stereotype.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员地址信息表(CrmUserAddress)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-05 10:01:59
 */
@Service("crmUserAddressService")
public class CrmUserAddressServiceImpl implements CrmUserAddressService {
    @Autowired
    private CrmUserAddressDao crmUserAddressDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmUserAddress queryById(Long id) {
        return this.crmUserAddressDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param crmUserAddress 筛选条件
     * @return 查询结果
     */
    @Override
    public List<CrmUserAddress> queryByPage(CrmUserAddress crmUserAddress) {
        long total = this.crmUserAddressDao.count(crmUserAddress);
        return (this.crmUserAddressDao.queryAllByPage(crmUserAddress));
    }


    /**
     * 新增数据
     *
     * @param crmUserAddress 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserAddress insert(CrmUserAddress crmUserAddress) {
        this.crmUserAddressDao.insert(crmUserAddress);
        return crmUserAddress;
    }

    /**
     * 修改数据
     *
     * @param crmUserAddress 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserAddress update(CrmUserAddress crmUserAddress) {
        this.crmUserAddressDao.update(crmUserAddress);
        return this.queryById(crmUserAddress.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return this.crmUserAddressDao.deleteById(id) > 0;
    }
}
