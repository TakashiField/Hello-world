package com.chinatechstar.crm.dao;

import com.chinatechstar.crm.entity.CrmTaskNotice;
import com.chinatechstar.crm.vo.CrmTaskNoticeVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 通知提醒表(CrmTaskNotice)表数据库访问层
 *
 * @author zhengxl
 * @since 2024-07-15 10:54:03
 */
public interface CrmTaskNoticeDao {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmTaskNotice queryById(Long id);

    /**
     * 查询指定行数据
     *
     * @param crmTaskNotice 查询条件
     * @return 对象列表
     */
    List<CrmTaskNotice> queryAllByPage(CrmTaskNoticeVO crmTaskNotice);

    /**
     * 统计总行数
     *
     * @param crmTaskNotice 查询条件
     * @return 总行数
     */
    long count(CrmTaskNotice crmTaskNotice);

    /**
     * 新增数据
     *
     * @param crmTaskNotice 实例对象
     * @return 影响行数
     */
    int insert(CrmTaskNotice crmTaskNotice);

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmTaskNotice> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<CrmTaskNotice> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmTaskNotice> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<CrmTaskNotice> entities);

    /**
     * 修改数据
     *
     * @param crmTaskNotice 实例对象
     * @return 影响行数
     */
    int update(CrmTaskNotice crmTaskNotice);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 影响行数
     */
    int deleteById(Long id);

}

