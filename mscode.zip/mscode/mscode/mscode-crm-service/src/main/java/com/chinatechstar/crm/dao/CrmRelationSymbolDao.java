package com.chinatechstar.crm.dao;

import com.chinatechstar.crm.entity.CrmRelationSymbol;
import com.chinatechstar.crm.vo.CrmRelationSymbolVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 会员标签表(CrmRelationSymbol)表数据库访问层
 *
 * @author makejava
 * @since 2024-06-26 09:59:19
 */
public interface CrmRelationSymbolDao {

    /**
     * 通过ID查询单条数据
     *
     * @param symbolId 主键
     * @return 实例对象
     */
    CrmRelationSymbol queryById(Long symbolId);

    /**
     * 查询指定行数据
     *
     * @param crmRelationSymbol 查询条件
     * @return 对象列表
     */
    List<CrmRelationSymbol> queryAllByPage(CrmRelationSymbolVO crmRelationSymbol);

    /**
     * 统计总行数
     *
     * @param crmRelationSymbol 查询条件
     * @return 总行数
     */
    long count(CrmRelationSymbol crmRelationSymbol);

    /**
     * 新增数据
     *
     * @param crmRelationSymbol 实例对象
     * @return 影响行数
     */
    int insert(CrmRelationSymbol crmRelationSymbol);

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmRelationSymbol> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<CrmRelationSymbol> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmRelationSymbol> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<CrmRelationSymbol> entities);

    /**
     * 修改数据
     *
     * @param crmRelationSymbol 实例对象
     * @return 影响行数
     */
    int update(CrmRelationSymbol crmRelationSymbol);

    /**
     * 通过主键删除数据
     *
     * @param symbolId 主键
     * @return 影响行数
     */
    int deleteById(Long symbolId);

    List<CrmRelationSymbol> queryByIds(Long[] id);

}

