package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmGradeTemplate;
import com.chinatechstar.crm.vo.CrmGradeTemplateVO;

import java.util.List;

/**
 * 等级模板表(CrmGradeTemplate)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-02 10:04:40
 */
public interface CrmGradeTemplateService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmGradeTemplate queryById(Long id);

    /**
     * 分页查询
     *
     * @param crmGradeTemplate 筛选条件
     * @return 查询结果
     */
    List<CrmGradeTemplate> queryByPage(CrmGradeTemplateVO crmGradeTemplate);

    /**
     * 新增数据
     *
     * @param crmGradeTemplate 实例对象
     * @return 实例对象
     */
    CrmGradeTemplate insert(CrmGradeTemplateVO crmGradeTemplate);

    /**
     * 修改数据
     *
     * @param crmGradeTemplate 实例对象
     * @return 实例对象
     */
    CrmGradeTemplate update(CrmGradeTemplate crmGradeTemplate);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Long id);

    void turnOff(Long id);

    void turnOn(Long id);
}
