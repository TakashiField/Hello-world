package com.chinatechstar.crm.service.impl;

import com.chinatechstar.component.commons.result.PaginationBuilder;
import com.chinatechstar.component.commons.utils.SequenceGenerator;
import com.chinatechstar.crm.entity.CrmUserInfoContact;
import com.chinatechstar.crm.entity.CrmUserInfoHealth;
import com.chinatechstar.crm.dao.CrmUserInfoHealthDao;
import com.chinatechstar.crm.service.CrmUserInfoHealthService;
import com.chinatechstar.crm.util.DateUtils;
import com.chinatechstar.crm.vo.CrmUserInfoHealthVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员健康信息表(CrmUserInfoHealth)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:03
 */
@Service("crmUserInfoHealthService")
public class CrmUserInfoHealthServiceImpl implements CrmUserInfoHealthService {

    private static final SequenceGenerator sequenceGenerator = new SequenceGenerator();
    @Autowired
    private CrmUserInfoHealthDao crmUserInfoHealthDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmUserInfoHealth queryById(Long id) {
        return this.crmUserInfoHealthDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param crmUserInfoHealth 筛选条件
     * @return 查询结果
     */
    @Override
    public Map<String, Object> queryByPage(CrmUserInfoHealthVO crmUserInfoHealth) {

        PageHelper.startPage(crmUserInfoHealth.getCurrentPage(),crmUserInfoHealth.getPageSize(),true);
        List<CrmUserInfoHealth> healthList = this.crmUserInfoHealthDao.queryAllByPage(crmUserInfoHealth);

        PageInfo<CrmUserInfoHealth> pageInfo = new PageInfo<>(healthList);
        return PaginationBuilder.buildResultObject(healthList, pageInfo.getTotal(), crmUserInfoHealth.getCurrentPage(), crmUserInfoHealth.getPageSize());
    }


    /**
     * 新增数据
     *
     * @param crmUserInfoHealth 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserInfoHealth insert(CrmUserInfoHealth crmUserInfoHealth) {
        crmUserInfoHealth.setId(sequenceGenerator.nextId());
        //crmUserInfoHealth.setUserId(crmUserInfoHealth.getUserId());
        crmUserInfoHealth.setCreateUser(crmUserInfoHealth.getOperatorName());
        crmUserInfoHealth.setCreateTime(DateUtils.timestamp());
        this.crmUserInfoHealthDao.insert(crmUserInfoHealth);
        return crmUserInfoHealth;
    }

    /**
     * 修改数据
     *
     * @param crmUserInfoHealth 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserInfoHealth update(CrmUserInfoHealth crmUserInfoHealth) {
        crmUserInfoHealth.setUpdateTime(DateUtils.timestamp());
        crmUserInfoHealth.setUpdateUser(crmUserInfoHealth.getOperatorName());
        this.crmUserInfoHealthDao.update(crmUserInfoHealth);
        return this.queryById(crmUserInfoHealth.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return this.crmUserInfoHealthDao.deleteById(id) > 0;
    }
}
