package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmUserInfoWork;
import com.chinatechstar.crm.service.CrmUserInfoWorkService;
import com.chinatechstar.crm.vo.CrmUserInfoWorkVO;
import com.github.pagehelper.PageHelper;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员健康信息表(CrmUserInfoWork)表控制层
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:03
 */
@RestController
@RequestMapping("crmUserInfoWork")
public class CrmUserInfoWorkController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmUserInfoWorkService crmUserInfoWorkService;

    /**
     * 分页查询
     *
     * @param crmUserInfoWork 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage(@Validated CrmUserInfoWorkVO crmUserInfoWork) {
        Map<String,Object> data = this.crmUserInfoWorkService.queryByPage(crmUserInfoWork);
        return ResultBuilder.buildListSuccess(data);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {
        return ResultBuilder.buildListSuccess(this.crmUserInfoWorkService.queryById(id));
    }

    /**
     * 新增数据
     *
     * @param crmUserInfoWork 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody CrmUserInfoWork crmUserInfoWork) {
        this.crmUserInfoWorkService.insert(crmUserInfoWork);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmUserInfoWork 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody CrmUserInfoWork crmUserInfoWork) {
        this.crmUserInfoWorkService.update(crmUserInfoWork);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Long id) {
        this.crmUserInfoWorkService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

}

