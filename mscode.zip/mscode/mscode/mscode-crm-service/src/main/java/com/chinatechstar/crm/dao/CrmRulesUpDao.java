package com.chinatechstar.crm.dao;
import com.chinatechstar.crm.entity.CrmRulesUp;
import com.chinatechstar.crm.vo.CrmRulesVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 会员升级规则(CrmRulesUp)表数据库访问层
 *
 * @author zhengxl
 * @since 2024-07-03 12:43:03
 */
public interface CrmRulesUpDao {

    /**
     * 通过ID查询单条数据
     *
     * @param ruleId 主键
     * @return 实例对象
     */
    CrmRulesUp queryById(Long ruleId);

    /**
     * 查询指定行数据
     *
     * @param crmRulesUp 查询条件
     * @return 对象列表
     */
    List<CrmRulesUp> queryAllByPage(CrmRulesVO crmRulesUp);

    /**
     * 统计总行数
     *
     * @param crmRulesUp 查询条件
     * @return 总行数
     */
    long count(CrmRulesUp crmRulesUp);

    /**
     * 新增数据
     *
     * @param crmRulesUp 实例对象
     * @return 影响行数
     */
    int insert(CrmRulesUp crmRulesUp);

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmRulesUp> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<CrmRulesUp> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmRulesUp> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<CrmRulesUp> entities);

    /**
     * 修改数据
     *
     * @param crmRulesUp 实例对象
     * @return 影响行数
     */
    int update(CrmRulesUp crmRulesUp);

    /**
     * 通过主键删除数据
     *
     * @param ruleId 主键
     * @return 影响行数
     */
    int deleteById(Long ruleId);

    List<CrmRulesUp> queryByGradeId(CrmRulesVO vo);

    List<CrmRulesUp> queryByIds(String[] ids);
}

