package com.chinatechstar.crm.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.chinatechstar.component.commons.utils.UUIDUtil;
import com.chinatechstar.crm.constants.CrmConstants;
import com.chinatechstar.crm.dao.CrmGradeTemplateDetailDao;
import com.chinatechstar.crm.entity.CrmGradeTemplate;
import com.chinatechstar.crm.dao.CrmGradeTemplateDao;
import com.chinatechstar.crm.entity.CrmGradeTemplateDetail;
import com.chinatechstar.crm.service.CrmGradeTemplateService;
import com.chinatechstar.crm.vo.CrmGradeTemplateDetailVO;
import com.chinatechstar.crm.vo.CrmGradeTemplateVO;
import com.github.pagehelper.PageHelper;
import org.springframework.stereotype.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 等级模板表(CrmGradeTemplate)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-02 10:04:40
 */
@Service("crmGradeTemplateService")
public class CrmGradeTemplateServiceImpl implements CrmGradeTemplateService {
    @Autowired
    private CrmGradeTemplateDao crmGradeTemplateDao;
    @Autowired
    private CrmGradeTemplateDetailDao crmGradeTemplateDetailDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmGradeTemplate queryById(Long id) {
        CrmGradeTemplate crmGradeTemplate = this.crmGradeTemplateDao.queryById(id);
        CrmGradeTemplateDetail select = new CrmGradeTemplateDetail();
        select.setTemplateId(id);
        List<CrmGradeTemplateDetail> details = crmGradeTemplateDetailDao.queryAllByPage(select);
        crmGradeTemplate.setList(details);
        return crmGradeTemplate;
    }

    /**
     * 分页查询
     *
     * @param crmGradeTemplate 筛选条件
     * @return 查询结果
     */
    @Override
    public List<CrmGradeTemplate> queryByPage(CrmGradeTemplateVO crmGradeTemplate) {
        PageHelper.startPage(crmGradeTemplate.getCurrentPage(),crmGradeTemplate.getPageSize(),true);
        //long total = this.crmGradeTemplateDao.count(crmGradeTemplate);
        return (this.crmGradeTemplateDao.queryAllByPage(crmGradeTemplate));
    }


    /**
     * 新增数据
     *
     * @param crmGradeTemplate 实例对象
     * @return 实例对象
     */
    @Override
    public CrmGradeTemplate insert(CrmGradeTemplateVO crmGradeTemplate) {
        CrmGradeTemplate select = new CrmGradeTemplate();
        select.setMchtId(crmGradeTemplate.getMchtId());
        select.setTemplateName(crmGradeTemplate.getTemplateName());
        select.setTemplateType(crmGradeTemplate.getTemplateType());
        long count = this.crmGradeTemplateDao.count(select);
        if (count > 0) {
            throw new RuntimeException("该模板名称已存在");
        } else {
            Long templateId = UUIDUtil.snowflakeId();
            select.setId(templateId);
            // 状态 0-停用 1-启用  默认停用，需页面开启，且每次只能开启一条，其他都为停用
            select.setStatus(CrmConstants.STATUS_OFF);
            // 来源渠道
            select.setSrcChannel("0");
            StringBuilder sb = new StringBuilder();
            List<CrmGradeTemplateDetailVO> list = crmGradeTemplate.getList();

            select.setTemplateContent(JSONObject.toJSONString(list));
            this.crmGradeTemplateDao.insert(select);

            CrmGradeTemplateDetail templateDetail = new CrmGradeTemplateDetail();
            for (CrmGradeTemplateDetailVO detail : list) {
                templateDetail.setId(UUIDUtil.snowflakeId());
                templateDetail.setTemplateId(templateId);
                templateDetail.setGrade(detail.getGrade());
                templateDetail.setGradeName(detail.getGradeName());
                templateDetail.setGradeImage(detail.getGradeImage());
                templateDetail.setRulesDownState(CrmConstants.STATUS_OFF);
                templateDetail.setRulesUpState(CrmConstants.STATUS_OFF);
                templateDetail.setRulesBenefitStatus(CrmConstants.STATUS_OFF);
                templateDetail.setStatus(CrmConstants.STATUS_ON);
                templateDetail.setMchtId(crmGradeTemplate.getMchtId());
                this.crmGradeTemplateDetailDao.insert(templateDetail);

            }

            return select;
        }
    }

    /**
     * 修改数据
     *
     * @param crmGradeTemplate 实例对象
     * @return 实例对象
     */
    @Override
    public CrmGradeTemplate update(CrmGradeTemplate crmGradeTemplate) {
        this.crmGradeTemplateDao.update(crmGradeTemplate);
        //更新detail
        List<CrmGradeTemplateDetail> list = crmGradeTemplate.getList();
        for (CrmGradeTemplateDetail templateDetail : list) {
            crmGradeTemplateDetailDao.update(templateDetail);
        }
        return this.queryById(crmGradeTemplate.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return this.crmGradeTemplateDao.deleteById(id) > 0;
    }

    /**
     * @param id
     */
    @Override
    public void turnOff(Long id) {
        CrmGradeTemplate crmGradeTemplate = new CrmGradeTemplate();
        crmGradeTemplate.setId(id);
        crmGradeTemplate.setStatus(CrmConstants.STATUS_OFF);
        this.crmGradeTemplateDao.update(crmGradeTemplate);
    }

    /**
     * @param id
     */
    @Override
    public void turnOn(Long id) {
        CrmGradeTemplate crmGradeTemplate = new CrmGradeTemplate();
        crmGradeTemplate.setId(id);
        crmGradeTemplate.setStatus(CrmConstants.STATUS_ON);
        this.crmGradeTemplateDao.update(crmGradeTemplate);
    }
}
