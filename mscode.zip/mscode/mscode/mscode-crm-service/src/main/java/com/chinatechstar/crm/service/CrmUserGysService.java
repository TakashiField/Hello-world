package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmUserGys;
import com.chinatechstar.crm.vo.CrmUserGysVO;

import java.util.List;

/**
 * 供应商列表(CrmUserGys)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:00
 */
public interface CrmUserGysService {

    /**
     * 通过ID查询单条数据
     *
     * @param userId 主键
     * @return 实例对象
     */
    CrmUserGys queryById(Long userId);

    /**
     * 分页查询
     *
     * @param crmUserGys 筛选条件
     * @return 查询结果
     */
    List<CrmUserGys> queryByPage(CrmUserGysVO crmUserGys);

    /**
     * 新增数据
     *
     * @param crmUserGys 实例对象
     * @return 实例对象
     */
    CrmUserGys insert(CrmUserGys crmUserGys);

    /**
     * 修改数据
     *
     * @param crmUserGys 实例对象
     * @return 实例对象
     */
    CrmUserGys update(CrmUserGys crmUserGys);

    /**
     * 通过主键删除数据
     *
     * @param userId 主键
     * @return 是否成功
     */
    boolean deleteById(Long userId);

}
