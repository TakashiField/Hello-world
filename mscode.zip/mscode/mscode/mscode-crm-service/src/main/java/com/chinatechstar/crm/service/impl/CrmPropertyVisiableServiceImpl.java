package com.chinatechstar.crm.service.impl;

import com.chinatechstar.component.commons.result.PaginationBuilder;
import com.chinatechstar.crm.entity.CrmPropertyVisiable;
import com.chinatechstar.crm.dao.CrmPropertyVisiableDao;
import com.chinatechstar.crm.service.CrmPropertyVisiableService;
import com.chinatechstar.crm.vo.CrmPropertyVisiableVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 属性可见控制表(CrmPropertyVisiable)表服务实现类
 *
 * @author zhengxl
 * @since 2024-06-28 10:00:32
 */
@Service("crmPropertyVisiableService")
public class CrmPropertyVisiableServiceImpl implements CrmPropertyVisiableService {
    @Autowired
    private CrmPropertyVisiableDao crmPropertyVisiableDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmPropertyVisiable queryById(Long id) {
        return this.crmPropertyVisiableDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param vo 筛选条件
     * @return 查询结果
     */
    @Override
    public Map<String, Object> queryByPage(CrmPropertyVisiableVO vo) {
        PageHelper.startPage(vo.getCurrentPage(),vo.getPageSize(),true);
        List<CrmPropertyVisiable> visiableList = this.crmPropertyVisiableDao.queryAllByPage(vo);
        PageInfo<CrmPropertyVisiable> pageInfo = new PageInfo<>(visiableList);
        return PaginationBuilder.buildResultObject(visiableList, pageInfo.getTotal(), vo.getCurrentPage(), vo.getPageSize());

    }


    /**
     * 新增数据
     *
     * @param crmPropertyVisiable 实例对象
     * @return 实例对象
     */
    @Override
    public CrmPropertyVisiable insert(CrmPropertyVisiable crmPropertyVisiable) {
        this.crmPropertyVisiableDao.insert(crmPropertyVisiable);
        return crmPropertyVisiable;
    }

    /**
     * 修改数据
     *
     * @param id 实例对象
     * @return 实例对象
     */
    @Override
    public CrmPropertyVisiable update(Long[] id) {
        this.crmPropertyVisiableDao.turnOff();
        this.crmPropertyVisiableDao.update(id);
        return null;
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return this.crmPropertyVisiableDao.deleteById(id) > 0;
    }
}
