package com.chinatechstar.crm.controller;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.controller
 * @Author: zhengxiaolei
 * @CreateTime: 2024-11-25 17-00
 * @Description: TODO
 * @Version: 1.0
 */
import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.task.service.FtpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@RestController
@RequestMapping("/ftp")
public class FtpController {

    @Autowired
    private FtpService ftpService;

    @PostMapping("/upload")
    public ActionResult uploadFile(@RequestParam("file") MultipartFile file, @RequestParam("directory") String directory) throws IOException {
        ftpService.uploadFile(file, directory);
        return ResultBuilder.buildActionSuccess();
    }

    @GetMapping("/download/{filename}")
    public ActionResult downloadFile(@PathVariable("filename") String filename, @RequestParam("directory") String directory) throws IOException {
        ftpService.downloadFile(filename, directory);
        return ResultBuilder.buildActionSuccess();
    }
}

