package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmUserWealthInfo;
import com.chinatechstar.crm.service.CrmUserWealthInfoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员资产信息表(CrmUserWealthInfo)表控制层
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:02
 */
@RestController
@RequestMapping("crmUserWealthInfo")
public class CrmUserWealthInfoController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmUserWealthInfoService crmUserWealthInfoService;

    /**
     * 分页查询
     *
     * @param crmUserWealthInfo 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage(@RequestBody CrmUserWealthInfo crmUserWealthInfo) {
        List<CrmUserWealthInfo> crmUserWealthInfos = this.crmUserWealthInfoService.queryByPage(crmUserWealthInfo);
        return ResultBuilder.buildListSuccess(crmUserWealthInfos);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Integer id) {
        CrmUserWealthInfo crmUserWealthInfo = this.crmUserWealthInfoService.queryById(id);
        return ResultBuilder.buildListSuccess(crmUserWealthInfo);
    }

    /**
     * 新增数据
     *
     * @param crmUserWealthInfo 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody CrmUserWealthInfo crmUserWealthInfo) {
        this.crmUserWealthInfoService.insert(crmUserWealthInfo);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmUserWealthInfo 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody CrmUserWealthInfo crmUserWealthInfo) {
        this.crmUserWealthInfoService.update(crmUserWealthInfo);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Integer id) {
        this.crmUserWealthInfoService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

}

