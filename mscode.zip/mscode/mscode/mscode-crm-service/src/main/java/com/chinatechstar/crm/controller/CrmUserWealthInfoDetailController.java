package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmUserWealthInfoDetail;
import com.chinatechstar.crm.service.CrmUserWealthInfoDetailService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员资产明细表(CrmUserWealthInfoDetail)表控制层
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:02
 */
@RestController
@RequestMapping("crmUserWealthInfoDetail")
public class CrmUserWealthInfoDetailController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmUserWealthInfoDetailService crmUserWealthInfoDetailService;

    /**
     * 分页查询
     *
     * @param crmUserWealthInfoDetail 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage(@RequestBody CrmUserWealthInfoDetail crmUserWealthInfoDetail) {
        List<CrmUserWealthInfoDetail> crmUserWealthInfoDetails = this.crmUserWealthInfoDetailService.queryByPage(crmUserWealthInfoDetail);
        return ResultBuilder.buildListSuccess(crmUserWealthInfoDetails);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Integer id) {
        CrmUserWealthInfoDetail crmUserWealthInfoDetail = this.crmUserWealthInfoDetailService.queryById(id);
        return ResultBuilder.buildListSuccess(crmUserWealthInfoDetail);
    }

    /**
     * 新增数据
     *
     * @param crmUserWealthInfoDetail 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody CrmUserWealthInfoDetail crmUserWealthInfoDetail) {
        this.crmUserWealthInfoDetailService.insert(crmUserWealthInfoDetail);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmUserWealthInfoDetail 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody CrmUserWealthInfoDetail crmUserWealthInfoDetail) {
        this.crmUserWealthInfoDetailService.update(crmUserWealthInfoDetail);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Integer id) {
        this.crmUserWealthInfoDetailService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

}

