package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.service.CrmCenterService;
import com.chinatechstar.crm.vo.CrmCenterVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.controller
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-30 15-12
 * @Description: TODO
 * @Version: 1.0
 */
@RestController
@Slf4j
@RequestMapping("crmCenter")
public class CrmCenterController {

    @Autowired
    private CrmCenterService service;

    @RequestMapping("/query")
    //个人中心获取会员信息
    ListResult<Object> query(@Validated @RequestBody CrmCenterVO crmCenterVO){

        service.queryCenter(crmCenterVO);

        return ResultBuilder.buildListSuccess(crmCenterVO);
    }
}
