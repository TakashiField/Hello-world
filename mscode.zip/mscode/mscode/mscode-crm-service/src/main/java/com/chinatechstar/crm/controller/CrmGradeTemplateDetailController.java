package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmGradeRule;
import com.chinatechstar.crm.entity.CrmGradeTemplateDetail;
import com.chinatechstar.crm.service.CrmGradeTemplateDetailService;
import com.chinatechstar.crm.vo.CrmGradeTemplateDetailVO;
import org.apache.ibatis.annotations.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 等级模板明细表(CrmGradeTemplateDetail)表控制层
 *
 * @author zhengxl
 * @since 2024-07-02 10:58:36
 */
@RestController
@RequestMapping("crmGradeTemplateDetail")
public class CrmGradeTemplateDetailController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmGradeTemplateDetailService crmGradeTemplateDetailService;

    /**
     * 分页查询
     *
     * @param templateType 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage(@Validated CrmGradeTemplateDetailVO templateType) {

        List<CrmGradeTemplateDetail> result = this.crmGradeTemplateDetailService.queryDetailByType(templateType);
        //crmGradeTemplateDetail.setCrmList(result);
        return ResultBuilder.buildListSuccess(result);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ResponseEntity<CrmGradeTemplateDetail> queryById(Long id) {
        return ResponseEntity.ok(this.crmGradeTemplateDetailService.queryById(id));
    }

    /**
     * 新增数据
     *
     * @param crmGradeTemplateDetail 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody CrmGradeTemplateDetailVO crmGradeTemplateDetail) {

        //this.crmGradeTemplateDetailService.insert(crmGradeTemplateDetail);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmGradeTemplateDetail 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ResponseEntity<CrmGradeTemplateDetail> edit(@RequestBody CrmGradeTemplateDetail crmGradeTemplateDetail) {
        return ResponseEntity.ok(this.crmGradeTemplateDetailService.update(crmGradeTemplateDetail));
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ResponseEntity<Boolean> deleteById(Long id) {
        return ResponseEntity.ok(this.crmGradeTemplateDetailService.deleteById(id));
    }

    @GetMapping("/queryDetailByType")
    public ListResult<Object> queryDetailByType(@RequestBody CrmGradeTemplateDetailVO templateType){

        List<CrmGradeTemplateDetail> result = this.crmGradeTemplateDetailService.queryDetailByType(templateType);
        return ResultBuilder.buildListSuccess(result);
    }

    @PostMapping("/turnOn")
    public ActionResult turnOn(@RequestBody @Validated CrmGradeRule crmGradeRule) {
        this.crmGradeTemplateDetailService.turnOn(crmGradeRule);
        return ResultBuilder.buildActionSuccess();
    }

    @PostMapping("/turnOff")
    public ActionResult turnOff(@RequestBody @Validated CrmGradeRule crmGradeRule) {
        this.crmGradeTemplateDetailService.turnOff(crmGradeRule);
        return ResultBuilder.buildActionSuccess();
    }

    @PostMapping("/selectOn")
    public ActionResult selectOn(@RequestBody @Validated CrmGradeRule crmGradeRule) {
        this.crmGradeTemplateDetailService.selectOn(crmGradeRule);
        return ResultBuilder.buildActionSuccess();
    }
}

