package com.chinatechstar.crm.service.impl;

import com.chinatechstar.crm.entity.CrmUserHealthInfo;
import com.chinatechstar.crm.dao.CrmUserHealthInfoDao;
import com.chinatechstar.crm.service.CrmUserHealthInfoService;
import org.springframework.stereotype.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员健康信息表(CrmUserHealthInfo)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:00
 */
@Service("crmUserHealthInfoService")
public class CrmUserHealthInfoServiceImpl implements CrmUserHealthInfoService {
    @Autowired
    private CrmUserHealthInfoDao crmUserHealthInfoDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmUserHealthInfo queryById(Integer id) {
        return this.crmUserHealthInfoDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param crmUserHealthInfo 筛选条件
     * @return 查询结果
     */
    @Override
    public List<CrmUserHealthInfo> queryByPage(CrmUserHealthInfo crmUserHealthInfo) {
        long total = this.crmUserHealthInfoDao.count(crmUserHealthInfo);
        return (this.crmUserHealthInfoDao.queryAllByPage(crmUserHealthInfo));
    }


    /**
     * 新增数据
     *
     * @param crmUserHealthInfo 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserHealthInfo insert(CrmUserHealthInfo crmUserHealthInfo) {
        this.crmUserHealthInfoDao.insert(crmUserHealthInfo);
        return crmUserHealthInfo;
    }

    /**
     * 修改数据
     *
     * @param crmUserHealthInfo 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserHealthInfo update(CrmUserHealthInfo crmUserHealthInfo) {
        this.crmUserHealthInfoDao.update(crmUserHealthInfo);
        return this.queryById(crmUserHealthInfo.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Integer id) {
        return this.crmUserHealthInfoDao.deleteById(id) > 0;
    }
}
