//package com.chinatechstar.crm.util;
//
//import java.util.Map;
//
//import com.alibaba.fastjson.JSONObject;
//
///**
// * @version:1.0（版本，具体版本信息自己来定）
// * @Description: 发往mbp的交易公共方法类
// * @author: kp （作者,自己姓名的拼音简称）
// * @date: 2020年10月23日
// */
//
//public class MBPUtils {
//
//	/**
//	 * 获取公共报文头
//	 * @param msgcode 交易代码
//	 * @return
//	 */
//	public static JSONObject getCommonHead(String msgcode, String platForm) {
//		JSONObject headObj = new JSONObject();
//		String serialno = IdGenerator.getIdLongStr();
//		SystemNowTime st = new SystemNowTime();
//
//		headObj.put("msgcode", msgcode);
//		headObj.put("trdate", st.getDateStr());
//		headObj.put("trtime", st.getTimeStrhhmmss());
//		headObj.put("serialno", serialno);
//		headObj.put("platform", platForm);
//		return headObj;
//	}
//
//	/**
//	 * 获取发送给mbp的报文字符串
//	 * @param headObj
//	 * @param dataObj
//	 * @return
//	 */
//	public static String getSendText(JSONObject headObj, JSONObject dataObj) {
//		JSONObject json = new JSONObject();
//		JSONObject rootObj = new JSONObject();
//		rootObj.put("head", headObj);
//		rootObj.put("data", dataObj);
//		json.put("imp", rootObj);
//		return json.toString();
//	}
//
//	/**
//	 * 获取发送给mbp的报文字符串
//	 * @param headObj
//	 * @param dataObj
//	 * @return
//	 */
//	public static JSONObject getSendObj(JSONObject headObj, JSONObject dataObj) {
//		JSONObject json = new JSONObject();
//		JSONObject rootObj = new JSONObject();
//		rootObj.put("head", headObj);
//		rootObj.put("data", dataObj);
//		json.put("imp", rootObj);
//		return json;
//	}
//
//	/**
//	 * 把前端的请求body设置到json对象
//	 * @param body
//	 * @return
//	 */
//	public static JSONObject getDataObj(Map<String, String> body) {
//		JSONObject dataObj = new JSONObject();
//		for (Map.Entry<String, String> entry : body.entrySet()) {
//			dataObj.put(entry.getKey(), entry.getValue());
//	    }
//		//去掉交易代码，mbp交易代码在报文头
//		dataObj.remove("transCode");
//		return dataObj;
//	}
//
//	/**
//	 * 获取mbp返回报文头
//	 * @param respStr
//	 * @return
//	 */
//	public static JSONObject getRespHeadObj(String respStr) {
//		JSONObject allObj =  JSONObject.parseObject(respStr);
//		JSONObject respHeadObj = allObj.getJSONObject("imp").getJSONObject("head");
//		return respHeadObj;
//	}
//
//	/**
//	 * 获取mbp返回报文体
//	 * @param respStr
//	 * @return
//	 */
//	public static JSONObject getRespDataObj(String respStr) {
//		JSONObject allObj =  JSONObject.parseObject(respStr);
//		JSONObject respDataObj = allObj.getJSONObject("imp").getJSONObject("data");
//		return respDataObj;
//	}
//
//	/**
//	 * 交易是否成功
//	 * @param respHeadObj
//	 * @return
//	 */
//	public static boolean isSuccess(JSONObject respHeadObj) {
//		String respcode = respHeadObj.getString("respcode");
//		if ("00000".equals(respcode)) {
//			return true;
//		} else {
//			return false;
//		}
//	}
//
//}
