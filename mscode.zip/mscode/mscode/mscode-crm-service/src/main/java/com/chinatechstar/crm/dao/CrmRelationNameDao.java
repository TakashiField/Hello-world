package com.chinatechstar.crm.dao;

import com.chinatechstar.crm.entity.CrmRelationName;
import com.chinatechstar.crm.vo.CrmRelationNameVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 会员关系名称表(CrmRelationName)表数据库访问层
 *
 * @author makejava
 * @since 2024-06-26 09:59:19
 */
public interface CrmRelationNameDao {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmRelationName queryById(Long id);

    /**
     * 查询指定行数据
     *
     * @param crmRelationName 查询条件
     * @return 对象列表
     */
    List<CrmRelationName> queryByPage(CrmRelationNameVO crmRelationName);

    /**
     * 统计总行数
     *
     * @param crmRelationName 查询条件
     * @return 总行数
     */
    long count(CrmRelationName crmRelationName);

    /**
     * 新增数据
     *
     * @param crmRelationName 实例对象
     * @return 影响行数
     */
    int insert(CrmRelationName crmRelationName);

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmRelationName> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<CrmRelationName> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmRelationName> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<CrmRelationName> entities);

    /**
     * 修改数据
     *
     * @param crmRelationName 实例对象
     * @return 影响行数
     */
    int update(CrmRelationName crmRelationName);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 影响行数
     */
    int deleteById(Long id);

}

