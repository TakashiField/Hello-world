package com.chinatechstar.crm.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.chinatechstar.component.commons.result.PaginationBuilder;
import com.chinatechstar.component.commons.utils.SequenceGenerator;
import com.chinatechstar.crm.entity.CrmUserInfoGraduation;
import com.chinatechstar.crm.dao.CrmUserInfoGraduationDao;
import com.chinatechstar.crm.service.CrmUserInfoGraduationService;
import com.chinatechstar.crm.util.DateUtils;
import com.chinatechstar.crm.vo.CrmUserInfoGraduationVO;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员学习信息表(CrmUserInfoGraduation)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:03
 */
@Slf4j
@Service("crmUserInfoGraduationService")
public class CrmUserInfoGraduationServiceImpl implements CrmUserInfoGraduationService {

    private static final SequenceGenerator sequenceGenerator = new SequenceGenerator();
    @Autowired
    private CrmUserInfoGraduationDao crmUserInfoGraduationDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmUserInfoGraduation queryById(Long id) {
        return this.crmUserInfoGraduationDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param crmUserInfoGraduation 筛选条件
     * @return 查询结果
     */
    @Override
    public Map<String, Object> queryByPage(CrmUserInfoGraduationVO crmUserInfoGraduation) {
        PageHelper.startPage(crmUserInfoGraduation.getCurrentPage(),crmUserInfoGraduation.getPageSize(),true);
        List<CrmUserInfoGraduation> graduationList = this.crmUserInfoGraduationDao.queryAllByPage(crmUserInfoGraduation);
        PageInfo<CrmUserInfoGraduation> pageInfo = new PageInfo<>(graduationList);
        return PaginationBuilder.buildResultObject(graduationList, pageInfo.getTotal(), crmUserInfoGraduation.getCurrentPage(), crmUserInfoGraduation.getPageSize());

    }


    /**
     * 新增数据
     *
     * @param crmUserInfoGraduation 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserInfoGraduation insert(CrmUserInfoGraduation crmUserInfoGraduation) {
        log.info(JSONObject.toJSONString(crmUserInfoGraduation));
        crmUserInfoGraduation.setId(sequenceGenerator.nextId());
        //crmUserInfoGraduation.setUserId(crmUserInfoGraduation.getUserId());
        //crmUserInfoGraduation.setMchtId(sequenceGenerator.nextId());
        crmUserInfoGraduation.setCreateUser(crmUserInfoGraduation.getOperatorName());
        crmUserInfoGraduation.setCreateTime(DateUtils.timestamp());
        this.crmUserInfoGraduationDao.insert(crmUserInfoGraduation);
        return crmUserInfoGraduation;
    }

    /**
     * 修改数据
     *
     * @param crmUserInfoGraduation 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserInfoGraduation update(CrmUserInfoGraduation crmUserInfoGraduation) {
        crmUserInfoGraduation.setUpdateTime(DateUtils.timestamp());
        crmUserInfoGraduation.setUpdateUser(crmUserInfoGraduation.getOperatorName());
        this.crmUserInfoGraduationDao.update(crmUserInfoGraduation);
        return this.queryById(crmUserInfoGraduation.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return this.crmUserInfoGraduationDao.deleteById(id) > 0;
    }
}
