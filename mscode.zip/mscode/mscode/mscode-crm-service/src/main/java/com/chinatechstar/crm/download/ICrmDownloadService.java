package com.chinatechstar.crm.download;

import javax.servlet.http.HttpServletResponse;

public interface ICrmDownloadService {

    void download(HttpServletResponse response);
}
