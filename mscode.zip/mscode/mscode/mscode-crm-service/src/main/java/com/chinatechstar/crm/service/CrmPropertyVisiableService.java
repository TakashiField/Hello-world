package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmPropertyVisiable;
import com.chinatechstar.crm.vo.CrmPropertyVisiableVO;

import java.util.List;
import java.util.Map;

/**
 * 属性可见控制表(CrmPropertyVisiable)表服务接口
 *
 * @author zhengxl
 * @since 2024-06-28 10:00:32
 */
public interface CrmPropertyVisiableService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmPropertyVisiable queryById(Long id);

    /**
     * 分页查询
     *
     * @param crmPropertyVisiable 筛选条件
     * @return 查询结果
     */
    Map<String, Object>  queryByPage(CrmPropertyVisiableVO crmPropertyVisiable);

    /**
     * 新增数据
     *
     * @param crmPropertyVisiable 实例对象
     * @return 实例对象
     */
    CrmPropertyVisiable insert(CrmPropertyVisiable crmPropertyVisiable);

    /**
     * 修改数据
     *
     * @param crmPropertyVisiable 实例对象
     * @return 实例对象
     */
    CrmPropertyVisiable update(Long[] crmPropertyVisiable);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Long id);

}
