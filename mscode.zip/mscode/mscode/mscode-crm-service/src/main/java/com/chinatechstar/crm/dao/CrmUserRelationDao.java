package com.chinatechstar.crm.dao;

import com.chinatechstar.crm.entity.CrmUserRelation;
import com.chinatechstar.crm.vo.CrmUserRelationVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 用户关系管理(CrmUserRelation)表数据库访问层
 *
 * @author zhengxl
 * @since 2024-07-19 14:49:54
 */
public interface CrmUserRelationDao {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmUserRelation queryById(Long id);

    /**
     * 查询指定行数据
     *
     * @param crmUserRelation 查询条件
     * @return 对象列表
     */
    List<CrmUserRelation> queryByPage(CrmUserRelationVO crmUserRelation);

    /**
     * 统计总行数
     *
     * @param crmUserRelation 查询条件
     * @return 总行数
     */
    long count(CrmUserRelation crmUserRelation);

    /**
     * 新增数据
     *
     * @param crmUserRelation 实例对象
     * @return 影响行数
     */
    int insert(CrmUserRelation crmUserRelation);

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmUserRelation> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<CrmUserRelation> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmUserRelation> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<CrmUserRelation> entities);

    /**
     * 修改数据
     *
     * @param crmUserRelation 实例对象
     * @return 影响行数
     */
    int update(CrmUserRelation crmUserRelation);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 影响行数
     */
    int deleteById(Long id);

}

