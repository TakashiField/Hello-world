package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmGradeRule;
import com.chinatechstar.crm.entity.CrmGradeTemplateDetail;
import com.chinatechstar.crm.vo.CrmGradeTemplateDetailVO;

import java.util.List;

/**
 * 等级模板明细表(CrmGradeTemplateDetail)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-02 10:58:36
 */
public interface CrmGradeTemplateDetailService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmGradeTemplateDetail queryById(Long id);

    /**
     * 分页查询
     *
     * @param crmGradeTemplateDetail 筛选条件
     * @return 查询结果
     */
    List<CrmGradeTemplateDetail> queryByPage(CrmGradeTemplateDetail crmGradeTemplateDetail);

    /**
     * 新增数据
     *
     * @param crmGradeTemplateDetail 实例对象
     * @return 实例对象
     */
    CrmGradeTemplateDetail insert(CrmGradeTemplateDetail crmGradeTemplateDetail);

    /**
     * 修改数据
     *
     * @param crmGradeTemplateDetail 实例对象
     * @return 实例对象
     */
    CrmGradeTemplateDetail update(CrmGradeTemplateDetail crmGradeTemplateDetail);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Long id);

    List<CrmGradeTemplateDetail> queryDetailByType(CrmGradeTemplateDetailVO templateType);

    void turnOn(CrmGradeRule crmGradeRule);

    void turnOff(CrmGradeRule crmGradeRule);

    void selectOn(CrmGradeRule crmGradeRule);
}
