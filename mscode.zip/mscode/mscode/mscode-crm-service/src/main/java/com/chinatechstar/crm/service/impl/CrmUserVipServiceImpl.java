package com.chinatechstar.crm.service.impl;

import com.chinatechstar.component.commons.result.PaginationBuilder;
import com.chinatechstar.crm.entity.CrmUserRelation;
import com.chinatechstar.crm.entity.CrmUserVip;
import com.chinatechstar.crm.dao.CrmUserVipDao;
import com.chinatechstar.crm.service.CrmUserVipService;
import com.chinatechstar.crm.vo.CrmUserVipVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 消费会员列表(CrmUserVip)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:02
 */
@Service("crmUserVipService")
public class CrmUserVipServiceImpl implements CrmUserVipService {
    @Autowired
    private CrmUserVipDao crmUserVipDao;

    /**
     * 通过ID查询单条数据
     *
     * @param userId 主键
     * @return 实例对象
     */
    @Override
    public CrmUserVip queryById(Long userId) {
        return this.crmUserVipDao.queryById(userId);
    }

    /**
     * 分页查询
     *
     * @param crmUserVip 筛选条件
     * @return 查询结果
     */
    @Override
    public Map<String,Object> queryByPage(CrmUserVipVO crmUserVip) {
        //long total = this.crmUserVipDao.count(crmUserVip);
        PageHelper.startPage(crmUserVip.getCurrentPage(),crmUserVip.getPageSize());
        List<CrmUserVip> crmUserVips = this.crmUserVipDao.queryAllByPage(crmUserVip);
        crmUserVip.setCrmList(crmUserVips);
        PageInfo<CrmUserVip> pageInfo = new PageInfo<>(crmUserVips);
        crmUserVip.setTotalSize( pageInfo.getTotal() );
        crmUserVip.setTotalPage( pageInfo.getPages() );
        return PaginationBuilder.buildResultObject(crmUserVips, pageInfo.getTotal(), crmUserVip.getCurrentPage(), crmUserVip.getPageSize());
    }


    /**
     * 新增数据
     *
     * @param crmUserVip 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserVip insert(CrmUserVip crmUserVip) {
        this.crmUserVipDao.insert(crmUserVip);
        return crmUserVip;
    }

    /**
     * 修改数据
     *
     * @param crmUserVip 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserVip update(CrmUserVip crmUserVip) {
        this.crmUserVipDao.update(crmUserVip);
        return this.queryById(crmUserVip.getUserId());
    }

    /**
     * 通过主键删除数据
     *
     * @param userId 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long userId) {
        return this.crmUserVipDao.deleteById(userId) > 0;
    }
}
