package com.chinatechstar.crm.upload;

import org.springframework.web.multipart.MultipartFile;

public interface CrmUploadService {

    void upload(MultipartFile file);
}
