package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.constants.CrmConstants;
import com.chinatechstar.crm.entity.CrmParam;
import com.chinatechstar.crm.service.CrmParamService;
import com.chinatechstar.crm.vo.CrmParamVO;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 选项参数表(CrmParam)表控制层
 *
 * @author zhengxl
 * @since 2024-07-18 16:49:15
 */
@RestController
@RequestMapping("crmParam")
public class CrmParamController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmParamService crmParamService;

    /**
     * 分页查询
     *
     * @param crmParam 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage(@Validated CrmParamVO crmParam) {
        Map<String,Object> data = this.crmParamService.queryByPage(crmParam);
        return ResultBuilder.buildListSuccess(data);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {
        return ResultBuilder.buildListSuccess(this.crmParamService.queryById(id));
    }

    /**
     * 新增数据
     *
     * @param crmParam 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody CrmParam crmParam) {
        this.crmParamService.insert(crmParam);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmParam 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody CrmParam crmParam) {
        this.crmParamService.update(crmParam);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Long id) {
        this.crmParamService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }


    @GetMapping("/queryByPageParent")
    public ListResult<Object> queryByPageParent(@RequestBody CrmParamVO crmParam) {
        List<CrmParam> crmParams = this.crmParamService.queryByPageParent(crmParam);
        crmParam.setCrmList(crmParams);
        return ResultBuilder.buildListSuccess(crmParam);
    }

    /**
     * 启用
     *
     * @param crmParam 实体
     * @return 编辑结果
     */
    @PostMapping("/turnOn")
    public ActionResult turnOn(CrmParam crmParam) {
        crmParam.setStatus(CrmConstants.STATUS_ON);
        this.crmParamService.update(crmParam);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 停用
     *
     * @param crmParam 实体
     * @return 编辑结果
     */
    @PostMapping("/turnOff")
    public ActionResult turnOff(CrmParam crmParam) {
        crmParam.setStatus(CrmConstants.STATUS_OFF);
        this.crmParamService.update(crmParam);
        return ResultBuilder.buildActionSuccess();
    }
}

