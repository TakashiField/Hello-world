package com.chinatechstar.crm.service.impl;

import com.chinatechstar.component.commons.result.PaginationBuilder;
import com.chinatechstar.component.commons.utils.UUIDUtil;
import com.chinatechstar.crm.entity.CrmRelationName;
import com.chinatechstar.crm.entity.CrmUserRelation;
import com.chinatechstar.crm.dao.CrmUserRelationDao;
import com.chinatechstar.crm.service.CrmUserRelationService;
import com.chinatechstar.crm.util.DateUtils;
import com.chinatechstar.crm.vo.CrmUserRelationVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 用户关系管理(CrmUserRelation)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-19 14:49:54
 */
@Service("crmUserRelationService")
public class CrmUserRelationServiceImpl implements CrmUserRelationService {
    @Autowired
    private CrmUserRelationDao crmUserRelationDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmUserRelation queryById(Long id) {
        return this.crmUserRelationDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param vo 筛选条件
     * @return 查询结果
     */
    @Override
    public Map<String, Object> queryByPage(CrmUserRelationVO vo) {
        PageHelper.startPage(vo.getCurrentPage(),vo.getPageSize(),true);
        List<CrmUserRelation> relationList = this.crmUserRelationDao.queryByPage(vo);
        vo.setCrmList(relationList);
        PageInfo<CrmUserRelation> pageInfo = new PageInfo<>(relationList);
        vo.setTotalSize( pageInfo.getTotal() );
        vo.setTotalPage( pageInfo.getPages() );
        return PaginationBuilder.buildResultObject(relationList, pageInfo.getTotal(), vo.getCurrentPage(), vo.getPageSize());
    }


    /**
     * 新增数据
     *
     * @param crmUserRelation 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserRelation insert(CrmUserRelation crmUserRelation) {
        CrmUserRelation select = new CrmUserRelation();
        select.setName(crmUserRelation.getName());
        select.setRelationName(crmUserRelation.getRelationName());
        select.setType(crmUserRelation.getType());
        long count = this.crmUserRelationDao.count(select);
        if (count > 0){
            throw new RuntimeException("该关系人信息名称已存在");
        } else {
            crmUserRelation.setId(UUIDUtil.snowflakeId());
            crmUserRelation.setCreateTime(DateUtils.timestamp());
            this.crmUserRelationDao.insert(crmUserRelation);
            return crmUserRelation;
        }
    }

    /**
     * 修改数据
     *
     * @param crmUserRelation 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserRelation update(CrmUserRelation crmUserRelation) {
        crmUserRelation.setUpdateTime(DateUtils.timestamp());
        this.crmUserRelationDao.update(crmUserRelation);
        return this.queryById(crmUserRelation.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return this.crmUserRelationDao.deleteById(id) > 0;
    }
}
