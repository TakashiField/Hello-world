package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmUserGys;
import com.chinatechstar.crm.service.CrmUserGysService;
import com.chinatechstar.crm.vo.CrmUserGysVO;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 供应商列表(CrmUserGys)表控制层
 *
 * @author zhengxl
 * @since 2024-07-05 10:01:59
 */
@RestController
@RequestMapping("crmUserGys")
public class CrmUserGysController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmUserGysService crmUserGysService;

    /**
     * 分页查询
     *
     * @param crmUserGys 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage(@RequestBody CrmUserGysVO crmUserGys) {
        List<CrmUserGys> result = this.crmUserGysService.queryByPage(crmUserGys);
        crmUserGys.setCrmList(result);
        return ResultBuilder.buildListSuccess(crmUserGys);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {

        CrmUserGys crmUserGys = this.crmUserGysService.queryById(id);
        return ResultBuilder.buildListSuccess(crmUserGys);
    }

    /**
     * 新增数据
     *
     * @param crmUserGys 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody CrmUserGys crmUserGys) {
        this.crmUserGysService.insert(crmUserGys);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmUserGys 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody CrmUserGys crmUserGys) {
        this.crmUserGysService.update(crmUserGys);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Long id) {
        this.crmUserGysService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

}

