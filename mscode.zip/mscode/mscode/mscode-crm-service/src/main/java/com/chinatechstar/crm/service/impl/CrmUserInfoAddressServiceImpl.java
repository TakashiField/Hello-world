package com.chinatechstar.crm.service.impl;

import com.chinatechstar.component.commons.result.PaginationBuilder;
import com.chinatechstar.component.commons.utils.SequenceGenerator;
import com.chinatechstar.crm.entity.CrmUserInfoAddress;
import com.chinatechstar.crm.dao.CrmUserInfoAddressDao;
import com.chinatechstar.crm.entity.CrmUserInfoGraduation;
import com.chinatechstar.crm.service.CrmUserInfoAddressService;
import com.chinatechstar.crm.util.DateUtils;
import com.chinatechstar.crm.vo.CrmUserInfoAddressVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员地址信息表(CrmUserInfoAddress)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:02
 */
@Service("crmUserInfoAddressService")
public class CrmUserInfoAddressServiceImpl implements CrmUserInfoAddressService {

    private static final SequenceGenerator sequenceGenerator = new SequenceGenerator();
    @Autowired
    private CrmUserInfoAddressDao crmUserInfoAddressDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmUserInfoAddress queryById(Long id) {
        return this.crmUserInfoAddressDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param crmUserInfoAddress 筛选条件
     * @return 查询结果
     */
    @Override
    public Map<String, Object> queryByPage(CrmUserInfoAddressVO crmUserInfoAddress) {
        PageHelper.startPage(crmUserInfoAddress.getCurrentPage(),crmUserInfoAddress.getPageSize(),true);

        List<CrmUserInfoAddress> addressList = this.crmUserInfoAddressDao.queryAllByPage(crmUserInfoAddress);
        PageInfo<CrmUserInfoAddress> pageInfo = new PageInfo<>(addressList);
        return PaginationBuilder.buildResultObject(addressList, pageInfo.getTotal(), crmUserInfoAddress.getCurrentPage(), crmUserInfoAddress.getPageSize());

    }


    /**
     * 新增数据
     *
     * @param crmUserInfoAddress 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserInfoAddress insert(CrmUserInfoAddress crmUserInfoAddress) {
        crmUserInfoAddress.setId(sequenceGenerator.nextId());
        //crmUserInfoAddress.setUserId(crmUserInfoAddress.getUserId());
        crmUserInfoAddress.setCreateUser(crmUserInfoAddress.getOperatorName());
        crmUserInfoAddress.setCreateTime(DateUtils.timestamp());
        this.crmUserInfoAddressDao.insert(crmUserInfoAddress);
        return crmUserInfoAddress;
    }

    /**
     * 修改数据
     *
     * @param crmUserInfoAddress 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserInfoAddress update(CrmUserInfoAddress crmUserInfoAddress) {
        crmUserInfoAddress.setUpdateTime(DateUtils.timestamp());
        crmUserInfoAddress.setUpdateUser(crmUserInfoAddress.getOperatorName());
        this.crmUserInfoAddressDao.update(crmUserInfoAddress);
        return this.queryById(crmUserInfoAddress.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return this.crmUserInfoAddressDao.deleteById(id) > 0;
    }
}
