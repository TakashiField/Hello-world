package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmRelationManager;
import com.chinatechstar.crm.service.CrmRelationManagerService;
import com.chinatechstar.crm.vo.CrmPersonInfo;
import com.chinatechstar.crm.vo.CrmRelationManagerVO;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * 会员关系管理表(CrmRelationManager)表控制层
 *
 * @author makejava
 * @since 2024-06-26 09:59:17
 */
@RestController
@RequestMapping("crmRelationManager")
public class CrmRelationManagerController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmRelationManagerService crmRelationManagerService;



    /**
     * 分页查询
     * @param vo    筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage( @Validated CrmRelationManagerVO vo) {

        List<CrmRelationManager> result = this.crmRelationManagerService.queryByPage(vo);
        vo.setCrmList(result);
        return ResultBuilder.buildListSuccess(vo);
    }


    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {
        CrmRelationManager result = this.crmRelationManagerService.queryById(id);
        return ResultBuilder.buildListSuccess(result);
    }

    /**
     * 新增数据
     *
     * @param crmRelationManager 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody @Validated CrmRelationManager crmRelationManager) {

        this.crmRelationManagerService.insert(crmRelationManager);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmRelationManager 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody @Validated CrmRelationManager crmRelationManager) {
        this.crmRelationManagerService.update(crmRelationManager);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Long id) {
        this.crmRelationManagerService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

    @GetMapping("/queryByMchtId")
    public ListResult<Object> queryByMchtId(@Validated CrmRelationManagerVO vo) {

        List<CrmRelationManager> result = this.crmRelationManagerService.queryByMchtId(vo);
        vo.setCrmList(result);
        return ResultBuilder.buildListSuccess(vo);
    }

    @GetMapping("/queryRelationByUserId")
    public ListResult<Object> queryRelationByUserId(@Validated CrmRelationManagerVO vo) {

        List<CrmRelationManager> result = this.crmRelationManagerService.queryRelationByUserId(vo);
        vo.setCrmList(result);
        return ResultBuilder.buildListSuccess(vo);
    }

    @GetMapping("/queryByUserIdRelationTypeRelationName")
    public ListResult<Object> queryByUserIdRelationTypeRelationName(@Validated CrmRelationManagerVO vo) {

        List<CrmRelationManager> result = this.crmRelationManagerService.queryByUserIdRelationTypeRelationName(vo);
        vo.setCrmList(result);
        return ResultBuilder.buildListSuccess(vo);
    }

    @GetMapping("/selectIdNoByNameMchtId")
    public ListResult<Object> selectIdNoByNameMchtId(@Validated CrmRelationManagerVO vo) {

        List<CrmPersonInfo> result = this.crmRelationManagerService.selectIdNoByNameMchtId(vo);
        vo.setCrmList(result);
        return ResultBuilder.buildListSuccess(vo);
    }


}

