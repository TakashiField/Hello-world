package com.chinatechstar.crm.dao;


import com.chinatechstar.crm.entity.CrmRulesDown;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 会员升级规则(CrmRulesDown)表数据库访问层
 *
 * @author zhengxl
 * @since 2024-07-03 12:43:14
 */
public interface CrmRulesDownDao {

    /**
     * 通过ID查询单条数据
     *
     * @param ruleId 主键
     * @return 实例对象
     */
    CrmRulesDown queryById(Long ruleId);

    /**
     * 查询指定行数据
     *
     * @param crmRulesDown 查询条件
     * @return 对象列表
     */
    List<CrmRulesDown> queryAllByPage(CrmRulesDown crmRulesDown);

    /**
     * 统计总行数
     *
     * @param crmRulesDown 查询条件
     * @return 总行数
     */
    long count(CrmRulesDown crmRulesDown);

    /**
     * 新增数据
     *
     * @param crmRulesDown 实例对象
     * @return 影响行数
     */
    int insert(CrmRulesDown crmRulesDown);

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmRulesDown> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<CrmRulesDown> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmRulesDown> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<CrmRulesDown> entities);

    /**
     * 修改数据
     *
     * @param crmRulesDown 实例对象
     * @return 影响行数
     */
    int update(CrmRulesDown crmRulesDown);

    /**
     * 通过主键删除数据
     *
     * @param ruleId 主键
     * @return 影响行数
     */
    int deleteById(Long ruleId);

    List<CrmRulesDown> queryByIds(String[] ids);
}

