package com.chinatechstar.crm.util;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.util
 * @Author: zhengxiaolei
 * @CreateTime: 2024-06-13 10-17
 * @Description: TODO
 * @Version: 1.0
 */
public class CrmUtils {

    private static final String CODE = "0000";

    private static final String MSG = "SUCCESS";

}
