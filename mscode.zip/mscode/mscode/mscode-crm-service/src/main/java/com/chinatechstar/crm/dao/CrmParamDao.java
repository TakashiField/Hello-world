package com.chinatechstar.crm.dao;

import com.chinatechstar.crm.entity.CrmParam;
import com.chinatechstar.crm.vo.CrmParamVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 选项参数表(CrmParam)表数据库访问层
 *
 * @author zhengxl
 * @since 2024-07-18 16:49:16
 */
public interface CrmParamDao {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmParam queryById(Long id);

    /**
     * 查询指定行数据
     *
     * @param crmParam 查询条件
     * @return 对象列表
     */
    List<CrmParam> queryAllByPage(CrmParamVO crmParam);

    /**
     * 统计总行数
     *
     * @param crmParam 查询条件
     * @return 总行数
     */
    long count(CrmParam crmParam);

    /**
     * 新增数据
     *
     * @param crmParam 实例对象
     * @return 影响行数
     */
    int insert(CrmParam crmParam);

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmParam> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<CrmParam> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmParam> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<CrmParam> entities);

    /**
     * 修改数据
     *
     * @param crmParam 实例对象
     * @return 影响行数
     */
    int update(CrmParam crmParam);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 影响行数
     */
    int deleteById(Long id);

}

