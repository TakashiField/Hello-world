package com.chinatechstar.crm.util;

import java.util.Random;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.util
 * @Author: zhengxiaolei
 * @CreateTime: 2024-12-03 15-29
 * @Description: 短信工具类
 * @Version: 1.0
 */
public class SmsUtils {

    public static String genSmsCode() {
        Random random = new Random();
        int code = random.nextInt(999999) + 100000;
        return String.valueOf(code);
    }
}
