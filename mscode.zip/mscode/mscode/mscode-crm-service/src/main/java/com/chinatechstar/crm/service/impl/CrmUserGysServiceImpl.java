package com.chinatechstar.crm.service.impl;

import com.chinatechstar.crm.entity.CrmUserGys;
import com.chinatechstar.crm.dao.CrmUserGysDao;
import com.chinatechstar.crm.service.CrmUserGysService;
import com.chinatechstar.crm.vo.CrmUserGysVO;
import com.github.pagehelper.PageHelper;
import org.springframework.stereotype.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 供应商列表(CrmUserGys)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:00
 */
@Service("crmUserGysService")
public class CrmUserGysServiceImpl implements CrmUserGysService {
    @Autowired
    private CrmUserGysDao crmUserGysDao;

    /**
     * 通过ID查询单条数据
     *
     * @param userId 主键
     * @return 实例对象
     */
    @Override
    public CrmUserGys queryById(Long userId) {
        return this.crmUserGysDao.queryById(userId);
    }

    /**
     * 分页查询
     *
     * @param crmUserGys 筛选条件
     * @return 查询结果
     */
    @Override
    public List<CrmUserGys> queryByPage(CrmUserGysVO crmUserGys) {
        //long total = this.crmUserGysDao.count(crmUserGys);
        PageHelper.startPage(crmUserGys.getCurrentPage(),crmUserGys.getPageSize());
        return (this.crmUserGysDao.queryAllByPage(crmUserGys));
    }


    /**
     * 新增数据
     *
     * @param crmUserGys 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserGys insert(CrmUserGys crmUserGys) {
        this.crmUserGysDao.insert(crmUserGys);
        return crmUserGys;
    }

    /**
     * 修改数据
     *
     * @param crmUserGys 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserGys update(CrmUserGys crmUserGys) {
        this.crmUserGysDao.update(crmUserGys);
        return this.queryById(crmUserGys.getUserId());
    }

    /**
     * 通过主键删除数据
     *
     * @param userId 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long userId) {
        return this.crmUserGysDao.deleteById(userId) > 0;
    }
}
