package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmUserHonor;
import com.chinatechstar.crm.vo.CrmUserHonorVO;

import java.util.List;

/**
 * 会员荣誉列表(CrmUserHonor)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:01
 */
public interface CrmUserHonorService {

    /**
     * 通过ID查询单条数据
     *
     * @param userId 主键
     * @return 实例对象
     */
    CrmUserHonor queryById(Long userId);

    /**
     * 分页查询
     *
     * @param crmUserHonor 筛选条件
     * @return 查询结果
     */
    List<CrmUserHonor> queryByPage(CrmUserHonorVO crmUserHonor);

    /**
     * 新增数据
     *
     * @param crmUserHonor 实例对象
     * @return 实例对象
     */
    CrmUserHonor insert(CrmUserHonor crmUserHonor);

    /**
     * 修改数据
     *
     * @param crmUserHonor 实例对象
     * @return 实例对象
     */
    CrmUserHonor update(CrmUserHonor crmUserHonor);

    /**
     * 通过主键删除数据
     *
     * @param userId 主键
     * @return 是否成功
     */
    boolean deleteById(Long userId);

}
