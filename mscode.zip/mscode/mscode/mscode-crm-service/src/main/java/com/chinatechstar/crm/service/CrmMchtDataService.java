package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmMchtData;
import com.chinatechstar.crm.vo.CrmMchtDataVO;

import java.util.List;


/**
 * 会员资料表(CrmMchtData)表服务接口
 *
 * @author makejava
 * @since 2024-06-19 16:57:41
 */
public interface CrmMchtDataService {

    /**
     * 通过ID查询单条数据
     *
     * @param dataId 主键
     * @return 实例对象
     */
    CrmMchtData queryById(Long dataId);

    /**
     * 分页查询
     *
     * @param crmMchtData 筛选条件
     * @return 查询结果
     */
    List<CrmMchtData> queryByPage(CrmMchtDataVO crmMchtData);


    /**
     * 新增数据
     *
     * @param crmMchtData 实例对象
     * @return 实例对象
     */
    CrmMchtData insert(CrmMchtData crmMchtData);

    /**
     * 修改数据
     *
     * @param crmMchtData 实例对象
     * @return 实例对象
     */
    CrmMchtData update(CrmMchtData crmMchtData);

    /**
     * 通过主键删除数据
     *
     * @param dataId 主键
     * @return 是否成功
     */
    boolean deleteById(Long dataId);

    List<CrmMchtData> queryAllByLimit(CrmMchtDataVO crmMchtDataVO);
}
