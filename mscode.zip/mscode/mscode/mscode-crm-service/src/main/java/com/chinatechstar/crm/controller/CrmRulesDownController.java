package com.chinatechstar.crm.controller;



import com.chinatechstar.crm.entity.CrmRulesDown;
import com.chinatechstar.crm.service.CrmRulesDownService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员升级规则(CrmRulesDown)表控制层
 *
 * @author zhengxl
 * @since 2024-07-03 12:43:14
 */
@RestController
@RequestMapping("crmRulesDown")
public class CrmRulesDownController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmRulesDownService crmRulesDownService;

    /**
     * 分页查询
     *
     * @param crmRulesDown 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ResponseEntity<List<CrmRulesDown>> queryByPage(@RequestBody CrmRulesDown crmRulesDown) {
        return ResponseEntity.ok(this.crmRulesDownService.queryByPage(crmRulesDown));
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ResponseEntity<CrmRulesDown> queryById(Long id) {
        return ResponseEntity.ok(this.crmRulesDownService.queryById(id));
    }

    /**
     * 新增数据
     *
     * @param crmRulesDown 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ResponseEntity<CrmRulesDown> add(@RequestBody CrmRulesDown crmRulesDown) {
        return ResponseEntity.ok(this.crmRulesDownService.insert(crmRulesDown));
    }

    /**
     * 编辑数据
     *
     * @param crmRulesDown 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ResponseEntity<CrmRulesDown> edit(@RequestBody CrmRulesDown crmRulesDown) {
        return ResponseEntity.ok(this.crmRulesDownService.update(crmRulesDown));
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ResponseEntity<Boolean> deleteById(Long id) {
        return ResponseEntity.ok(this.crmRulesDownService.deleteById(id));
    }

}

