package com.chinatechstar.crm.service.impl;

import com.chinatechstar.component.commons.utils.UUIDUtil;
import com.chinatechstar.crm.entity.CrmRelationName;
import com.chinatechstar.crm.dao.CrmRelationNameDao;
import com.chinatechstar.crm.entity.CrmRelationSymbol;
import com.chinatechstar.crm.service.CrmRelationNameService;
import com.chinatechstar.crm.util.DateUtils;
import com.chinatechstar.crm.vo.CrmRelationNameVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 会员关系名称表(CrmRelationName)表服务实现类
 *
 * @author makejava
 * @since 2024-06-26 09:59:19
 */
@Service("crmRelationNameService")
public class CrmRelationNameServiceImpl implements CrmRelationNameService {
    @Resource
    private CrmRelationNameDao crmRelationNameDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmRelationName queryById(Long id) {
        return this.crmRelationNameDao.queryById(id);
    }

    /*
     * 分页查询
     *
     * @param  vo 筛选条件
     * @return 查询结果
     */
    @Override
    public List<CrmRelationName> queryByPage(CrmRelationNameVO vo) {
        PageHelper.startPage(vo.getCurrentPage(),vo.getPageSize(),true);
        List<CrmRelationName> relationNameList = this.crmRelationNameDao.queryByPage(vo);
        PageInfo<CrmRelationName> pageInfo = new PageInfo<>(relationNameList);
        vo.setTotalSize( pageInfo.getTotal() );
        vo.setTotalPage( pageInfo.getPages() );
        return relationNameList;
    }


    /**
     * 新增数据
     *
     * @param crmRelationName 实例对象
     * @return 实例对象
     */
    @Override
    public CrmRelationName insert(CrmRelationName crmRelationName) {
        CrmRelationName select = new CrmRelationName();
        select.setRelationType(crmRelationName.getRelationType());
        select.setRelationName(crmRelationName.getRelationName());
        long count = this.crmRelationNameDao.count(select);
        if (count > 0){
            throw new RuntimeException("该关系名称已存在");
        } else {
            crmRelationName.setId(UUIDUtil.snowflakeId());
            crmRelationName.setCreateTime(DateUtils.timestamp());
            this.crmRelationNameDao.insert(crmRelationName);
            return crmRelationName;
        }
    }

    /**
     * 修改数据
     *
     * @param crmRelationName 实例对象
     * @return 实例对象
     */
    @Override
    public CrmRelationName update(CrmRelationName crmRelationName) {
        crmRelationName.setUpdateTime(DateUtils.timestamp());
        this.crmRelationNameDao.update(crmRelationName);
        return this.queryById(crmRelationName.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return this.crmRelationNameDao.deleteById(id) > 0;
    }
}
