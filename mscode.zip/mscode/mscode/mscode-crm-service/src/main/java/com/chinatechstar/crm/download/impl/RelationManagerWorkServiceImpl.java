package com.chinatechstar.crm.download.impl;

import com.chinatechstar.component.commons.utils.FileUtils;
import com.chinatechstar.crm.download.ICrmDownloadService;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.download.impl
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-31 16-26
 * @Description: TODO
 * @Version: 1.0
 */
@Service
public class RelationManagerWorkServiceImpl implements ICrmDownloadService {

    /**
     * @param filename
     * @param url
     * @param response
     */
    @Override
    public void download(HttpServletResponse response) {

        String filename = "CrmRelationManagerWorkTemplate.xlxs";
        String url = "/template";
        try {
            FileUtils.downloadFile(filename,url,response);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
