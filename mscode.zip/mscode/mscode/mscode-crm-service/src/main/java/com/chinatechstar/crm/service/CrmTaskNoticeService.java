package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmTaskNotice;
import com.chinatechstar.crm.vo.CrmTaskNoticeVO;

import java.util.List;

/**
 * 通知提醒表(CrmTaskNotice)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-15 10:54:04
 */
public interface CrmTaskNoticeService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmTaskNotice queryById(Long id);

    /**
     * 分页查询
     *
     * @param crmTaskNotice 筛选条件
     * @return 查询结果
     */
    List<CrmTaskNotice> queryByPage(CrmTaskNoticeVO crmTaskNotice);

    /**
     * 新增数据
     *
     * @param crmTaskNotice 实例对象
     * @return 实例对象
     */
    CrmTaskNotice insert(CrmTaskNotice crmTaskNotice);

    /**
     * 修改数据
     *
     * @param crmTaskNotice 实例对象
     * @return 实例对象
     */
    CrmTaskNotice update(CrmTaskNotice crmTaskNotice);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Long id);

}
