package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmRelationType;
import com.chinatechstar.crm.service.CrmRelationTypeService;
import com.chinatechstar.crm.vo.CrmRelationTypeVO;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * 会员关系类别表(CrmRelationType)表控制层
 *
 * @author makejava
 * @since 2024-06-26 09:59:20
 */
@RestController
@RequestMapping("crmRelationType")
public class CrmRelationTypeController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmRelationTypeService crmRelationTypeService;


    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {
        CrmRelationType relationType = this.crmRelationTypeService.query(id);
        return ResultBuilder.buildListSuccess(relationType);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param vo 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage(@Validated CrmRelationTypeVO vo) {
        List<CrmRelationType> crmRelationType = crmRelationTypeService.queryByPage(vo);
        vo.setCrmList(crmRelationType);
        ListResult<Object> result = ResultBuilder.buildListSuccess(vo);
        return result;
    }

    /**
     * 新增数据
     *
     * @param crmRelationType 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody @Validated CrmRelationType crmRelationType) {
        this.crmRelationTypeService.insert(crmRelationType);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmRelationType 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody @Validated CrmRelationType crmRelationType) {
        this.crmRelationTypeService.update(crmRelationType);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @DeleteMapping("/delete")
    public ActionResult deleteById(Long id) {
        this.crmRelationTypeService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

}

