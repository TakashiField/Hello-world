package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmPropertyCustomedValue;

import java.util.List;


/**
 * 自定义标签值表(CrmPropertyCustomedValue)表服务接口
 *
 * @author makejava
 * @since 2024-06-24 17:20:23
 */
public interface CrmPropertyCustomedValueService {

    /**
     * 通过ID查询单条数据
     *
     * @param userId 主键
     * @return 实例对象
     */
    List<CrmPropertyCustomedValue> queryById(Long userId);

    /**
     * 分页查询
     *
     * @param crmPropertyCustomedValue 筛选条件
     * @param pageRequest              分页对象
     * @return 查询结果
     */

    /**
     * 新增数据
     *
     * @param crmPropertyCustomedValue 实例对象
     * @return 实例对象
     */
    CrmPropertyCustomedValue insert(CrmPropertyCustomedValue crmPropertyCustomedValue);

    /**
     * 修改数据
     *
     * @param crmPropertyCustomedValue 实例对象
     * @return 实例对象
     */
    CrmPropertyCustomedValue update(CrmPropertyCustomedValue crmPropertyCustomedValue);

    /**
     * 通过主键删除数据
     *
     * @param userId 主键
     * @return 是否成功
     */
    boolean deleteById(String userId);

}
