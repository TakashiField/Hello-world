package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmUserInfoAddress;
import com.chinatechstar.crm.service.CrmUserInfoAddressService;
import com.chinatechstar.crm.vo.CrmUserInfoAddressVO;
import com.github.pagehelper.PageHelper;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员地址信息表(CrmUserInfoAddress)表控制层
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:01
 */
@RestController
@RequestMapping("crmUserInfoAddress")
public class CrmUserInfoAddressController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmUserInfoAddressService crmUserInfoAddressService;

    /**
     * 分页查询
     *
     * @param crmUserInfoAddress 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage( @Validated CrmUserInfoAddressVO crmUserInfoAddress) {
        Map<String,Object> data = this.crmUserInfoAddressService.queryByPage(crmUserInfoAddress);
        return ResultBuilder.buildListSuccess(data);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {
        return ResultBuilder.buildListSuccess(this.crmUserInfoAddressService.queryById(id));
    }

    /**
     * 新增数据
     *
     * @param crmUserInfoAddress 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody CrmUserInfoAddress crmUserInfoAddress) {
        this.crmUserInfoAddressService.insert(crmUserInfoAddress);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmUserInfoAddress 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody CrmUserInfoAddress crmUserInfoAddress) {
        this.crmUserInfoAddressService.update(crmUserInfoAddress);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Long id) {
        this.crmUserInfoAddressService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

}

