package com.chinatechstar.crm.util;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.util
 * @Author: zhengxiaolei
 * @CreateTime: 2024-11-25 16-57
 * @Description: TODO
 * @Version: 1.0
 */

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FtpUtils {

    private static final FTPClient ftpClient = new FTPClient();

    public static void connect(String host, int port, String username, String password) throws IOException {
        ftpClient.connect(host, port);
        int replyCode = ftpClient.getReplyCode();
        if (!FTPReply.isPositiveCompletion(replyCode)) {
            ftpClient.disconnect();
            throw new IOException("FTP server refused connection");
        }
        boolean success = ftpClient.login(username, password);
        if (!success) {
            ftpClient.logout();
            throw new IOException("FTP login failed");
        }
    }

    public static void disconnect() {
        if (ftpClient.isConnected()) {
            try {
                ftpClient.logout();
                ftpClient.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static List<String> listFiles(String directory) throws IOException {
        List<String> fileNames = new ArrayList<>();
        ftpClient.changeWorkingDirectory(directory);
        String[] names = ftpClient.listNames();
        Collections.addAll(fileNames, names);
        return fileNames;
    }

    public static void uploadFile(String localFilePath, String remoteFilePath) throws IOException {
        InputStream inputStream = new FileInputStream(localFilePath);
        boolean done = ftpClient.storeFile(remoteFilePath, inputStream);
        inputStream.close();
        if (!done) {
            throw new IOException("File upload failed");
        }
    }

    public static void downloadFile(String remoteFilePath, String localFilePath) throws IOException {
        InputStream inputStream = ftpClient.retrieveFileStream(remoteFilePath);
        FileOutputStream outputStream = new FileOutputStream(localFilePath);
        byte[] buffer = new byte[1024];
        int bytesRead;
        while ((bytesRead = inputStream.read(buffer)) != -1) {
            outputStream.write(buffer, 0, bytesRead);
        }
        inputStream.close();
        outputStream.close();
    }
}


