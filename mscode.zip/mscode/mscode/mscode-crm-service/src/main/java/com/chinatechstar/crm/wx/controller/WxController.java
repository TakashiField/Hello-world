package com.chinatechstar.crm.wx.controller;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.controller.wx.controller
 * @Author: zhengxiaolei
 * @CreateTime: 2024-12-05 16-53
 * @Description: TODO
 * @Version: 1.0
 */
public class WxController {
}
