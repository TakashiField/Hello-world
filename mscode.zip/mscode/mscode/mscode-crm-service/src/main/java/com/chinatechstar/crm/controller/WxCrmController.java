//package com.chinatechstar.crm.controller;
//
//import com.alibaba.fastjson.JSONArray;
//import com.alibaba.fastjson.JSONObject;
//import com.chinatechstar.crm.util.HttpUtils;
//import com.chinatechstar.crm.util.MBPUtils;
//import com.guokai.config.BusinessException;
//import com.guokai.config.HttpCfg;
//import com.guokai.pojo.Account_info;
//import com.guokai.pojo.Client_order_info;
//import com.guokai.service.AccountInfoService;
//import com.guokai.service.ClientOrderInfoService;
//import com.guokai.service.DraftService;
//import com.guokai.service.MsgAuthCodeService;
//import com.guokai.utils.*;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang3.StringUtils;
//import org.apache.http.entity.StringEntity;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.http.HttpStatus;
//import org.springframework.stereotype.Component;
//
//import java.math.BigDecimal;
//import java.text.SimpleDateFormat;
//import java.util.*;
//
///**
// * @version:1.0（版本，具体版本信息自己来定）
// * @Description: 会员系统接入
// * @author: kp （作者,自己姓名的拼音简称）
// * @date: 2020年10月22日
// */
//@Slf4j
//@Component
//public class WxCrmController {
//
//    //	@Autowired
////	private ModelParaService modelParaService;
//    @Autowired
//    private AccountInfoService accountInfoService;
//    @Autowired
//    private MsgAuthCodeService msgAuthCodeService;
//    @Value("${mbp.crm.url}")
//    private String crmUrl;
//    @Value("${system.env}")
//    private String env;
//    @Autowired
//    private RedisUtilWX redisUtil;
//    @Autowired
//    private DraftService draftService;
//    @Autowired
//    private WxCrmController wxCrmController;
//    @Autowired
//    private BaiduSanWangUtil baiduSanWangUtil;
//    @Autowired
//    private ClientOrderInfoService clientOrderInfoService;
//
//    /**
//     * @param reqMap @return（展示方法参数和返回值）
//     * @Description:会员系统接入（方法功能描述）
//     */
//    public JSONObject execute(Map reqMap) throws Exception {
//
//        JSONObject respJson = new JSONObject();
//        JSONObject respHead = new JSONObject();
//        JSONObject respBody = new JSONObject();
//
//        Map head = (Map) reqMap.get("head");
//        Map body = (Map) reqMap.get("body");
//
//        String operFlag = (String) body.get("operFlag");
//        String transCode = (String) body.get("transCode");
//
//        switch (transCode) {
//            case "USR00007":// 短信验证码接口
//                respJson = commonSendMbp(reqMap);
//                Map respbody = (Map) respJson.get("body");
//                redisUtil.set(respbody.get("transno") + "" + respbody.get("sn") + "", respbody.get("sn") + "", 300);
//                break;
//            case "USR00009":// 短信信息接口
//                respJson = commonSendMbp(reqMap);
//                break;
//            case "CRM00001":// 会员注册修改等
//                respJson = commonSendMbp(reqMap);
//                break;
//            case "CRM60004":// 查询会员信息，
//                //通过查询账户信息获取账号类型发送到会员系统
//                String regname = (String) body.get("regname");
//                String regflag = (String) body.get("regflag");
//                if (regflag == null || "".equals(regflag)) {//如果为空查询数据库个人基本信息 保留以前代码 但是sql被修改成只查询client 由于授权登录查询只能查询一条
////				Map<String,Object> accountInfo  = accountInfoService.GetClientAccountByUsername(regname);
////				String accountType = (String) accountInfo.get("accountType");
////				if("Supplier".equals(accountType)) {//供应商
////					body.put("regflag", "1");
////				}else if ("Client".equals(accountType)){//个人
////					body.put("regflag", "0");
////				}
//                    body.put("regflag", "0");
//                }
//
//                respJson = commonSendMbp(reqMap);
//                break;
//            case "KEY00002":// 密码表
//                respJson = commonSendMbp(reqMap);
//                break;
//            case "CRM00002":// 会员实名
//                String draftType = (String) body.get("draftType"); //草稿类型 03商户实名认证 06店铺实名认证 07商户收单进件 08店铺收单进件
//                String supplierId = (String) body.get("supplierId");//店铺或者供应商ID
//                if (StringUtils.isEmpty(draftType) || StringUtils.isEmpty(supplierId)) {
//                    respHead.put("msgCode", "1001");
//                    respHead.put("msgMsg", "draftType或supplierId不能为空");
//                    respJson.put("head", respHead);
//                    return respJson;
//                }
//                respJson = commonSendMbp(reqMap);
//                JSONObject mbpHead = respJson.getJSONObject("head");
//                if (mbpHead.get("msgCode").equals("0")) {
//                    log.info("删除草稿记录supplierId:" + supplierId + ",draftType:" + draftType);
//                    draftService.deleteDraftInfo(null, supplierId, draftType);//删除草稿记录
//                }
//                //给管理员发送短信
//                wxCrmController.commonSendMbpObj(head, "", "国开管理员您好！有一个 实名 信息请到公众号审核");
//                break;
//            case "CRM10015":// 企业实名查询
//                respJson = commonSendMbp(reqMap);
//                break;
//            case "CRM10016":// 个人实名查询
//                respJson = commonSendMbp(reqMap);
//                break;
//            case "INT30001":// 积分余额查询(单笔)
//                //case "INT01019": //积分记账
//                //case "INT01020": //积分消费
//                String account = (String) body.get("account");
//                String busino = (String) body.get("busino");
//                String acctype = (String) body.get("acctype");
//                if (StringUtils.isEmpty(account) || StringUtils.isEmpty(busino) /*|| StringUtils.isEmpty(acctype)*/) {
//                    respHead.put("msgCode", "1001");
//                    respHead.put("msgMsg", "busino、account、acctype不能为空");
//                    respJson.put("head", respHead);
//                    return respJson;
//                }
//                respJson = commonSendMbp(reqMap);
//                JSONObject INTHead = respJson.getJSONObject("head");
//                if ("9005".equals(INTHead.get("msgCode"))) {
//                    respHead.put("msgCode", "1001");
//                    respHead.put("msgMsg", "请先进行实名认证");
//                    respJson.put("head", respHead);
//                }
//                break;
//            case "INT30002":// 积分明细查询
//                String account02 = (String) body.get("account");
//                String busino02 = (String) body.get("busino");
//                String acctype02 = (String) body.get("acctype");
//                if (StringUtils.isEmpty(account02) || StringUtils.isEmpty(busino02) || StringUtils.isEmpty(acctype02)) {
//                    respHead.put("msgCode", "1001");
//                    respHead.put("msgMsg", "busino、account、acctype不能为空");
//                    respJson.put("head", respHead);
//                    return respJson;
//                }
//                String timeType = (String) body.get("timeType");  // 0-全部 1-本月 2-近三个月 3-近一年
//                String startdate = "";
//                String enddate = "";
//                SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
//                Date now = new Date();
//
//                if (StringUtils.isEmpty(body.get("timeType")) || timeType.equals("0") || timeType.equals("3")) {
//                    enddate = sdf.format(now);
//                    Calendar calendar = Calendar.getInstance();
//                    calendar.setTime(now);
//                    calendar.add(Calendar.YEAR, -1);
//                    startdate = sdf.format(calendar.getTime());
//                } else if (timeType.equals("1")) {
//                    Calendar startCalendar = Calendar.getInstance();
//                    startCalendar.setTime(now);
//                    startCalendar.set(Calendar.DAY_OF_MONTH, 1);   //设置本月第一天
//                    startdate = sdf.format(startCalendar.getTime());
//
//                    Calendar endCalendar = Calendar.getInstance();
//                    endCalendar.setTime(now);
//                    //设置本月最后一天
//                    endCalendar.set(Calendar.DAY_OF_MONTH, endCalendar.getActualMaximum(Calendar.DAY_OF_MONTH));
//                    enddate = sdf.format(endCalendar.getTime());
//                } else if (timeType.equals("2")) {
//                    enddate = sdf.format(now);
//                    Calendar calendar = Calendar.getInstance();
//                    calendar.setTime(now);
//                    calendar.add(Calendar.MONTH, -3);
//                    startdate = sdf.format(calendar.getTime());
//                }
//                body.put("startdate", startdate);
//                body.put("enddate", enddate);
//                respJson = commonSendMbp(reqMap);
//                JSONObject resbody = respJson.getJSONObject("body");
//                String rownum = (String) resbody.get("rownum");
//                List<Map<String, Object>> detailList = new ArrayList<>();
//                if (rownum != null && rownum.equals("1")) { //最后一条数据特殊处理
//                    Map<String, Object> detail = resbody.getJSONObject("detail");
//                    //获取用户账号查询用户信息
//                    String orderno = String.valueOf(detail.get("orderno"));
//                    Client_order_info order = clientOrderInfoService.getClientOrderInfoByCrmOrderNo(orderno);
//                    detail.put("clientOrderNo", order == null ? orderno : order.getClient_order_no());
//                    detail.put("orderType", order == null ? "" : order.getOrder_type());
//                    detailList.add(detail);
//                    resbody.put("detail", detailList);
//                } else if (rownum != null && Integer.parseInt(rownum) > 1) {
//                    JSONArray list = resbody.getJSONArray("detail");
//                    for (int i = 0; i < list.size(); i++) {
//                        JSONObject info = list.getJSONObject(i);
//                        //获取用户账号查询用户信息
//                        String orderno = info.getString("orderno");
//                        Client_order_info order = clientOrderInfoService.getClientOrderInfoByCrmOrderNo(orderno);
//                        info.put("clientOrderNo", order == null ? orderno : order.getClient_order_no());
//                        info.put("orderType", order == null ? "" : order.getOrder_type());
//                    }
//                    resbody.put("detail", list);
//                } else {
//                    resbody.put("detail", detailList);
//                }
//                break;
//            case "INT30003":
//                List<Account_info> list = accountInfoService.danger();
//                List<String> error = new ArrayList<String>();
//                for (Account_info info : list) {
//                    String accountStr = info.getCrmaccount();
//                    String businoStr = "BUS888888";
//                    String account_id = info.getAccount_id() + "";
//                    if (accountStr == null || account_id == null) {
//                        error.add(account_id);
//                        continue;
//                    }
//                    body.put("account", accountStr);
//                    body.put("busino", businoStr);
//                    respJson = commonSendMbp(reqMap);
//                    JSONObject xbtHead = respJson.getJSONObject("head");
//                    if (!"0".equals(xbtHead.get("msgCode"))) {
//                        error.add(account_id);
//                        if (error.size() > 20) {
//                            break;
//                        }
//                        continue;
//                    }
//                    Thread.sleep(100);
//                }
//                respBody.put("error", error);
//                respJson.put("body", respBody);
//                break;
//            case "INT300032":
//                body.put("transCode", "INT30003");
//                respJson = commonSendMbp(reqMap);
//                break;
//            case "INT01019": //积分充值
//            case "INT01020": //积分消费
//            case "INT01021": //钱包充值
//            case "INT01022": //钱包消费
//            case "INT07020": //积分退货
//            case "INT07021": //钱包退货
//            case "INT01023": //代金券充值
//            case "INT01024": //代金券消费
//            case "INT01025": //代金券扫码消费
//            case "INT07022": //代金券退款
//            case "INT01026": //钱包提现
//            case "INT07026": //钱包提现撤销
//                respJson = commonSendMbp(reqMap);
//                break;
//            default:
//                log.info("默认值");
//                break;
//        }
//
//        return respJson;
//    }
//
//    public String doPostJson(String url, String sendText) throws Exception {
//        HttpCfg cfg = new HttpCfg(30000, 30000, 30000);
//        StringEntity strEntity = new StringEntity(sendText, "utf-8");
//        Map<String, String> header = new HashMap<>();
//        return HttpUtils.doPostJson(url, header, sendText, cfg);
//        // HttpUtils.doPostJson(url, header, sendText, "utf-8", cfg);
//    }
//
//    /**
//     * 向公众号 管理员发送消息
//     *
//     * @param head    请求报文头
//     * @param phone   手机号
//     * @param sendmsg 发送的短信内容
//     * @throws Exception
//     * @return 返回成功数值 head body
//     */
//    public JSONObject commonSendMbpObj(Map head, String phone, String sendmsg) {
//        if (StringUtils.isEmpty(phone)) {//判断手机号为空 则 查询公众号的管理员手机号
//            List<Map<String, Object>> list = accountInfoService.queryAccountInfoOfficial();
//            phone = (String) list.get(0).get("account");
//        }
//        Map<String, Object> paraMap = new HashMap<String, Object>();
//        Map<String, Object> paraBody = new HashMap<String, Object>();
//        paraBody.put("transCode", "USR00009");
//        paraBody.put("sendmsg", sendmsg);
//        paraBody.put("telno", phone);
//        paraMap.put("body", paraBody);
//        paraMap.put("head", head);
//        return commonSendMbp(paraMap);
//    }
//
//    /**
//     * 向用户 发送消息
//     *
//     * @param head      请求报文头
//     * @param accountId 用户编号
//     * @param sendmsg   发送的短信内容
//     * @throws Exception
//     * @return 返回成功数值 head body
//     */
//    public JSONObject commonSendMbpObjByAccount(Map head, String accountId, String sendmsg) throws Exception {
//        Account_info bean = accountInfoService.getAccountByUserId(accountId);//通过商户编号或者个人个人编号查询accountName
//        String accountName = bean.getAccount_name();
//        if (StringUtils.isEmpty(accountName)) {//判断accountName 是否为空  是 通过手机号和Client 条件查询accountName
//            Account_info accountNameBean = accountInfoService.getAccountByUserName(bean.getAccount());
//            if (!StringUtils.isEmpty(accountNameBean.getAccount_name())) {
//                accountName = accountNameBean.getAccount_name();
//            }
//            if (!StringUtils.isEmpty(accountNameBean.getCrm_name())) {
//                accountName = accountNameBean.getCrm_name();
//            }
//        }
//        Map<String, Object> paraMap = new HashMap<String, Object>();
//        Map<String, Object> paraBody = new HashMap<String, Object>();
//        paraBody.put("transCode", "USR00009");
//        paraBody.put("sendmsg", accountName + sendmsg);
//        paraBody.put("telno", bean.getAccount());
//        paraMap.put("body", paraBody);
//        paraMap.put("head", head);
//        return commonSendMbp(paraMap);
//    }
//
//    /**
//     * @param map @return（展示方法参数和返回值）
//     * @Description: 发送短信
//     */
//    public JSONObject commonSendMbp(Map map) {
//
//        JSONObject respJson = new JSONObject();
//        JSONObject respHead = new JSONObject();
//
//        Map head = (Map) map.get("head");
//        Map body = (Map) map.get("body");
//
//        String transCode = (String) body.get("transCode");
//        String platForm = (String) head.get("platForm");
//
//        JSONObject headObj = MBPUtils.getCommonHead(transCode, platForm);
//        JSONObject dataObj = MBPUtils.getDataObj(body);
//
//
//        JSONObject sendObj = MBPUtils.getSendObj(headObj, dataObj);
//
//        log.info("发往mbp的请求报文sendText=" + sendObj);
//        String url = crmUrl;
//        String respStr = HttpUtils.doPostJsonNew(url, sendObj);
//        log.info("mbp返回内容respStr=" + respStr);
//
//        JSONObject respHeadObj = MBPUtils.getRespHeadObj(respStr);
//        JSONObject respDataObj = MBPUtils.getRespDataObj(respStr);
//
//        String respcode = respHeadObj.getString("respcode");
//        String msgCode = "";
//        if (MBPUtils.isSuccess(respHeadObj)) {
//            msgCode = "0";
//        } else {
//            msgCode = respcode;
//        }
//        String respmsg = respHeadObj.getString("respmsg");
//
//        respHead.put("msgCode", msgCode);
//        respHead.put("msgMsg", respmsg);
//
//        respJson.put("head", respHead);
//        respJson.put("body", respDataObj);
//
//        return respJson;
//    }
//
//    /**
//     * @param reqMap @return（展示方法参数和返回值）
//     * @Description:获取验证码（方法功能描述）
//     */
//    @SuppressWarnings({"rawtypes", "unchecked"})
//    public JSONObject getMsgAuthCode(Map reqMap) {
//        JSONObject respJson = new JSONObject();
//        JSONObject respHead = new JSONObject();
//        JSONObject respBody = new JSONObject();
//
////		Map head = (Map) reqMap.get("head");
//        Map body = (Map) reqMap.get("body");
//
//        if (StringUtils.isEmpty(body.get("telno")) || StringUtils.isEmpty(body.get("sendtype"))) {
//            throw new RuntimeException("telno、sendtype不能为空");
//        }
//        String sendtype = String.valueOf(body.get("sendtype"));
//
//        String sendmsg = "";
//        String code = env.equals("test") ? "888888" : SmsUtils.getRandomNumCode(6);
//        //如有其它类型短信可增加短信类型进行短信发送
//        switch (sendtype) {
//            case "1":// 短信验证码接口
//                sendmsg += "您的国社服务经理注册验证码:" + code + "，";
//                break;
//            case "2"://注册个人、企业会员短信验证码接口
//                sendmsg += "您的国社会员注册验证码:" + code + "，";
//                break;
//            case "3"://PC商户端验证码获取
//                sendmsg += "您正在登录国社商户端，验证码为：" + code + "，";
//                break;
//            case "4":
//                sendmsg += "您正在修改国社支付密码，验证码为：" + code + "，";
//                break;
//            case "5":
//                sendmsg += "您正在注销团餐信用账户，验证码为：" + code + "，";
//                break;
//            case "6":
//                sendmsg += "您正在变更团餐信用账户联系人，验证码为：" + code + "，";
//                break;
//            default:
//                log.info("无效业务类型");
//                throw new RuntimeException("无效sendtype");
//        }
//
//        if (!StringUtils.isEmpty(sendmsg)) {
//            sendmsg += "为了你的帐号安全，请勿将此验证码透露给他人。";
//            body.put("transCode", "USR00009");
//            body.put("sendmsg", sendmsg);
//            respJson = commonSendMbp(reqMap);
//            String respcode = null == respJson ? "" : respJson.getJSONObject("head").getString("msgCode");
//            if (null != respcode && "0".equals(respcode)) {
//                String smsid = IdGenerator.getIdLongStr();
//                //存库
//                body.put("smscode", code);
//                body.put("smsid", smsid);
//                msgAuthCodeService.saveMsgAuthCodeInfo(body);
//                //缓存到redis
//                redisUtil.set(smsid + code, code, 300);
//                respHead.put("msgCode", "0");
//                respHead.put("msgMsg", "获取成功");
//                respBody.put("smsid", smsid);
//            } else {
//                respHead.put("msgCode", "1001");
//                respHead.put("msgMsg", "获取失败");
//            }
//
//        }
//        respJson.put("head", respHead);
//        respJson.put("body", respBody);
//        return respJson;
//    }
//
//
//    public Result<Boolean> verifySMSCaptcha(Map reqMap) {
//        Map body = (Map) reqMap.get("body");
//
//        String code = body.get("msgCode").toString();
//        String id = body.get("smsid").toString();
//
//        boolean hasKeyFlag = redisUtil.hasKey(id + code);
//        if (!hasKeyFlag) return new Result<>(HttpStatus.INTERNAL_SERVER_ERROR.value(),"验证码过期");
//
//        String smsCode = (String) redisUtil.get(id + code);
//        if (!code.equals(smsCode)) return new Result<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "验证码不正确");
//
//        return new Result<>(HttpStatus.OK.value(), "ok");
//    }
//
//    /**
//     * @param reqMap @return（展示方法参数和返回值）
//     * @Description:获取图片信息（方法功能描述）
//     */
//    public JSONObject queryPhotoInfo(Map reqMap) throws Exception {
//        JSONObject respJson = new JSONObject();
//        JSONObject respHead = new JSONObject();
//        JSONObject respBody = new JSONObject();
//
//        Map head = (Map) reqMap.get("head");
//        Map body = (Map) reqMap.get("body");
//        String str = "";
//
//        String type = (String) body.get("type");  //1-正面 2-反面
//        if (StringUtils.isEmpty(body.get("type"))) {
//            respHead.put("msgCode", "1001");
//            respHead.put("msgMsg", "type不能为空！");
//            respJson.put("head", respHead);
//            return respJson;
//        }
//        switch (type) {
//            case "1":
//                if (StringUtils.isEmpty(body.get("frontUrl"))) {
//                    respHead.put("msgCode", "1001");
//                    respHead.put("msgMsg", "身份证正面不能为空！");
//                    respJson.put("head", respHead);
//                    return respJson;
//                }
//                break;
//            case "2":
//                if (StringUtils.isEmpty(body.get("frontUrl"))) {
//                    respHead.put("msgCode", "1001");
//                    respHead.put("msgMsg", "身份证反面不能为空！");
//                    respJson.put("head", respHead);
//                    return respJson;
//                }
//                break;
//            default:
//                respHead.put("msgCode", "1001");
//                respHead.put("msgMsg", "无效type");
//                respJson.put("head", respHead);
//                return respJson;
//        }
//
//        String frontUrlMessage = baiduSanWangUtil.baiduProductIdentityCard((String) body.get("frontUrl"));
//        if (StringUtils.isNotEmpty(frontUrlMessage) && frontUrlMessage.length() >= 2) {
//            JSONObject jsStr = JSONObject.parseObject(frontUrlMessage); //将字符串 转json
//            String errcode = (String) jsStr.get("errcode");
//            if ("R0000".equals(errcode)) {
//                JSONObject encresult = JSONObject.parseObject(jsStr.get("encresult").toString()); //将字符串 转json
//                if ((type.equals("1") && StringUtils.isEmpty(encresult.get("issueAauthority")))
//                        || (type.equals("2") && !StringUtils.isEmpty(encresult.get("issueAauthority")))) {
//                    respHead.put("msgCode", "0");
//                    respHead.put("msgMsg", "查询身份信息成功！");
//                    respBody.put("encresult", jsStr.get("encresult"));
//                } else {
//                    respHead.put("msgCode", "1001");
//                    if (type.equals("1")) {
//                        respHead.put("msgMsg", "请上传身份证正面");
//                    } else {
//                        respHead.put("msgMsg", "请上传身份证反面");
//                    }
//                    respJson.put("head", respHead);
//                    return respJson;
//                }
//            } else {
//                log.error("查询身份信息失败" + jsStr.get("errmsg"));
//                respHead.put("msgCode", "1001");
//                respHead.put("msgMsg", "请上传正确的身份证信息！");
//                respJson.put("head", respHead);
//                return respJson;
//            }
//
//        } else {
//            log.error("查询身份信息失败！");
//            respHead.put("msgCode", "1001");
//            respHead.put("msgMsg", "查询失败！");
//            respJson.put("head", respHead);
//            return respJson;
//        }
//        respJson.put("head", respHead);
//        respJson.put("body", respBody);
//        return respJson;
//    }
//
//    /**
//     * 查询开币余额
//     *
//     * @param crmaccount
//     * @return
//     * @throws BusinessException
//     */
//    public BigDecimal kaibiBalanceQuery(String crmaccount) throws BusinessException {
//        Map<String, Object> paraReq = new HashMap<String, Object>();
//        Map<String, Object> paraHead = new HashMap<String, Object>();
//        paraHead.put("platForm", "001");
//        paraReq.put("head", paraHead);
//        Map<String, Object> paraBody = new HashMap<String, Object>();
//        paraBody.put("transCode", "INT30001");
//        paraBody.put("account", crmaccount);
//        paraBody.put("busino", "BUS888888");
//        paraBody.put("sumcode", "INT001");
//        paraBody.put("acctype", "02");  //查询开币
//        paraReq.put("body", paraBody);
//        JSONObject mbpResp = commonSendMbp(paraReq);
//        JSONObject mbpRespHead = mbpResp.getJSONObject("head");
//        String mbpRespCode = mbpRespHead.getString("msgCode");
//        String mbpRespMsg = mbpRespHead.getString("msgMsg");
//        if (!"00000".equals(mbpRespCode) && !"0".equals(mbpRespCode)) {
//            log.info("查询开币会员系统返回：" + mbpRespMsg);
//            throw new BusinessException(mbpRespMsg);
//        } else {
//            JSONObject mbpRespBody = mbpResp.getJSONObject("body");
//            BigDecimal balance = new BigDecimal(String.valueOf(mbpRespBody.get("balance")));
//            return balance;
//        }
//    }
//
//    /**
//     * 开币支付
//     *
//     * @param crmaccount
//     * @param amt
//     * @param orderNo
//     * @return
//     * @throws BusinessException
//     */
//    public String kaibiPay(String crmaccount, BigDecimal amt, String orderNo)
//            throws BusinessException {
//        Map<String, Object> paraReq = new HashMap<String, Object>();
//        Map<String, Object> paraHead = new HashMap<String, Object>();
//        paraHead.put("platForm", "001");
//        paraReq.put("head", paraHead);
//        Map<String, Object> paraBody = new HashMap<String, Object>();
//        paraBody.put("transCode", "INT01022");
//        paraBody.put("currency", "156");
//        paraBody.put("channel", "001");
//        paraBody.put("orderno", orderNo);
//        paraBody.put("acctype", "02");
//        paraBody.put("sumcode", "INT001");
//        paraBody.put("busino", "BUS888888");
//        paraBody.put("amount", amt);
//        paraBody.put("account", crmaccount);
//        paraReq.put("body", paraBody);
//        JSONObject mbpResp = commonSendMbp(paraReq);
//        JSONObject mbpRespHead = mbpResp.getJSONObject("head");
//        String mbpRespCode = mbpRespHead.getString("msgCode");
//        String mbpRespMsg = mbpRespHead.getString("msgMsg");
//        if (!"00000".equals(mbpRespCode) && !"0".equals(mbpRespCode)) {
//            log.info("开币支付会员系统返回：" + mbpRespMsg);
//            throw new BusinessException(mbpRespMsg);
//        } else {
//            JSONObject mbpRespBody = mbpResp.getJSONObject("body");
//            String orderno = (String) mbpRespBody.get("orderno");
//            return orderno;
//        }
//    }
//
//    /**
//     * 开币支付退款
//     *
//     * @param crmaccount
//     * @param amt
//     * @param knsorderno    开币支付时,返回的流水号
//     * @param returnOrderNo
//     * @return
//     * @throws BusinessException
//     */
//    public String kaibiPayRefund(String crmaccount, BigDecimal amt, String knsorderno, String returnOrderNo)
//            throws BusinessException {
//        Map<String, Object> paraReq = new HashMap<String, Object>();
//        Map<String, Object> paraHead = new HashMap<String, Object>();
//        paraHead.put("platForm", "001");
//        paraReq.put("head", paraHead);
//        Map<String, Object> paraBody = new HashMap<String, Object>();
//        paraBody.put("transCode", "INT07021");
//        paraBody.put("currency", "156");
//        paraBody.put("channel", "001");
//        paraBody.put("orderno", returnOrderNo);
//        paraBody.put("acctype", "02");
//        paraBody.put("sumcode", "INT001");
//        paraBody.put("busino", "BUS888888");
//        paraBody.put("knsorderno", knsorderno);
//        paraBody.put("amount", amt);
//        paraBody.put("account", crmaccount);
//        paraReq.put("body", paraBody);
//        JSONObject mbpResp = commonSendMbp(paraReq);
//        JSONObject mbpRespHead = mbpResp.getJSONObject("head");
//        String mbpRespCode = mbpRespHead.getString("msgCode");
//        String mbpRespMsg = mbpRespHead.getString("msgMsg");
//        if (!"00000".equals(mbpRespCode) && !"0".equals(mbpRespCode)) {
//            log.info("开币退款会员系统返回：" + mbpRespMsg);
//            throw new BusinessException(mbpRespMsg);
//        } else {
//            JSONObject mbpRespBody = mbpResp.getJSONObject("body");
//            String orderno = (String) mbpRespBody.get("orderno");
//            return orderno;
//        }
//    }
//
//    /**
//     * 开币提现
//     *
//     * @param crmaccount
//     * @param amt
//     * @param orderNo
//     * @return
//     * @throws BusinessException
//     */
//    public String kaibiDeduction(String crmaccount, BigDecimal amt, String orderNo)
//            throws BusinessException {
//        Map<String, Object> paraReq = new HashMap<String, Object>();
//        Map<String, Object> paraHead = new HashMap<String, Object>();
//        paraHead.put("platForm", "001");
//        paraReq.put("head", paraHead);
//        Map<String, Object> paraBody = new HashMap<String, Object>();
//        paraBody.put("transCode", "INT01026");
//        paraBody.put("currency", "156");
//        paraBody.put("channel", "001");
//        paraBody.put("orderno", orderNo);
//        paraBody.put("acctype", "02");
//        paraBody.put("sumcode", "INT001");
//        paraBody.put("busino", "BUS888888");
//        paraBody.put("amount", amt);
//        paraBody.put("account", crmaccount);
//        paraReq.put("body", paraBody);
//        JSONObject mbpResp = commonSendMbp(paraReq);
//        JSONObject mbpRespHead = mbpResp.getJSONObject("head");
//        String mbpRespCode = mbpRespHead.getString("msgCode");
//        String mbpRespMsg = mbpRespHead.getString("msgMsg");
//        if (!"00000".equals(mbpRespCode) && !"0".equals(mbpRespCode)) {
//            log.info("提现开币会员系统返回：" + mbpRespMsg);
//            throw new BusinessException(mbpRespMsg);
//        } else {
//            JSONObject mbpRespBody = mbpResp.getJSONObject("body");
//            String orderno = (String) mbpRespBody.get("orderno");
//            return orderno;
//        }
//    }
//
//    /**
//     * 开币提现退款
//     *
//     * @param crmaccount
//     * @param amt
//     * @param knsorderno
//     * @param returnOrderNo
//     * @return
//     * @throws BusinessException
//     */
//    public String kaibiRefund(String crmaccount, BigDecimal amt, String knsorderno, String returnOrderNo)
//            throws BusinessException {
//        Map<String, Object> paraReq = new HashMap<String, Object>();
//        Map<String, Object> paraHead = new HashMap<String, Object>();
//        paraHead.put("platForm", "001");
//        paraReq.put("head", paraHead);
//        Map<String, Object> paraBody = new HashMap<String, Object>();
//        paraBody.put("transCode", "INT07026");
//        paraBody.put("currency", "156");
//        paraBody.put("channel", "001");
//        paraBody.put("orderno", returnOrderNo);
//        paraBody.put("acctype", "02");
//        paraBody.put("sumcode", "INT001");
//        paraBody.put("busino", "BUS888888");
//        paraBody.put("knsorderno", knsorderno);
//        paraBody.put("amount", amt);
//        paraBody.put("account", crmaccount);
//        paraReq.put("body", paraBody);
//        JSONObject mbpResp = commonSendMbp(paraReq);
//        JSONObject mbpRespHead = mbpResp.getJSONObject("head");
//        String mbpRespCode = mbpRespHead.getString("msgCode");
//        String mbpRespMsg = mbpRespHead.getString("msgMsg");
//        if (!"00000".equals(mbpRespCode) && !"0".equals(mbpRespCode)) {
//            log.info("提现开币退款会员系统返回：" + mbpRespMsg);
//            throw new BusinessException(mbpRespMsg);
////
////            paraBody.put("transCode", "INT01021");
////			paraBody.remove("knsorderno");
////			paraReq.put("body", paraBody);
////			mbpResp = commonSendMbp(paraReq);
////			mbpRespHead = mbpResp.getJSONObject("head");
////	        mbpRespCode = mbpRespHead.getString("msgCode");
////	        mbpRespMsg = mbpRespHead.getString("msgMsg");
////	        if (!"00000".equals(mbpRespCode) && !"0".equals(mbpRespCode)) {
////	            log.info("提现开币充值退款会员系统返回：" + mbpRespMsg);
////	            throw new BusinessException(mbpRespMsg);
////	        }else {
////	        	JSONObject mbpRespBody = mbpResp.getJSONObject("body");
////	        	String orderno = (String) mbpRespBody.get("orderno");
////	        	return orderno;
////	        }
//        } else {
//            JSONObject mbpRespBody = mbpResp.getJSONObject("body");
//            String orderno = (String) mbpRespBody.get("orderno");
//            return orderno;
//        }
//    }
//
//    /**
//     * 查询店铺金余额
//     *
//     * @param crmaccount
//     * @return
//     * @throws BusinessException
//     */
//    public BigDecimal DPJBalanceQuery(String crmaccount, String busino) throws BusinessException {
//        Map<String, Object> paraReq = new HashMap<String, Object>();
//        Map<String, Object> paraHead = new HashMap<String, Object>();
//        paraHead.put("platForm", "001");
//        paraReq.put("head", paraHead);
//        Map<String, Object> paraBody = new HashMap<String, Object>();
//        paraBody.put("transCode", "INT30001");
//        paraBody.put("account", crmaccount);
//        paraBody.put("busino", busino);
//        paraBody.put("sumcode", "INT001");
//        paraBody.put("acctype", "05");  //查询店铺金
//        paraReq.put("body", paraBody);
//        JSONObject mbpResp = commonSendMbp(paraReq);
//        JSONObject mbpRespHead = mbpResp.getJSONObject("head");
//        String mbpRespCode = mbpRespHead.getString("msgCode");
//        String mbpRespMsg = mbpRespHead.getString("msgMsg");
//        if (!"00000".equals(mbpRespCode) && !"0".equals(mbpRespCode)) {
//            log.info("查询店铺金会员系统返回：" + mbpRespMsg);
//            throw new BusinessException(mbpRespMsg);
//        } else {
//            JSONObject mbpRespBody = mbpResp.getJSONObject("body");
//            BigDecimal balance = new BigDecimal(String.valueOf(mbpRespBody.get("balance")));
//            return balance;
//        }
//    }
//
//    /**
//     * 店铺金提现
//     *
//     * @param crmaccount
//     * @param busino
//     * @param amt
//     * @param orderNo
//     * @return
//     * @throws BusinessException
//     */
//    public String DPJDeduction(String crmaccount, String busino, BigDecimal amt, String orderNo)
//            throws BusinessException {
//        Map<String, Object> paraReq = new HashMap<String, Object>();
//        Map<String, Object> paraHead = new HashMap<String, Object>();
//        paraHead.put("platForm", "001");
//        paraReq.put("head", paraHead);
//        Map<String, Object> paraBody = new HashMap<String, Object>();
//        paraBody.put("transCode", "INT01024");
//        paraBody.put("currency", "156");
//        paraBody.put("channel", "001");
//        paraBody.put("orderno", orderNo);
//        paraBody.put("acctype", "05");
//        paraBody.put("sumcode", "INT001");
//        paraBody.put("busino", busino);
//        paraBody.put("amount", amt);
//        paraBody.put("account", crmaccount);
//        paraReq.put("body", paraBody);
//        JSONObject mbpResp = commonSendMbp(paraReq);
//        JSONObject mbpRespHead = mbpResp.getJSONObject("head");
//        String mbpRespCode = mbpRespHead.getString("msgCode");
//        String mbpRespMsg = mbpRespHead.getString("msgMsg");
//        if (!"00000".equals(mbpRespCode) && !"0".equals(mbpRespCode)) {
//            log.info("店铺金开币会员系统返回：" + mbpRespMsg);
//            throw new BusinessException(mbpRespMsg);
//        } else {
//            JSONObject mbpRespBody = mbpResp.getJSONObject("body");
//            String orderno = (String) mbpRespBody.get("orderno");
//            return orderno;
//        }
//    }
//
//    /**
//     * 店铺金提现退款
//     *
//     * @param crmaccount
//     * @param busino
//     * @param amt
//     * @param knsorderno
//     * @param returnOrderNo
//     * @return
//     * @throws BusinessException
//     */
//    public String DPJRefund(String crmaccount, String busino, BigDecimal amt, String knsorderno, String returnOrderNo)
//            throws BusinessException {
//        Map<String, Object> paraReq = new HashMap<String, Object>();
//        Map<String, Object> paraHead = new HashMap<String, Object>();
//        paraHead.put("platForm", "001");
//        paraReq.put("head", paraHead);
//        Map<String, Object> paraBody = new HashMap<String, Object>();
//        paraBody.put("transCode", "INT07022");
//        paraBody.put("currency", "156");
//        paraBody.put("channel", "001");
//        paraBody.put("orderno", returnOrderNo);
//        paraBody.put("acctype", "05");
//        paraBody.put("sumcode", "INT001");
//        paraBody.put("busino", busino);
//        paraBody.put("knsorderno", knsorderno);
//        paraBody.put("amount", amt);
//        paraBody.put("account", crmaccount);
//        paraReq.put("body", paraBody);
//        JSONObject mbpResp = commonSendMbp(paraReq);
//        JSONObject mbpRespHead = mbpResp.getJSONObject("head");
//        String mbpRespCode = mbpRespHead.getString("msgCode");
//        String mbpRespMsg = mbpRespHead.getString("msgMsg");
//        if (!"00000".equals(mbpRespCode) && !"0".equals(mbpRespCode)) {
//            log.info("提现店铺金退款会员系统返回：" + mbpRespMsg);
//            throw new BusinessException(mbpRespMsg);
//        } else {
//            JSONObject mbpRespBody = mbpResp.getJSONObject("body");
//            String orderno = (String) mbpRespBody.get("orderno");
//            return orderno;
//        }
//    }
//
//    /**
//     * 店铺金人脸支付线下消费
//     *
//     * @param crmaccount
//     * @param busino
//     * @param amt
//     * @param orderNo
//     * @return
//     * @throws BusinessException
//     */
//    public JSONObject DPJFacePay(String crmaccount, String busino, BigDecimal amt, String orderNo)
//            throws BusinessException {
//        Map<String, Object> paraReq = new HashMap<String, Object>();
//        Map<String, Object> paraHead = new HashMap<String, Object>();
//        paraHead.put("platForm", "001");
//        paraReq.put("head", paraHead);
//        Map<String, Object> paraBody = new HashMap<String, Object>();
//        paraBody.put("transCode", "INT01025");
//        paraBody.put("currency", "156");
//        paraBody.put("channel", "001");
//        paraBody.put("orderno", orderNo);
//        paraBody.put("acctype", "05");
//        paraBody.put("sumcode", "INT011");//INT011判断出为人脸支付
//        paraBody.put("busino", busino);
//        paraBody.put("amount", amt);
//        paraBody.put("account", crmaccount);
//        paraReq.put("body", paraBody);
//        JSONObject mbpResp = commonSendMbp(paraReq);
//        JSONObject mbpRespHead = mbpResp.getJSONObject("head");
//        String mbpRespCode = mbpRespHead.getString("msgCode");
//        String mbpRespMsg = mbpRespHead.getString("msgMsg");
//        if (!"00000".equals(mbpRespCode) && !"0".equals(mbpRespCode)) {
//            log.info("店铺金开币会员系统返回：" + mbpRespMsg);
//            throw new BusinessException(mbpRespMsg);
//        } else {
//            JSONObject mbpRespBody = mbpResp.getJSONObject("body");
////        	String orderno = (String) mbpRespBody.get("orderno");
//            return mbpRespBody;
//        }
//    }
//}
