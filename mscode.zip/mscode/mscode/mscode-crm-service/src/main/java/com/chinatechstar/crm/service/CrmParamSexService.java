package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmParamSex;
import com.chinatechstar.crm.vo.CrmParamSexVO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import java.util.List;
import java.util.Map;

/**
 * 性别参数表(CrmParamSex)表服务接口
 *
 * @author zhengxl
 * @since 2024-12-17 11:09:30
 */
public interface CrmParamSexService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmParamSex queryById(Long id);

    /**
     * 分页查询
     *
     * @param vo 筛选条件
     * @return 查询结果
     */
    Map<String, Object> queryByPage(CrmParamSexVO vo);

    /**
     * 新增数据
     *
     * @param crmParamSex 实例对象
     * @return 实例对象
     */
    CrmParamSex insert(CrmParamSex crmParamSex);

    /**
     * 修改数据
     *
     * @param crmParamSex 实例对象
     * @return 实例对象
     */
    CrmParamSex update(CrmParamSex crmParamSex);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Long id);

}
