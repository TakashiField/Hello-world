package com.chinatechstar.crm.wx.vo;

import com.chinatechstar.crm.entity.CrmUser;
import com.chinatechstar.crm.entity.CrmUserVip;
import lombok.Data;

import java.util.List;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.wx.vo
 * @Author: zhengxiaolei
 * @CreateTime: 2024-12-05 16-54
 * @Description: TODO
 * @Version: 1.0
 */
@Data
public class WxCenterVO {

    private CrmUser crmUser;

    private List<CrmUserVip> crmUserVipList;


}
