//package com.chinatechstar.crm.controller;
//
//
//
//import com.chinatechstar.crm.entity.CrmRulesEquity;
//import com.chinatechstar.crm.service.CrmRulesEquityService;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//
///**
// * 会员权益规则表(CrmRulesEquity)表控制层
// *
// * @author zhengxl
// * @since 2024-07-03 12:42:04
// */
//@RestController
//@RequestMapping("crmRulesEquity")
//public class CrmRulesEquityController {
//    /**
//     * 服务对象
//     */
//    @Autowired
//    private CrmRulesEquityService crmRulesEquityService;
//
//    /**
//     * 分页查询
//     *
//     * @param crmRulesEquity 筛选条件
//     * @return 查询结果
//     */
//    @GetMapping("/queryByPage")
//    public ResponseEntity<List<CrmRulesEquity>> queryByPage(@RequestBody CrmRulesEquity crmRulesEquity) {
//        return ResponseEntity.ok(this.crmRulesEquityService.queryByPage(crmRulesEquity));
//    }
//
//    /**
//     * 通过主键查询单条数据
//     *
//     * @param id 主键
//     * @return 单条数据
//     */
//    @GetMapping("/queryById")
//    public ResponseEntity<CrmRulesEquity> queryById(Long id) {
//        return ResponseEntity.ok(this.crmRulesEquityService.queryById(id));
//    }
//
//    /**
//     * 新增数据
//     *
//     * @param crmRulesEquity 实体
//     * @return 新增结果
//     */
//    @PostMapping("/add")
//    public ResponseEntity<CrmRulesEquity> add(@RequestBody CrmRulesEquity crmRulesEquity) {
//        return ResponseEntity.ok(this.crmRulesEquityService.insert(crmRulesEquity));
//    }
//
//    /**
//     * 编辑数据
//     *
//     * @param crmRulesEquity 实体
//     * @return 编辑结果
//     */
//    @PostMapping("/update")
//    public ResponseEntity<CrmRulesEquity> edit(@RequestBody CrmRulesEquity crmRulesEquity) {
//        return ResponseEntity.ok(this.crmRulesEquityService.update(crmRulesEquity));
//    }
//
//    /**
//     * 删除数据
//     *
//     * @param id 主键
//     * @return 删除是否成功
//     */
//    @PostMapping("/delete")
//    public ResponseEntity<Boolean> deleteById(Long id) {
//        return ResponseEntity.ok(this.crmRulesEquityService.deleteById(id));
//    }
//
//}
//
