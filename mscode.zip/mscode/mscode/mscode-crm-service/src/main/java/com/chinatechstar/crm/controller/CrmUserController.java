package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmUser;
import com.chinatechstar.crm.service.CrmUserService;
import com.chinatechstar.crm.vo.CrmUserVO;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员基础信息表(CrmUser)表控制层
 *
 * @author zhengxl
 * @since 2024-06-28 11:31:37
 */
@RestController
@RequestMapping("crmUser")
public class CrmUserController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmUserService crmUserService;

    /**
     * 分页查询
     *
     * @param vo 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage( @Validated CrmUserVO vo) {

        Map<String,Object> data = this.crmUserService.queryByPage(vo);
        return ResultBuilder.buildListSuccess(data);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {
        CrmUser crmUser = this.crmUserService.queryById(id);
        return ResultBuilder.buildListSuccess(crmUser);
    }

    /**
     * 新增数据
     *
     * @param crmUser 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody @Validated CrmUser crmUser) {
        this.crmUserService.insert(crmUser);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmUser 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody @Validated CrmUser crmUser) {
        this.crmUserService.update(crmUser);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Long id) {
        this.crmUserService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

    @GetMapping("/checkExists")
    public ListResult<Object> checkExists(@RequestBody CrmUser crmUser){
        Boolean exist = this.crmUserService.checkExists(crmUser);
        return ResultBuilder.buildListSuccess(exist);
    }

    @PostMapping("/sync")
    public ListResult<Object> sync(@RequestBody @Validated CrmUserVO crmUser) {
        this.crmUserService.sync(crmUser);
        return ResultBuilder.buildListSuccess(crmUser);
    }
}

