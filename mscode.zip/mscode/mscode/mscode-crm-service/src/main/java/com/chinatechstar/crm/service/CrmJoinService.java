package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmJoin;

import java.util.List;

/**
 * 招商加盟表(CrmJoin)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-08 15:35:19
 */
public interface CrmJoinService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmJoin queryById(Long id);

    /**
     * 分页查询
     *
     * @param crmJoin 筛选条件
     * @return 查询结果
     */
    List<CrmJoin> queryByPage(CrmJoin crmJoin);

    /**
     * 新增数据
     *
     * @param crmJoin 实例对象
     * @return 实例对象
     */
    CrmJoin insert(CrmJoin crmJoin);

    /**
     * 修改数据
     *
     * @param crmJoin 实例对象
     * @return 实例对象
     */
    CrmJoin update(CrmJoin crmJoin);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Long id);

}
