package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmRelationName;
import com.chinatechstar.crm.service.CrmRelationNameService;
import com.chinatechstar.crm.vo.CrmRelationNameVO;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * 会员关系名称表(CrmRelationName)表控制层
 *
 * @author makejava
 * @since 2024-06-26 09:59:18
 */
@RestController
@RequestMapping("crmRelationName")
public class CrmRelationNameController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmRelationNameService crmRelationNameService;

    /*
     * 分页查询
     *
     * @param vo 筛选条件
     * @param       分页对象
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage( @Validated CrmRelationNameVO vo) {
        List<CrmRelationName> result = this.crmRelationNameService.queryByPage(vo);
        vo.setCrmList(result);
        return ResultBuilder.buildListSuccess(vo);
    }


    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {
        CrmRelationName result = this.crmRelationNameService.queryById(id);
        return ResultBuilder.buildListSuccess(result);
    }

    /**
     * 新增数据
     *
     * @param crmRelationName 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody @Validated CrmRelationName crmRelationName) {
        this.crmRelationNameService.insert(crmRelationName);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmRelationName 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody @Validated CrmRelationName crmRelationName) {
        this.crmRelationNameService.update(crmRelationName);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Long id) {
        this.crmRelationNameService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

}

