package com.chinatechstar.crm.service.impl;

import com.chinatechstar.crm.entity.CrmTaskNotice;
import com.chinatechstar.crm.dao.CrmTaskNoticeDao;
import com.chinatechstar.crm.service.CrmTaskNoticeService;
import com.chinatechstar.crm.vo.CrmTaskNoticeVO;
import com.github.pagehelper.PageHelper;
import org.springframework.stereotype.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 通知提醒表(CrmTaskNotice)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-15 10:54:04
 */
@Service("crmTaskNoticeService")
public class CrmTaskNoticeServiceImpl implements CrmTaskNoticeService {
    @Autowired
    private CrmTaskNoticeDao crmTaskNoticeDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmTaskNotice queryById(Long id) {
        return this.crmTaskNoticeDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param crmTaskNotice 筛选条件
     * @return 查询结果
     */
    @Override
    public List<CrmTaskNotice> queryByPage(CrmTaskNoticeVO crmTaskNotice) {
        //long total = this.crmTaskNoticeDao.count(crmTaskNotice);
        PageHelper.startPage(crmTaskNotice.getCurrentPage(),crmTaskNotice.getPageSize());
        return (this.crmTaskNoticeDao.queryAllByPage(crmTaskNotice));
    }


    /**
     * 新增数据
     *
     * @param crmTaskNotice 实例对象
     * @return 实例对象
     */
    @Override
    public CrmTaskNotice insert(CrmTaskNotice crmTaskNotice) {
        this.crmTaskNoticeDao.insert(crmTaskNotice);
        return crmTaskNotice;
    }

    /**
     * 修改数据
     *
     * @param crmTaskNotice 实例对象
     * @return 实例对象
     */
    @Override
    public CrmTaskNotice update(CrmTaskNotice crmTaskNotice) {
        this.crmTaskNoticeDao.update(crmTaskNotice);
        return this.queryById(crmTaskNotice.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return this.crmTaskNoticeDao.deleteById(id) > 0;
    }
}
