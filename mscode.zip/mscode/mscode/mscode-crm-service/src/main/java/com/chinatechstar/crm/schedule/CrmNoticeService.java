package com.chinatechstar.crm.schedule;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.schedule
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-24 16-37
 * @Description: TODO
 * @Version: 1.0
 */
@Service
@Slf4j
public class CrmNoticeService {

    public void sendSms(String mobile, String content){

    }
}
