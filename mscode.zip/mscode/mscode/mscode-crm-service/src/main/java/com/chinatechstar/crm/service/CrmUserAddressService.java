package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmUserAddress;

import java.util.List;

/**
 * 会员地址信息表(CrmUserAddress)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-05 10:01:59
 */
public interface CrmUserAddressService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmUserAddress queryById(Long id);

    /**
     * 分页查询
     *
     * @param crmUserAddress 筛选条件
     * @return 查询结果
     */
    List<CrmUserAddress> queryByPage(CrmUserAddress crmUserAddress);

    /**
     * 新增数据
     *
     * @param crmUserAddress 实例对象
     * @return 实例对象
     */
    CrmUserAddress insert(CrmUserAddress crmUserAddress);

    /**
     * 修改数据
     *
     * @param crmUserAddress 实例对象
     * @return 实例对象
     */
    CrmUserAddress update(CrmUserAddress crmUserAddress);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Long id);

}
