package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmCooperationManager;
import com.chinatechstar.crm.service.CrmCooperationManagerService;
import com.chinatechstar.crm.vo.CrmCooperationManagerVO;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 合作商管理表(CrmCooperationManager)表控制层
 *
 * @author zhengxl
 * @since 2024-07-01 10:20:45
 */
@RestController
@RequestMapping("crmCooperationManager")
public class CrmCooperationManagerController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmCooperationManagerService crmCooperationManagerService;

    /**
     * 分页查询
     *
     * @param vo 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage(@RequestBody @Validated CrmCooperationManagerVO vo) {
        List<CrmCooperationManager> crmCooperationManagers = this.crmCooperationManagerService.queryByPage(vo);
        vo.setCrmList(crmCooperationManagers);
        return ResultBuilder.buildListSuccess(vo);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {
        CrmCooperationManager crmCooperationManager = this.crmCooperationManagerService.queryById(id);
        return ResultBuilder.buildListSuccess(crmCooperationManager);
    }

    /**
     * 新增数据
     *
     * @param crmCooperationManager 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody @Validated CrmCooperationManager crmCooperationManager) {
        this.crmCooperationManagerService.insert(crmCooperationManager);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmCooperationManager 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody @Validated CrmCooperationManager crmCooperationManager) {
        this.crmCooperationManagerService.update(crmCooperationManager);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Long id) {
        this.crmCooperationManagerService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmCooperationManager 实体
     * @return 编辑结果
     */
    @PostMapping("/check")
    public ActionResult check(@RequestBody @Validated CrmCooperationManager crmCooperationManager) {
        this.crmCooperationManagerService.check(crmCooperationManager);
        return ResultBuilder.buildActionSuccess();
    }

}

