package com.chinatechstar.crm.dao;

import com.chinatechstar.crm.entity.CrmPropertyCustomedValue;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 自定义标签值表(CrmPropertyCustomedValue)表数据库访问层
 *
 * @author makejava
 * @since 2024-06-24 17:20:22
 */
public interface CrmPropertyCustomedValueDao {

    /**
     * 通过ID查询单条数据
     *
     * @param userId 主键
     * @return 实例对象
     */
    List<CrmPropertyCustomedValue> queryById(Long userId);


    /**
     * 统计总行数
     *
     * @param crmPropertyCustomedValue 查询条件
     * @return 总行数
     */
    long count(CrmPropertyCustomedValue crmPropertyCustomedValue);

    /**
     * 新增数据
     *
     * @param crmPropertyCustomedValue 实例对象
     * @return 影响行数
     */
    int insert(CrmPropertyCustomedValue crmPropertyCustomedValue);

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmPropertyCustomedValue> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<CrmPropertyCustomedValue> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmPropertyCustomedValue> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<CrmPropertyCustomedValue> entities);

    /**
     * 修改数据
     *
     * @param crmPropertyCustomedValue 实例对象
     * @return 影响行数
     */
    int update(CrmPropertyCustomedValue crmPropertyCustomedValue);

    /**
     * 通过主键删除数据
     *
     * @param userId 主键
     * @return 影响行数
     */
    int deleteById(String userId);

}

