package com.chinatechstar.crm.dao;

import com.chinatechstar.crm.entity.CrmRelationManager;
import com.chinatechstar.crm.vo.CrmRelationManagerVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 会员关系管理表(CrmRelationManager)表数据库访问层
 *
 * @author makejava
 * @since 2024-06-26 09:59:17
 */
public interface CrmRelationManagerDao {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmRelationManager queryById(Long id);

    /**
     * 查询指定行数据
     *
     * @param crmRelationManager 查询条件
     * @return 对象列表
     */
    List<CrmRelationManager> queryByPage(CrmRelationManagerVO crmRelationManager);

    /**
     * 统计总行数
     *
     * @param crmRelationManager 查询条件
     * @return 总行数
     */
    long count(CrmRelationManager crmRelationManager);

    /**
     * 新增数据
     *
     * @param crmRelationManager 实例对象
     * @return 影响行数
     */
    int insert(CrmRelationManager crmRelationManager);

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmRelationManager> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<CrmRelationManager> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmRelationManager> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<CrmRelationManager> entities);

    /**
     * 修改数据
     *
     * @param crmRelationManager 实例对象
     * @return 影响行数
     */
    int update(CrmRelationManager crmRelationManager);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 影响行数
     */
    int deleteById(Long id);

    List<CrmRelationManager> queryByMchtId(CrmRelationManagerVO vo);

    List<CrmRelationManager> queryRelationByUserId(CrmRelationManagerVO vo);

    List<CrmRelationManager> queryByUserIdRelationTypeRelationName(CrmRelationManagerVO vo);
}

