package com.chinatechstar.crm.service.impl;


import com.chinatechstar.component.commons.utils.UUIDUtil;
import com.chinatechstar.crm.dao.CrmRulesUpDao;
import com.chinatechstar.crm.entity.CrmRulesUp;
import com.chinatechstar.crm.service.CrmRulesUpService;
import com.chinatechstar.crm.vo.CrmRulesVO;
import org.springframework.stereotype.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员升级规则(CrmRulesUp)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-03 12:43:03
 */
@Service("crmRulesUpService")
public class CrmRulesUpServiceImpl implements CrmRulesUpService {
    @Autowired
    private CrmRulesUpDao crmRulesUpDao;

    /**
     * 通过ID查询单条数据
     *
     * @param ruleId 主键
     * @return 实例对象
     */
    @Override
    public CrmRulesUp queryById(Long ruleId) {
        return this.crmRulesUpDao.queryById(ruleId);
    }

    /**
     * 分页查询
     *
     * @param crmRulesUp 筛选条件
     * @return 查询结果
     */
    @Override
    public List<CrmRulesUp> queryByPage(CrmRulesVO crmRulesUp) {
        //long total = this.crmRulesUpDao.count(crmRulesUp);
        return (this.crmRulesUpDao.queryAllByPage(crmRulesUp));
    }


    /**
     * 新增数据
     *
     * @param crmRulesUp 实例对象
     * @return 实例对象
     */
    @Override
    public CrmRulesUp insert(CrmRulesUp crmRulesUp) {
        crmRulesUp.setRuleId(UUIDUtil.snowflakeId());
        String ruleDesc = crmRulesUp.getRuleName()+crmRulesUp.getRuleParam()+crmRulesUp.getRuleValue()+crmRulesUp.getRuleValueUnit();
        crmRulesUp.setRuleDesc(ruleDesc);
        this.crmRulesUpDao.insert(crmRulesUp);
        return crmRulesUp;
    }

    /**
     * 修改数据
     *
     * @param crmRulesUp 实例对象
     * @return 实例对象
     */
    @Override
    public CrmRulesUp update(CrmRulesUp crmRulesUp) {
        this.crmRulesUpDao.update(crmRulesUp);
        return this.queryById(crmRulesUp.getRuleId());
    }

    /**
     * 通过主键删除数据
     *
     * @param ruleId 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long ruleId) {
        return this.crmRulesUpDao.deleteById(ruleId) > 0;
    }

    /**
     * @param vo
     * @return
     */
    @Override
    public List<CrmRulesUp> queryByGradeId(CrmRulesVO vo) {
        return this.crmRulesUpDao.queryByGradeId(vo);
    }
}
