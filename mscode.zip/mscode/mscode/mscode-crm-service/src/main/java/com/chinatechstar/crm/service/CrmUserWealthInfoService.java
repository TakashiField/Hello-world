package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmUserWealthInfo;

import java.util.List;

/**
 * 会员资产信息表(CrmUserWealthInfo)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:02
 */
public interface CrmUserWealthInfoService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmUserWealthInfo queryById(Integer id);

    /**
     * 分页查询
     *
     * @param crmUserWealthInfo 筛选条件
     * @return 查询结果
     */
    List<CrmUserWealthInfo> queryByPage(CrmUserWealthInfo crmUserWealthInfo);

    /**
     * 新增数据
     *
     * @param crmUserWealthInfo 实例对象
     * @return 实例对象
     */
    CrmUserWealthInfo insert(CrmUserWealthInfo crmUserWealthInfo);

    /**
     * 修改数据
     *
     * @param crmUserWealthInfo 实例对象
     * @return 实例对象
     */
    CrmUserWealthInfo update(CrmUserWealthInfo crmUserWealthInfo);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Integer id);

}
