package com.chinatechstar.crm.dao;

import com.chinatechstar.crm.entity.CrmUserAddress;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 会员地址信息表(CrmUserAddress)表数据库访问层
 *
 * @author zhengxl
 * @since 2024-07-05 10:01:59
 */
public interface CrmUserAddressDao {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmUserAddress queryById(Long id);

    /**
     * 查询指定行数据
     *
     * @param crmUserAddress 查询条件
     * @return 对象列表
     */
    List<CrmUserAddress> queryAllByPage(CrmUserAddress crmUserAddress);

    /**
     * 统计总行数
     *
     * @param crmUserAddress 查询条件
     * @return 总行数
     */
    long count(CrmUserAddress crmUserAddress);

    /**
     * 新增数据
     *
     * @param crmUserAddress 实例对象
     * @return 影响行数
     */
    int insert(CrmUserAddress crmUserAddress);

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmUserAddress> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<CrmUserAddress> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmUserAddress> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<CrmUserAddress> entities);

    /**
     * 修改数据
     *
     * @param crmUserAddress 实例对象
     * @return 影响行数
     */
    int update(CrmUserAddress crmUserAddress);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 影响行数
     */
    int deleteById(Long id);

}

