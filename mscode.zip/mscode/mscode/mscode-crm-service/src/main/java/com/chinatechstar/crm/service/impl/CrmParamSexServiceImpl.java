package com.chinatechstar.crm.service.impl;

import com.chinatechstar.component.commons.result.PaginationBuilder;
import com.chinatechstar.crm.entity.CrmParamSex;
import com.chinatechstar.crm.dao.CrmParamSexDao;
import com.chinatechstar.crm.entity.CrmPropertyCustomed;
import com.chinatechstar.crm.service.CrmParamSexService;
import com.chinatechstar.crm.vo.CrmParamSexVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * 性别参数表(CrmParamSex)表服务实现类
 *
 * @author zhengxl
 * @since 2024-12-17 11:09:30
 */
@Service("crmParamSexService")
public class CrmParamSexServiceImpl implements CrmParamSexService {
    @Resource
    private CrmParamSexDao crmParamSexDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmParamSex queryById(Long id) {
        return this.crmParamSexDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param vo 筛选条件
     * @return 查询结果
     */
    @Override
    public Map<String, Object> queryByPage(CrmParamSexVO vo) {
        PageHelper.startPage(vo.getCurrentPage(),vo.getPageSize(),true);
        List<CrmParamSex> crmParamSexList = this.crmParamSexDao.queryByPage(vo);
        PageInfo<CrmParamSex> pageInfo = new PageInfo<>(crmParamSexList);
        return PaginationBuilder.buildResultObject(crmParamSexList, pageInfo.getTotal(), vo.getCurrentPage(), vo.getPageSize());
    }

    /**
     * 新增数据
     *
     * @param crmParamSex 实例对象
     * @return 实例对象
     */
    @Override
    public CrmParamSex insert(CrmParamSex crmParamSex) {
        this.crmParamSexDao.insert(crmParamSex);
        return crmParamSex;
    }

    /**
     * 修改数据
     *
     * @param crmParamSex 实例对象
     * @return 实例对象
     */
    @Override
    public CrmParamSex update(CrmParamSex crmParamSex) {
        this.crmParamSexDao.update(crmParamSex);
        return this.queryById(crmParamSex.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return this.crmParamSexDao.deleteById(id) > 0;
    }
}
