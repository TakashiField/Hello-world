package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmUserWealthInfoDetail;

import java.util.List;

/**
 * 会员资产明细表(CrmUserWealthInfoDetail)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:03
 */
public interface CrmUserWealthInfoDetailService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmUserWealthInfoDetail queryById(Integer id);

    /**
     * 分页查询
     *
     * @param crmUserWealthInfoDetail 筛选条件
     * @return 查询结果
     */
    List<CrmUserWealthInfoDetail> queryByPage(CrmUserWealthInfoDetail crmUserWealthInfoDetail);

    /**
     * 新增数据
     *
     * @param crmUserWealthInfoDetail 实例对象
     * @return 实例对象
     */
    CrmUserWealthInfoDetail insert(CrmUserWealthInfoDetail crmUserWealthInfoDetail);

    /**
     * 修改数据
     *
     * @param crmUserWealthInfoDetail 实例对象
     * @return 实例对象
     */
    CrmUserWealthInfoDetail update(CrmUserWealthInfoDetail crmUserWealthInfoDetail);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Integer id);

}
