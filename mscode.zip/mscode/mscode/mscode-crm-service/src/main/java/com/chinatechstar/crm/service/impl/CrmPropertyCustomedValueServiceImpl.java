package com.chinatechstar.crm.service.impl;

import com.chinatechstar.crm.entity.CrmPropertyCustomedValue;
import com.chinatechstar.crm.dao.CrmPropertyCustomedValueDao;
import com.chinatechstar.crm.service.CrmPropertyCustomedValueService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;


/**
 * 自定义标签值表(CrmPropertyCustomedValue)表服务实现类
 *
 * @author makejava
 * @since 2024-06-24 17:20:23
 */
@Service("crmPropertyCustomedValueService")
public class CrmPropertyCustomedValueServiceImpl implements CrmPropertyCustomedValueService {
    @Resource
    private CrmPropertyCustomedValueDao crmPropertyCustomedValueDao;

    /**
     * 通过ID查询单条数据
     *
     * @param userId 主键
     * @return 实例对象
     */
    @Override
    public List<CrmPropertyCustomedValue> queryById(Long userId) {
        return this.crmPropertyCustomedValueDao.queryById(userId);
    }

    /**
     * 分页查询
     *
     * @param crmPropertyCustomedValue 筛选条件
     * @param pageRequest              分页对象
     * @return 查询结果
     */


    /**
     * 新增数据
     *
     * @param crmPropertyCustomedValue 实例对象
     * @return 实例对象
     */
    @Override
    public CrmPropertyCustomedValue insert(CrmPropertyCustomedValue crmPropertyCustomedValue) {
        this.crmPropertyCustomedValueDao.insert(crmPropertyCustomedValue);
        return crmPropertyCustomedValue;
    }

    /**
     * 修改数据
     *
     * @param crmPropertyCustomedValue 实例对象
     * @return 实例对象
     */
    @Override
    public CrmPropertyCustomedValue update(CrmPropertyCustomedValue crmPropertyCustomedValue) {
        this.crmPropertyCustomedValueDao.update(crmPropertyCustomedValue);
        return crmPropertyCustomedValue;
    }

    /**
     * 通过主键删除数据
     *
     * @param userId 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(String userId) {
        return this.crmPropertyCustomedValueDao.deleteById(userId) > 0;
    }
}
