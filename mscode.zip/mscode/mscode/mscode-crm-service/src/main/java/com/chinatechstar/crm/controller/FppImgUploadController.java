package com.chinatechstar.crm.controller;

import com.alibaba.fastjson.JSON;
import com.chinatechstar.component.commons.config.JsonResult;
import com.chinatechstar.component.commons.utils.StringUtils;
import com.chinatechstar.component.commons.utils.UUIDUtil;

import com.chinatechstar.crm.config.QiNiuClient;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * @author lixu
 */
@RestController
@RequestMapping("/fppImgUpload")
public class FppImgUploadController {

    private final Logger logger = LoggerFactory.getLogger(getClass());
    @Qualifier("qiNiuClient")
    @Resource
    private QiNiuClient qiNiuClient;

    private String prefixName = "fppmall/merchant/";

    /**
     * 单图片上传，直接上传到图片服务器 add by lyt 20200610
     * @param file
     * @return
     * @throws IOException
     */
    @RequestMapping("/imgUploadService")
    public JsonResult<Map<String, Object>> storeImgUpload2(@RequestParam("file") MultipartFile file){
        JsonResult<Map<String, Object>> result = new JsonResult<Map<String, Object>>();
        String fileName = file.getOriginalFilename();// 获取原名称
        String fileNowName = UUIDUtil.getUUID2() + "." + FilenameUtils.getExtension(fileName);// 生成唯一的名字
        logger.info("接收到的图片："+fileName);
        InputStream is = null;
        String returnPath = null;
        try {
            is = file.getInputStream();//文件输入流
        } catch (IOException e) {
            // TODO Auto-generated catch block
            logger.error("获取图片文件流出错：" + JSON.toJSONString(e));
            result.setMsg("上传失败,请重新上传");
            result.setCode(500);
            return result;
        }

        Map<String,String> descriptions=new HashMap<String,String>();
        descriptions.put("msg", "活动图片");

        try {
            logger.info("上传图片到图片服务器，新图片名为："+fileNowName);
            returnPath = qiNiuClient.uploadImg(is,fileNowName,prefixName);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            logger.error("上传图片发生错误：" + JSON.toJSONString(e));
            logger.info("删除已上传图片列表："+ JSON.toJSONString(returnPath));
            try {
                qiNiuClient.deleteFile(returnPath);
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                logger.error("删除图片"+returnPath+"发生错误：" + JSON.toJSONString(e1));
            }
            result.setMsg("上传失败,请重新上传");
            result.setCode(500);
            return result;
        }
        if(!StringUtils.isEmpty(returnPath)){
            logger.info("上传文件成功,服务器路径为： " + returnPath);
            HashMap<String, Object> objectObjectHashMap = new HashMap<>();
            objectObjectHashMap.put("returnPath",returnPath);
            result.setMsg("上传文件成功");
            result.setData(objectObjectHashMap);
            result.setCode(200);
        }
        return result;
    }
}
