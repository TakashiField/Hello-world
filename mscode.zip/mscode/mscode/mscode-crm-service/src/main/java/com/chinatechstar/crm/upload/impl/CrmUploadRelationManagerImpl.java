package com.chinatechstar.crm.upload.impl;

import com.chinatechstar.component.commons.utils.ExcelUtils;
import com.chinatechstar.component.commons.utils.UUIDUtil;
import com.chinatechstar.crm.entity.CrmRelationManager;
import com.chinatechstar.crm.service.CrmRelationManagerService;
import com.chinatechstar.crm.upload.CrmUploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.upload.impl
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-01 09-38
 * @Description: TODO
 * @Version: 1.0
 */
@Service("relationManagerWork")
public class CrmUploadRelationManagerImpl implements CrmUploadService {

    @Autowired
    private CrmRelationManagerService service;
    /**
     * @param file
     */
    @Override
    public void upload(MultipartFile file) {

        if (file.getOriginalFilename().toLowerCase().indexOf(".xlsx") == -1) {
            throw new IllegalArgumentException("请上传xlsx格式的文件");
        }
        List<Map<Integer, String>> listMap = ExcelUtils.readExcel(file);
        for (Map<Integer, String> data : listMap) {
            CrmRelationManager crmRelationManager = new CrmRelationManager();
            crmRelationManager.setId(UUIDUtil.snowflakeId());
            if(data.get(0) == null){
                throw new RuntimeException("第一列不能为空");
            }else {
                crmRelationManager.setUserId(Long.getLong(data.get(0)));
            }
            crmRelationManager.setName(data.get(1) == null ? "" : data.get(1));
            crmRelationManager.setMobile(data.get(2) == null ? "" : data.get(2));
            if(data.get(3) == null){
                throw new RuntimeException("第三列不能为空");
            }else {
                crmRelationManager.setUserId(Long.getLong(data.get(3)));
            }
            crmRelationManager.setNameRelated(data.get(4) == null ? " " : data.get(4));
            crmRelationManager.setMobileRelated(data.get(5) == null ? " " : data.get(5));
            crmRelationManager.setSrcChannel(data.get(6) == null ? " " : data.get(6));
            crmRelationManager.setRelationName(data.get(7) == null ? " " : data.get(7));
            //crmRelationManager.setRelationProperty(data.get(8) == null ? " " : data.get(8));
            if(data.get(9) == null){
                throw new RuntimeException("第三列不能为空");
            }else {
                crmRelationManager.setUserId(Long.getLong(data.get(9)));
            }
            //crmRelationManager.setMchtId(data.get(9) == null ? " " : data.get(9));

            service.insert(crmRelationManager);

        }

    }
}
