package com.chinatechstar.crm.service.impl;

import com.chinatechstar.component.commons.result.PaginationBuilder;
import com.chinatechstar.component.commons.utils.SequenceGenerator;
import com.chinatechstar.crm.entity.CrmPropertyCustomed;
import com.chinatechstar.crm.dao.CrmPropertyCustomedDao;
import com.chinatechstar.crm.service.CrmPropertyCustomedService;
import com.chinatechstar.crm.util.DateUtils;
import com.chinatechstar.crm.vo.CrmPropertyCustomedVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;


/**
 * 自定义标签表(CrmPropertyCustomed)表服务实现类
 *
 * @author makejava
 * @since 2024-06-24 17:20:22
 */
@Service("crmPropertyCustomedService")
public class CrmPropertyCustomedServiceImpl implements CrmPropertyCustomedService {
    @Resource
    private CrmPropertyCustomedDao crmPropertyCustomedDao;

    private static final SequenceGenerator sequenceGenerator = new SequenceGenerator();

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmPropertyCustomed queryById(Long id) {
        return this.crmPropertyCustomedDao.queryById(id);
    }



    /**
     * 新增数据
     *
     * @param crmPropertyCustomed 实例对象
     * @return 实例对象
     */
    @Override
    public CrmPropertyCustomed insert(CrmPropertyCustomed crmPropertyCustomed) {
        CrmPropertyCustomed select = new CrmPropertyCustomed();
        select.setPropName(crmPropertyCustomed.getPropName());
        select.setMchtId(crmPropertyCustomed.getMchtId());
        long count = this.crmPropertyCustomedDao.count(select);
        if(count > 0){
            throw new RuntimeException("该属性已存在");
        } else {
            crmPropertyCustomed.setId(sequenceGenerator.nextId());
            crmPropertyCustomed.setCreateUser(crmPropertyCustomed.getOperatorName());
            crmPropertyCustomed.setCreateTime(DateUtils.timestamp());
            this.crmPropertyCustomedDao.insert(crmPropertyCustomed);
            return crmPropertyCustomed;
        }
    }

    /**
     * 修改数据
     *
     * @param crmPropertyCustomed 实例对象
     * @return 实例对象
     */
    @Override
    public CrmPropertyCustomed update(CrmPropertyCustomed crmPropertyCustomed) {
        crmPropertyCustomed.setUpdateUser(crmPropertyCustomed.getUpdateUser());
        crmPropertyCustomed.setUpdateTime(DateUtils.timestamp());
        this.crmPropertyCustomedDao.update(crmPropertyCustomed);
        return this.queryById(crmPropertyCustomed.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long[] id) {
        return this.crmPropertyCustomedDao.deleteById(id) > 0;
    }

    /**
     * 分页查询
     *
     * @param vo 筛选条件
     * @return 查询结果
     */
    @Override
    public Map<String, Object> queryByPage(CrmPropertyCustomedVO vo) {
        PageHelper.startPage(vo.getCurrentPage(),vo.getPageSize(),true);
        List<CrmPropertyCustomed> customedList = this.crmPropertyCustomedDao.queryByPage(vo);
        PageInfo<CrmPropertyCustomed> pageInfo = new PageInfo<>(customedList);
        return PaginationBuilder.buildResultObject(customedList, pageInfo.getTotal(), vo.getCurrentPage(), vo.getPageSize());

    }
}
