package com.chinatechstar.crm.service;
import com.chinatechstar.crm.entity.CrmRulesEquity;

import java.util.List;

/**
 * 会员权益规则表(CrmRulesEquity)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-03 12:42:05
 */
public interface CrmRulesEquityService {

    /**
     * 通过ID查询单条数据
     *
     * @param ruleId 主键
     * @return 实例对象
     */
    CrmRulesEquity queryById(Long ruleId);

    /**
     * 分页查询
     *
     * @param crmRulesEquity 筛选条件
     * @return 查询结果
     */
    List<CrmRulesEquity> queryByPage(CrmRulesEquity crmRulesEquity);

    /**
     * 新增数据
     *
     * @param crmRulesEquity 实例对象
     * @return 实例对象
     */
    CrmRulesEquity insert(CrmRulesEquity crmRulesEquity);

    /**
     * 修改数据
     *
     * @param crmRulesEquity 实例对象
     * @return 实例对象
     */
    CrmRulesEquity update(CrmRulesEquity crmRulesEquity);

    /**
     * 通过主键删除数据
     *
     * @param ruleId 主键
     * @return 是否成功
     */
    boolean deleteById(Long ruleId);

}
