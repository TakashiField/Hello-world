package com.chinatechstar.crm.service.impl;

import com.chinatechstar.component.commons.result.PaginationBuilder;
import com.chinatechstar.component.commons.utils.SequenceGenerator;
import com.chinatechstar.crm.entity.CrmUserInfoAddress;
import com.chinatechstar.crm.entity.CrmUserInfoContact;
import com.chinatechstar.crm.dao.CrmUserInfoContactDao;
import com.chinatechstar.crm.service.CrmUserInfoContactService;
import com.chinatechstar.crm.util.DateUtils;
import com.chinatechstar.crm.vo.CrmUserInfoContactVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员联系人信息表(CrmUserInfoContact)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:02
 */
@Service("crmUserInfoContactService")
public class CrmUserInfoContactServiceImpl implements CrmUserInfoContactService {

    private static final SequenceGenerator sequenceGenerator = new SequenceGenerator();
    @Autowired
    private CrmUserInfoContactDao crmUserInfoContactDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmUserInfoContact queryById(Long id) {
        return this.crmUserInfoContactDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param crmUserInfoContact 筛选条件
     * @return 查询结果
     */
    @Override
    public Map<String, Object> queryByPage(CrmUserInfoContactVO crmUserInfoContact) {
        PageHelper.startPage(crmUserInfoContact.getCurrentPage(),crmUserInfoContact.getPageSize(),true);
        List<CrmUserInfoContact> contactList = this.crmUserInfoContactDao.queryAllByPage(crmUserInfoContact);
        PageInfo<CrmUserInfoContact> pageInfo = new PageInfo<>(contactList);
        return PaginationBuilder.buildResultObject(contactList, pageInfo.getTotal(), crmUserInfoContact.getCurrentPage(), crmUserInfoContact.getPageSize());

    }


    /**
     * 新增数据
     *
     * @param crmUserInfoContact 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserInfoContact insert(CrmUserInfoContact crmUserInfoContact) {
        crmUserInfoContact.setId(sequenceGenerator.nextId());
        //crmUserInfoContact.setUserId(crmUserInfoContact.getUserId());
        crmUserInfoContact.setCreateUser(crmUserInfoContact.getOperatorName());
        crmUserInfoContact.setCreateTime(DateUtils.timestamp());
        this.crmUserInfoContactDao.insert(crmUserInfoContact);
        return crmUserInfoContact;
    }

    /**
     * 修改数据
     *
     * @param crmUserInfoContact 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserInfoContact update(CrmUserInfoContact crmUserInfoContact) {
        crmUserInfoContact.setUpdateTime(DateUtils.timestamp());
        crmUserInfoContact.setUpdateUser(crmUserInfoContact.getOperatorName());
        this.crmUserInfoContactDao.update(crmUserInfoContact);
        return this.queryById(crmUserInfoContact.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return this.crmUserInfoContactDao.deleteById(id) > 0;
    }
}
