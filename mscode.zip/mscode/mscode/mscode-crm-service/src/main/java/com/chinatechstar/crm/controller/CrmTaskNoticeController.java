package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmTaskNotice;
import com.chinatechstar.crm.service.CrmTaskNoticeService;
import com.chinatechstar.crm.vo.CrmTaskNoticeVO;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 通知提醒表(CrmTaskNotice)表控制层
 *
 * @author zhengxl
 * @since 2024-07-15 10:54:03
 */
@RestController
@RequestMapping("crmTaskNotice")
public class CrmTaskNoticeController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmTaskNoticeService crmTaskNoticeService;

    /**
     * 分页查询
     *
     * @param crmTaskNotice 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage(@RequestBody @Validated CrmTaskNoticeVO crmTaskNotice) {
        List<CrmTaskNotice> crmTaskNotices = this.crmTaskNoticeService.queryByPage(crmTaskNotice);
        crmTaskNotice.setCrmList(crmTaskNotices);
        return ResultBuilder.buildListSuccess(crmTaskNotice);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {
        CrmTaskNotice crmTaskNotice = this.crmTaskNoticeService.queryById(id);
        return ResultBuilder.buildListSuccess(crmTaskNotice);
    }

    /**
     * 新增数据
     *
     * @param crmTaskNotice 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody CrmTaskNotice crmTaskNotice) {
        this.crmTaskNoticeService.insert(crmTaskNotice);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmTaskNotice 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody CrmTaskNotice crmTaskNotice) {
        this.crmTaskNoticeService.update(crmTaskNotice);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Long id) {
        this.crmTaskNoticeService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

}

