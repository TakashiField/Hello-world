package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.upload.CrmUploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.controller
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-01 09-31
 * @Description: TODO
 * @Version: 1.0
 */
@RestController
public class CrmUploadController {

    @Autowired
    Map<String, CrmUploadService> serviceMap;
    @PostMapping(value = "/importSysUserPost", consumes = {"multipart/form-data"})
    public ActionResult importSysUserPost(@RequestParam(name = "file", required = true) MultipartFile file, @RequestParam(name = "type", required = true)String type) {

        CrmUploadService service = serviceMap.get(type);
        service.upload(file);
        return ResultBuilder.buildActionSuccess();
    }
}
