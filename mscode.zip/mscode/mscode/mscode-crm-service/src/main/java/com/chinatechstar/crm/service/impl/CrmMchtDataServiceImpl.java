package com.chinatechstar.crm.service.impl;

import com.chinatechstar.component.commons.result.PaginationBuilder;
import com.chinatechstar.component.commons.utils.UUIDUtil;
import com.chinatechstar.crm.entity.CrmMchtData;
import com.chinatechstar.crm.dao.CrmMchtDataDao;
import com.chinatechstar.crm.entity.CrmParam;
import com.chinatechstar.crm.service.CrmMchtDataService;
import com.chinatechstar.crm.util.DateUtils;
import com.chinatechstar.crm.vo.CrmMchtDataVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * 会员资料表(CrmMchtData)表服务实现类
 *
 * @author makejava
 * @since 2024-06-19 16:57:41
 */
@Service("crmMchtDataService")
public class CrmMchtDataServiceImpl implements CrmMchtDataService {

    @Autowired
    private CrmMchtDataDao crmMchtDataDao;

    /**
     * 通过ID查询单条数据
     *
     * @param dataId 主键
     * @return 实例对象
     */
    @Override
    public CrmMchtData queryById(Long dataId) {
        return this.crmMchtDataDao.queryById(dataId);
    }

    /**
     * 分页查询
     *
     * @param crmMchtData 筛选条件
     * @return 查询结果
     */

    @Override
    public List<CrmMchtData> queryByPage(CrmMchtDataVO crmMchtData) {
        PageHelper.startPage(crmMchtData.getCurrentPage(),crmMchtData.getPageSize());
        List<CrmMchtData> mchtData = this.crmMchtDataDao.queryByPage(crmMchtData);
        PageInfo<CrmMchtData> pageInfo = new PageInfo<>(mchtData);
        crmMchtData.setTotalSize( pageInfo.getTotal() );
        crmMchtData.setTotalPage( pageInfo.getPages() );
        return mchtData;

    }
    /**
     * 新增数据
     *
     * @param crmMchtData 实例对象
     * @return 实例对象
     */
    @Override
    public CrmMchtData insert(CrmMchtData crmMchtData) {
        crmMchtData.setDataId(UUIDUtil.snowflakeId());
        crmMchtData.setCreateTime(DateUtils.timestamp());
        this.crmMchtDataDao.insert(crmMchtData);
        return crmMchtData;
    }

    /**
     * 修改数据
     *
     * @param crmMchtData 实例对象
     * @return 实例对象
     */
    @Override
    public CrmMchtData update(CrmMchtData crmMchtData) {
        this.crmMchtDataDao.update(crmMchtData);
        return this.queryById(crmMchtData.getDataId());
    }

    /**
     * 通过主键删除数据
     *
     * @param dataId 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long dataId) {
        return this.crmMchtDataDao.deleteById(dataId) > 0;
    }

    /**
     * @param crmMchtDataVO
     * @return
     */
    @Override
    public List<CrmMchtData> queryAllByLimit(CrmMchtDataVO crmMchtDataVO) {
        PageHelper.startPage(crmMchtDataVO.getCurrentPage() * crmMchtDataVO.getPageSize(),crmMchtDataVO.getPageSize());
        List<CrmMchtData> result = crmMchtDataDao.queryAllByLimit(crmMchtDataVO);
        return result;
    }
}
