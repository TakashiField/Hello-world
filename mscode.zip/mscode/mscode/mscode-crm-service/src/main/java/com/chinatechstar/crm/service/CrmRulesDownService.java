package com.chinatechstar.crm.service;
import com.chinatechstar.crm.entity.CrmRulesDown;

import java.util.List;

/**
 * 会员升级规则(CrmRulesDown)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-03 12:43:15
 */
public interface CrmRulesDownService {

    /**
     * 通过ID查询单条数据
     *
     * @param ruleId 主键
     * @return 实例对象
     */
    CrmRulesDown queryById(Long ruleId);

    /**
     * 分页查询
     *
     * @param crmRulesDown 筛选条件
     * @return 查询结果
     */
    List<CrmRulesDown> queryByPage(CrmRulesDown crmRulesDown);

    /**
     * 新增数据
     *
     * @param crmRulesDown 实例对象
     * @return 实例对象
     */
    CrmRulesDown insert(CrmRulesDown crmRulesDown);

    /**
     * 修改数据
     *
     * @param crmRulesDown 实例对象
     * @return 实例对象
     */
    CrmRulesDown update(CrmRulesDown crmRulesDown);

    /**
     * 通过主键删除数据
     *
     * @param ruleId 主键
     * @return 是否成功
     */
    boolean deleteById(Long ruleId);

}
