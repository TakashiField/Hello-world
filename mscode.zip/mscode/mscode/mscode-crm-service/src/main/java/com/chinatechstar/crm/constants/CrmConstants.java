package com.chinatechstar.crm.constants;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.constants
 * @Author: zhengxiaolei
 * @CreateTime: 2024-06-11 10-57
 * @Description: TODO
 * @Version: 1.0
 */
public class CrmConstants {

    /**操作类型 0-新增 1-查询 2-修改 3-删除*/
    public static final String OPERATE_TYPE_ADD = "add";

    public static final String OPERATE_TYPE_QUEUY = "query";

    public static final String OPERATE_TYPE_UPDATE = "update";

    public static final String OPERATE_TYPE_DELETE = "delete";

    /** 状态 0-停用 1-启用 */
    public static final String STATUS_ON = "1";
    public static final String STATUS_OFF = "0";

    /** 申请状态 0-已申请 1-审核通过 2-审核不通过*/
    public static final String STATUS_APPLY = "0";
    public static final String STATUS_PASS = "1";
    public static final String STATUS_FAIL = "2";


}
