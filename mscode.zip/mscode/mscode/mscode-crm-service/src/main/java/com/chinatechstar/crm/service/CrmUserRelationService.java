package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmUserRelation;
import com.chinatechstar.crm.vo.CrmUserRelationVO;

import java.util.List;
import java.util.Map;

/**
 * 用户关系管理(CrmUserRelation)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-19 14:49:54
 */
public interface CrmUserRelationService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmUserRelation queryById(Long id);

    /**
     * 分页查询
     *
     * @param crmUserRelation 筛选条件
     * @return 查询结果
     */
    Map<String, Object> queryByPage(CrmUserRelationVO crmUserRelation);

    /**
     * 新增数据
     *
     * @param crmUserRelation 实例对象
     * @return 实例对象
     */
    CrmUserRelation insert(CrmUserRelation crmUserRelation);

    /**
     * 修改数据
     *
     * @param crmUserRelation 实例对象
     * @return 实例对象
     */
    CrmUserRelation update(CrmUserRelation crmUserRelation);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Long id);

}
