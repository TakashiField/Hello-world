package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmUserInfoGraduation;
import com.chinatechstar.crm.service.CrmUserInfoGraduationService;
import com.chinatechstar.crm.vo.CrmUserInfoGraduationVO;
import com.github.pagehelper.PageHelper;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员学习信息表(CrmUserInfoGraduation)表控制层
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:02
 */
@RestController
@RequestMapping("crmUserInfoGraduation")
public class CrmUserInfoGraduationController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmUserInfoGraduationService crmUserInfoGraduationService;

    /**
     * 分页查询
     *
     * @param crmUserInfoGraduation 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage(@Validated CrmUserInfoGraduationVO crmUserInfoGraduation) {
        Map<String,Object> data = this.crmUserInfoGraduationService.queryByPage(crmUserInfoGraduation);
        return ResultBuilder.buildListSuccess(data);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {
        return ResultBuilder.buildListSuccess(this.crmUserInfoGraduationService.queryById(id));

    }

    /**
     * 新增数据
     *
     * @param crmUserInfoGraduation 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody CrmUserInfoGraduation crmUserInfoGraduation) {
        this.crmUserInfoGraduationService.insert(crmUserInfoGraduation);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmUserInfoGraduation 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody CrmUserInfoGraduation crmUserInfoGraduation) {
        this.crmUserInfoGraduationService.update(crmUserInfoGraduation);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Long id) {
        this.crmUserInfoGraduationService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

}

