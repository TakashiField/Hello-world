package com.chinatechstar.crm.dao;

import com.chinatechstar.crm.entity.CrmPropertyVisiable;
import com.chinatechstar.crm.vo.CrmPropertyVisiableVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 属性可见控制表(CrmPropertyVisiable)表数据库访问层
 *
 * @author zhengxl
 * @since 2024-06-28 10:00:31
 */
public interface CrmPropertyVisiableDao {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmPropertyVisiable queryById(Long id);

    /**
     * 查询指定行数据
     *
     * @param crmPropertyVisiable 查询条件
     * @return 对象列表
     */
    List<CrmPropertyVisiable> queryAllByPage(CrmPropertyVisiableVO crmPropertyVisiable);

    /**
     * 统计总行数
     *
     * @param crmPropertyVisiable 查询条件
     * @return 总行数
     */
    long count(CrmPropertyVisiableVO crmPropertyVisiable);

    /**
     * 新增数据
     *
     * @param crmPropertyVisiable 实例对象
     * @return 影响行数
     */
    int insert(CrmPropertyVisiable crmPropertyVisiable);

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmPropertyVisiable> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<CrmPropertyVisiable> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmPropertyVisiable> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<CrmPropertyVisiable> entities);

    /**
     * 修改数据
     *
     * @param crmPropertyVisiable 实例对象
     * @return 影响行数
     */
    int update(Long[] crmPropertyVisiable);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 影响行数
     */
    int deleteById(Long id);

    void turnOff();
}

