package com.chinatechstar.crm.service.impl;

import com.chinatechstar.crm.entity.CrmUserWealthInfoDetail;
import com.chinatechstar.crm.dao.CrmUserWealthInfoDetailDao;
import com.chinatechstar.crm.service.CrmUserWealthInfoDetailService;
import org.springframework.stereotype.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员资产明细表(CrmUserWealthInfoDetail)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:03
 */
@Service("crmUserWealthInfoDetailService")
public class CrmUserWealthInfoDetailServiceImpl implements CrmUserWealthInfoDetailService {
    @Autowired
    private CrmUserWealthInfoDetailDao crmUserWealthInfoDetailDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmUserWealthInfoDetail queryById(Integer id) {
        return this.crmUserWealthInfoDetailDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param crmUserWealthInfoDetail 筛选条件
     * @return 查询结果
     */
    @Override
    public List<CrmUserWealthInfoDetail> queryByPage(CrmUserWealthInfoDetail crmUserWealthInfoDetail) {
        long total = this.crmUserWealthInfoDetailDao.count(crmUserWealthInfoDetail);
        return (this.crmUserWealthInfoDetailDao.queryAllByPage(crmUserWealthInfoDetail));
    }


    /**
     * 新增数据
     *
     * @param crmUserWealthInfoDetail 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserWealthInfoDetail insert(CrmUserWealthInfoDetail crmUserWealthInfoDetail) {
        this.crmUserWealthInfoDetailDao.insert(crmUserWealthInfoDetail);
        return crmUserWealthInfoDetail;
    }

    /**
     * 修改数据
     *
     * @param crmUserWealthInfoDetail 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserWealthInfoDetail update(CrmUserWealthInfoDetail crmUserWealthInfoDetail) {
        this.crmUserWealthInfoDetailDao.update(crmUserWealthInfoDetail);
        return this.queryById(crmUserWealthInfoDetail.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Integer id) {
        return this.crmUserWealthInfoDetailDao.deleteById(id) > 0;
    }
}
