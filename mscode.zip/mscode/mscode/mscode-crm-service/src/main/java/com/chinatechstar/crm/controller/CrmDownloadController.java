package com.chinatechstar.crm.controller;

import com.alibaba.fastjson.JSON;
import com.chinatechstar.component.commons.config.JsonResult;
import com.chinatechstar.component.commons.utils.StringUtils;
import com.chinatechstar.component.commons.utils.UUIDUtil;
import com.chinatechstar.crm.config.QiNiuClient;
import com.chinatechstar.crm.download.ICrmDownloadService;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * @author lixu
 */
@RestController
@RequestMapping("/crmDownload")
public class CrmDownloadController {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    Map<String, ICrmDownloadService> downloadServiceMap;

    /**
     * 单图片上传，直接上传到图片服务器 add by lyt 20200610
     * @param file
     * @return
     * @throws IOException
     */
    @RequestMapping("/fileDownload")
    public void fileDownload(@RequestParam("fileType") String fileType, HttpServletResponse response){

        ICrmDownloadService iCrmDownloadService = downloadServiceMap.get(fileType);
        iCrmDownloadService.download(response);
    }
}
