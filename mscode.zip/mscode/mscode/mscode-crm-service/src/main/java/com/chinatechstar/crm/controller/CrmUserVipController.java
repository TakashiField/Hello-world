package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.PaginationBuilder;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmUserRelation;
import com.chinatechstar.crm.entity.CrmUserVip;
import com.chinatechstar.crm.service.CrmUserVipService;
import com.chinatechstar.crm.vo.CrmUserVipVO;
import com.github.pagehelper.PageInfo;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 消费会员列表(CrmUserVip)表控制层
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:01
 */
@RestController
@RequestMapping("crmUserVip")
public class CrmUserVipController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmUserVipService crmUserVipService;

    /**
     * 分页查询
     *
     * @param vo 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage(@Validated CrmUserVipVO vo) {
        Map<String, Object> data = this.crmUserVipService.queryByPage(vo);
        return ResultBuilder.buildListSuccess(data);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {
        CrmUserVip crmUserVip = this.crmUserVipService.queryById(id);
        return ResultBuilder.buildListSuccess(crmUserVip);
    }

    /**
     * 新增数据
     *
     * @param crmUserVip 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody CrmUserVip crmUserVip) {
        this.crmUserVipService.insert(crmUserVip);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmUserVip 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody CrmUserVip crmUserVip) {
        this.crmUserVipService.update(crmUserVip);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Long id) {
        this.crmUserVipService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

}

