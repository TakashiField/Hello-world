package com.chinatechstar.crm.service.impl;

import com.chinatechstar.component.commons.result.PaginationBuilder;
import com.chinatechstar.component.commons.utils.SequenceGenerator;
import com.chinatechstar.crm.entity.CrmPropertyCustomed;
import com.chinatechstar.crm.entity.CrmRelationSymbol;
import com.chinatechstar.crm.dao.CrmRelationSymbolDao;
import com.chinatechstar.crm.service.CrmRelationSymbolService;
import com.chinatechstar.crm.util.DateUtils;
import com.chinatechstar.crm.vo.CrmRelationSymbolVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * 会员标签表(CrmRelationSymbol)表服务实现类
 *
 * @author makejava
 * @since 2024-06-26 09:59:20
 */
@Service("crmRelationSymbolService")
public class CrmRelationSymbolServiceImpl implements CrmRelationSymbolService {
    @Resource
    private CrmRelationSymbolDao crmRelationSymbolDao;

    private static final SequenceGenerator sequenceGenerator = new SequenceGenerator();

    /**
     * 通过ID查询单条数据
     *
     * @param symbolId 主键
     * @return 实例对象
     */
    @Override
    public CrmRelationSymbol queryById(Long symbolId) {
        return this.crmRelationSymbolDao.queryById(symbolId);
    }

    /*
     * 分页查询
     *
     * @param vo 筛选条件
     * @return 查询结果
     */
    @Override
    public Map<String, Object> queryByPage(CrmRelationSymbolVO vo) {
        PageHelper.startPage(vo.getCurrentPage(),vo.getPageSize(),true);
        List<CrmRelationSymbol> symbolList = this.crmRelationSymbolDao.queryAllByPage(vo);
        PageInfo<CrmRelationSymbol> pageInfo = new PageInfo<>(symbolList);
        return PaginationBuilder.buildResultObject(symbolList, pageInfo.getTotal(), vo.getCurrentPage(), vo.getPageSize());

    }


    /**
     * 新增数据
     *
     * @param crmRelationSymbol 实例对象
     * @return 实例对象
     */
    @Override
    public CrmRelationSymbol insert(CrmRelationSymbol crmRelationSymbol) {
        CrmRelationSymbol select = new CrmRelationSymbol();
        select.setSymbolName(crmRelationSymbol.getSymbolName());
        long count = this.crmRelationSymbolDao.count(select);
        if ( count > 0 ){
            throw new RuntimeException("该标签已存在");
        } else {
            crmRelationSymbol.setId(sequenceGenerator.nextId());
            crmRelationSymbol.setCreateTime(DateUtils.timestamp());
            this.crmRelationSymbolDao.insert(crmRelationSymbol);
            return crmRelationSymbol;
        }
    }

    /**
     * 修改数据
     *
     * @param crmRelationSymbol 实例对象
     * @return 实例对象
     */
    @Override
    public CrmRelationSymbol update(CrmRelationSymbol crmRelationSymbol) {
        crmRelationSymbol.setUpdateTime(DateUtils.timestamp());
        crmRelationSymbol.setUpdateUser(crmRelationSymbol.getOperatorName());
        this.crmRelationSymbolDao.update(crmRelationSymbol);
        return this.queryById(crmRelationSymbol.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param symbolId 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long symbolId) {
        return this.crmRelationSymbolDao.deleteById(symbolId) > 0;
    }
}
