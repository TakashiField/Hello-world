package com.chinatechstar.crm.config;

import com.google.gson.Gson;
import com.qiniu.common.QiniuException;
import com.qiniu.common.Zone;
import com.qiniu.http.Response;
import com.qiniu.storage.BucketManager;
import com.qiniu.storage.Configuration;
import com.qiniu.storage.UploadManager;
import com.qiniu.storage.model.DefaultPutRet;
import com.qiniu.util.Auth;
import com.qiniu.util.Base64;
import com.qiniu.util.StringMap;
import com.qiniu.util.UrlSafeBase64;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.ResponseBody;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * @description:七牛云工具类
 * @author: zhg
 * @create: 2020-09-15 10:51
 **/
@Component("qiNiuClient")
public class QiNiuClient {

    private final  Logger logger = LoggerFactory.getLogger(getClass());

	/**
     * 路径分隔符
     */
    public static final String SEPARATOR = "/";
    /**
     * Point
     */
    public static final String POINT = ".";
	 /**
     * ContentType
     */
    public static final Map<String, String> EXT_MAPS = new HashMap<>();
	// 七牛文件上传管理器
    private  UploadManager uploadManager;
    private QiNiuCloudConfig qiNiuConfig;
    private  String token;
    // 七牛认证管理
    private Auth auth;
    private Configuration cfg;
    private BucketManager bucketManager;

    public QiNiuClient(QiNiuCloudConfig config){//
        this.qiNiuConfig = config;
        init();
    }

    private  void init(){
    	 // image
        EXT_MAPS.put("png", "image/png");
        EXT_MAPS.put("gif", "image/gif");
        EXT_MAPS.put("bmp", "image/bmp");
        EXT_MAPS.put("ico", "image/x-ico");
        EXT_MAPS.put("jpeg", "image/jpeg");
        EXT_MAPS.put("jpg", "image/jpeg");
        // 压缩文件
        EXT_MAPS.put("zip", "application/zip");
        EXT_MAPS.put("rar", "application/x-rar");
        // doc
        EXT_MAPS.put("pdf", "application/pdf");
        EXT_MAPS.put("ppt", "application/vnd.ms-powerpoint");
        EXT_MAPS.put("xls", "application/vnd.ms-excel");
        EXT_MAPS.put("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        EXT_MAPS.put("pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation");
        EXT_MAPS.put("doc", "application/msword");
        EXT_MAPS.put("doc", "application/wps-office.doc");
        EXT_MAPS.put("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        EXT_MAPS.put("txt", "text/plain");
        // 音频
        EXT_MAPS.put("mp4", "video/mp4");
        EXT_MAPS.put("flv", "video/x-flv");

        // 构造一个带指定Zone对象的配置类, 注意这里的Zone.zone0需要根据主机选择
    	//Zone.zone0:华东
        //Zone.zone1:华北
        //Zone.zone2:华南
        //Zone.zoneNa0:北美
        //———http上传，自动识别上传区域——  //Zone.httpAutoZone
        //———https上传，自动识别上传区域—— //Zone.httpsAutoZone
    	//构造一个带指定Zone对象的配置类
    	cfg = new Configuration(Zone.zone2());
    	uploadManager = new UploadManager(cfg);
//    	System.out.println("qiNiuConfig:::::"+qiNiuConfig);
//    	System.out.println("qiNiuConfig.getQiniuAccessKey():"+qiNiuConfig.getQiniuAccessKey());
//    	System.out.println(" qiNiuConfig.getQiniuSecretKey():"+ qiNiuConfig.getQiniuSecretKey());
        auth = Auth.create(qiNiuConfig.getQiniuAccessKey(), qiNiuConfig.getQiniuSecretKey());
        // 根据命名空间生成的上传token
       // token = auth.uploadToken(qiNiuConfig.getQiniuBucketName());
       // System.out.println("init token:::::"+token);
        System.out.println("auth："+auth);
        System.out.println("cfg："+cfg);
        bucketManager=new BucketManager(auth,  cfg);//new Configuration()
        System.out.println("bucketManager:"+bucketManager);
    }

    /**
     * 七牛云上传图片
     * @param inputStream 文件输入流
     * @param key  唯一图片名称
     * @param prefixName  文件前缀
     * @return
     */
    public String uploadImg(InputStream inputStream, String key,String prefixName) {
        try{
//       	 // 获取文件的名称
//          String fileName = file.getOriginalFilename();
//          // 使用工具类根据上传文件生成唯一图片名称
          String imgName = getRandomImgName(key,prefixName);
//          if (file.isEmpty()) {
//              return "";
//          }
//          FileInputStream inputStream = (FileInputStream) file.getInputStream();
            token = auth.uploadToken(qiNiuConfig.getQiniuBucketName());
//        	System.out.println("inputStream:"+inputStream);
//        	System.out.println("key:"+key);
//        	System.out.println("imgName:"+imgName);
//        	System.out.println("token:"+token);
//        	System.out.println("uploadManager:"+uploadManager);
            // 上传图片文件
            Response res = uploadManager.put(inputStream, imgName, token, null, null);
            if (!res.isOK()) {
                throw new RuntimeException("上传七牛出错：" + res.toString());
            }
            // 解析上传成功的结果
            DefaultPutRet putRet = new Gson().fromJson(res.bodyString(), DefaultPutRet.class);
            System.out.println("putRet:"+putRet);
            String path = qiNiuConfig.getQiniuDomain() + "/" + putRet.key;
            System.out.println("path:"+path);
            // 这个returnPath是获得到的外链地址,通过这个地址可以直接打开图片
            return path;
        }catch (QiniuException e){
            e.printStackTrace();
        }
        return "";
    }
    /**
     * 上传方法3 覆盖上传
     * @param key 覆盖文件的文件名
     */
    public boolean overrideUpload(File file, String key) {
        try {
        	//path=toLocal(path);
        	//insertOnly 如果希望只能上传指定key的文件，并且不允许修改，那么可以将下面的 insertOnly 属性值设为 1
            String token = auth.uploadToken(qiNiuConfig.getQiniuBucketName(), key, 3600, new StringMap().put("insertOnly", 0));//获取 token
            Response response = uploadManager.put(file, key, token);//执行上传，通过token来识别 该上传是“覆盖上传”
            System.out.println(response.toString());
            int retry = 0;
            if (null == response || 200 != response.statusCode) {
		    	while (response.needRetry() && retry++ < 3) {
		            response = uploadManager.put(file, key, token);
		            System.out.println(response);
		            System.out.println("response:"+response.statusCode);
		            if (200 == response.statusCode) {
						System.out.println("覆盖成功1");
						return true;
					}
		        }
				return false;
			}

        } catch (QiniuException e) {
            System.out.println(e.response.statusCode);
            e.printStackTrace();
        }
        System.out.println("覆盖成功2");
		return true;
    }
    // base64方式上传
    public void put64image(String filePath, String fileName, String key) throws Exception {
    	token = auth.uploadToken(qiNiuConfig.getQiniuBucketName());

    	filePath=toLocal(filePath);
        FileInputStream fis = null;
        int l = (int) (new File(filePath).length());
        byte[] src = new byte[l];
        fis = new FileInputStream(new File(filePath));
        fis.read(src);
        String file64 = Base64.encodeToString(src, 0);
        String url = "http://upload.qiniu.com/putb64/" + l + "/key/" + UrlSafeBase64.encodeToString(fileName);
        okhttp3.RequestBody rb =  okhttp3.RequestBody.create(null, file64);
        Request request = new Request.Builder().url(url).addHeader("Content-Type", "application/octet-stream")
                .addHeader("Authorization", "UpToken " + token).post(rb).build();
        System.out.println(request.headers());
        OkHttpClient client = new OkHttpClient();
        okhttp3.Response response = client.newCall(request).execute();
        System.out.println(response);
    }

    /**
	 * 删除单个文件
	 *
	 * @return
	 */
	public boolean deleteFile(String filePath) {
		try {
			if(StringUtils.isEmpty(filePath)) {
				logger.info("删除文件路径不能为空。");
				return false;
			}
			token = auth.uploadToken(qiNiuConfig.getQiniuBucketName());
			System.out.println("token:"+token);
			String folderAndFile = filePath.substring(filePath.indexOf("com/") + 4,filePath.length());
			// 调用delete方法移动文件
			Response response = bucketManager.delete(qiNiuConfig.getQiniuBucketName(), folderAndFile);
		    int retry = 0;
		    if (null == response || 200 != response.statusCode) {
		    	while (response.needRetry() && retry++ < 3) {
		            response = bucketManager.delete(qiNiuConfig.getQiniuBucketName(), filePath);
		            System.out.println(response);
		            System.out.println("response:"+response.statusCode);
		            if (200 == response.statusCode) {
						System.out.println("删除成功1");
						return true;
					}
		        }
				return false;
			}else {
				System.out.println("删除成功2");
				return true;
			}

		} catch (Exception e) {
			logger.error("deleteFile Exception:" + e.getMessage());
			return false;
		}
	}

	/**下载
     * 获取下载文件路径，即：donwloadUrl
     * @return
     */
    public void getDownloadUrl(String targetUrl, OutputStream os, HttpServletResponse response) {
        String downloadUrl = auth.privateDownloadUrl(targetUrl);
        OkHttpClient client = new OkHttpClient();
        Request req = new Request.Builder().url(downloadUrl).build();
        okhttp3.Response resp = null;
        String filename=targetUrl.substring(targetUrl.lastIndexOf(SEPARATOR)+1,targetUrl.length());
        String filenameSuffix=getFilenameSuffix(filename);////获取文件后缀
        String contentType = EXT_MAPS.get(filenameSuffix);
        LocalDateTime date = LocalDateTime.now();
        DateTimeFormatter format1 = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        //日期转字符串
        String str = date.format(format1)+"_"+com.chinatechstar.component.commons.utils.StringUtils.getRandom620(6);
        filename=str+POINT+filenameSuffix;
        try {
            resp = client.newCall(req).execute();
            System.out.println(resp.isSuccessful());
            if(resp.isSuccessful()) {
                ResponseBody body = resp.body();
                InputStream is = body.byteStream();
              //  byte[] data = readInputStream(is);
              //  File imgFile = new File(filepath + "123.png");          //下载到本地的图片命名
              //  FileOutputStream fops = new FileOutputStream(imgFile);
                if (response != null) {
                    os = response.getOutputStream();
                    // 设置响应头
                    if (StringUtils.isNotBlank(contentType)) {
                        // 文件编码 处理文件名中的 '+'、' ' 特殊字符
                        String encoderName = URLEncoder.encode(filename, "UTF-8").replace("+", "%20").replace("%2B", "+");
                        response.setHeader("Content-Disposition", "attachment;filename=\"" + encoderName + "\"");
                        response.setContentType(contentType + ";charset=UTF-8");
                        response.setHeader("Accept-Ranges", "bytes");
                    }
                }
               // fops.write(data);
              //  fops.close();
              //  is = new ByteArrayInputStream(data);
                byte[] buffer = new byte[1024 * 5];
                int len = 0;
                while ((len = is.read(buffer)) > 0) {
                    os.write(buffer, 0, len);
                }
                os.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Unexpected code " + resp);
        }
       // return downloadUrl;
    }

    /**
     * 读取字节输入流内容
     */
    private static byte[] readInputStream(InputStream is) {
        ByteArrayOutputStream writer = new ByteArrayOutputStream();
        byte[] buff = new byte[1024 * 2];
        int len = 0;
        try {
            while((len = is.read(buff)) != -1) {
                writer.write(buff, 0, len);
            }
            is.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return writer.toByteArray();
    }

    /**
     * 获取文件名称的后缀
     *
     * @param filename 文件名 或 文件路径
     * @return 文件后缀
     */
    public static String getFilenameSuffix(String filename) {
        String suffix = null;
        String originalFilename = filename;
        if (StringUtils.isNotBlank(filename)) {
            if (filename.contains(SEPARATOR)) {
                filename = filename.substring(filename.lastIndexOf(SEPARATOR) + 1);
            }
            if (filename.contains(POINT)) {
                suffix = filename.substring(filename.lastIndexOf(POINT) + 1);
            } else {
                System.out.println("filename error without suffix : {}"+originalFilename);
            }
        }
        return suffix;
    }

    /**
     * @Description: 生成唯一图片名称
     * @Param: fileName
     * @return: 云服务器fileName
     */
    public static String getRandomImgName(String fileName,String prefixName) {

        int index = fileName.lastIndexOf(".");

        if ((fileName == null || fileName.isEmpty()) || index == -1){
            throw new IllegalArgumentException();
        }
        // 获取文件后缀
        String suffix = fileName.substring(index);
        //String suffix = FilenameUtils.getExtension(fileName);
        // 生成UUID
        String uuid = UUID.randomUUID().toString().replaceAll("-", "");
        // 生成上传至云服务器的路径
//        String path = "guokai/bv/" + DateUtils.formatPackTime(new Date()) + "-" + uuid + suffix;
      //  String path = "guokai/bv/" + uuid + suffix;
        String path=prefixName+ uuid + suffix;
        return path;
    }

    /**
     * 转换路径中的 '\' 为 '/' <br>
     * 并把文件后缀转为小写
     *
     * @param path 路径
     * @return
     */
    public static String toLocal(String path) {
        if (StringUtils.isNotBlank(path)) {
            path = path.replaceAll("\\\\", SEPARATOR);

            if (path.contains(POINT)) {
                String pre = path.substring(0, path.lastIndexOf(POINT) + 1);
                String suffix = path.substring(path.lastIndexOf(POINT) + 1).toLowerCase();
                path = pre + suffix;
            }
        }
        return path;
    }


    /**下载
     * 获取下载文件路径，即：donwloadUrl
     * @return
     */
    public void getDownloadUrl1(String targetUrl, OutputStream os, HttpServletResponse response) {
        String downloadUrl = auth.privateDownloadUrl(targetUrl);
        OkHttpClient client = new OkHttpClient();
        Request req = new Request.Builder().url(downloadUrl).build();
        okhttp3.Response resp = null;
        try {
            resp = client.newCall(req).execute();
            System.out.println(resp.isSuccessful() + targetUrl);
            if(resp.isSuccessful()) {
                ResponseBody body = resp.body();
                InputStream is = body.byteStream();
                byte[] buffer = new byte[1024 * 5];
                int len = 0;
                while ((len = is.read(buffer)) > 0) {
                    os.write(buffer, 0, len);
                }
                os.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Unexpected code " + resp);
        }
        if(resp != null){
            resp.close();
        }
    }


    /**
     * 七牛云上传图片
     * @param inputStream 文件输入流
     * @return
     */
    public String uploadImg1(InputStream inputStream, String imgName) {
        try{
//       	 // 获取文件的名称
//          String fileName = file.getOriginalFilename();
//          // 使用工具类根据上传文件生成唯一图片名称
//            String imgName = getRandomImgName(key,prefixName);
//          if (file.isEmpty()) {
//              return "";
//          }
//          FileInputStream inputStream = (FileInputStream) file.getInputStream();
            token = auth.uploadToken(qiNiuConfig.getQiniuBucketName());
//        	System.out.println("inputStream:"+inputStream);
//        	System.out.println("key:"+key);
//        	System.out.println("imgName:"+imgName);
//        	System.out.println("token:"+token);
//        	System.out.println("uploadManager:"+uploadManager);
            // 上传图片文件
            Response res = uploadManager.put(inputStream, imgName, token, null, null);
            if (!res.isOK()) {
                throw new RuntimeException("上传七牛出错：" + res.toString());
            }
            // 解析上传成功的结果
            DefaultPutRet putRet = new Gson().fromJson(res.bodyString(), DefaultPutRet.class);
            System.out.println("putRet:"+putRet);
            String path = qiNiuConfig.getQiniuDomain() + "/" + putRet.key;
            System.out.println("path:"+path);
            // 这个returnPath是获得到的外链地址,通过这个地址可以直接打开图片
            return path;
        }catch (QiniuException e){
            e.printStackTrace();
        }
        return "";
    }
}
