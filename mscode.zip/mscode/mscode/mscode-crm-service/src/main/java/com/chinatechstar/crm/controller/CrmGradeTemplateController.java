package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmGradeTemplate;
import com.chinatechstar.crm.service.CrmGradeTemplateService;
import com.chinatechstar.crm.vo.CrmGradeTemplateVO;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 等级模板表(CrmGradeTemplate)表控制层
 *
 * @author zhengxl
 * @since 2024-07-02 10:04:39
 */
@RestController
@RequestMapping("crmGradeTemplate")
public class CrmGradeTemplateController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmGradeTemplateService crmGradeTemplateService;

    /**
     * 分页查询
     *
     * @param crmGradeTemplate 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage(@Validated CrmGradeTemplateVO crmGradeTemplate) {
        List<CrmGradeTemplate> result = this.crmGradeTemplateService.queryByPage(crmGradeTemplate);
        crmGradeTemplate.setCrmList(result);
        return ResultBuilder.buildListSuccess(crmGradeTemplate);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {
        CrmGradeTemplate crmGradeTemplate = this.crmGradeTemplateService.queryById(id);
        return ResultBuilder.buildListSuccess(crmGradeTemplate);
    }

    /**
     * 新增数据
     *
     * @param crmGradeTemplate 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody @Validated CrmGradeTemplateVO crmGradeTemplate) {
        this.crmGradeTemplateService.insert(crmGradeTemplate);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmGradeTemplate 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody @Validated CrmGradeTemplate crmGradeTemplate) {
        this.crmGradeTemplateService.update(crmGradeTemplate);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Long id) {
        this.crmGradeTemplateService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

    @PostMapping("/turnOn")
    public ActionResult turnOn(Long id) {
        this.crmGradeTemplateService.turnOn(id);
        return ResultBuilder.buildActionSuccess();
    }

    @PostMapping("/turnOff")
    public ActionResult turnOff(Long id) {
        this.crmGradeTemplateService.turnOff(id);
        return ResultBuilder.buildActionSuccess();
    }

}

