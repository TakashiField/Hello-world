package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmParam;
import com.chinatechstar.crm.vo.CrmParamVO;

import java.util.List;
import java.util.Map;

/**
 * 选项参数表(CrmParam)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-18 16:49:16
 */
public interface CrmParamService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmParam queryById(Long id);

    /**
     * 分页查询
     *
     * @param crmParam 筛选条件
     * @return 查询结果
     */
    Map<String, Object> queryByPage(CrmParamVO crmParam);

    /**
     * 新增数据
     *
     * @param crmParam 实例对象
     * @return 实例对象
     */
    CrmParam insert(CrmParam crmParam);

    /**
     * 修改数据
     *
     * @param crmParam 实例对象
     * @return 实例对象
     */
    CrmParam update(CrmParam crmParam);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Long id);

    List<CrmParam> queryByPageParent(CrmParamVO crmParam);
}
