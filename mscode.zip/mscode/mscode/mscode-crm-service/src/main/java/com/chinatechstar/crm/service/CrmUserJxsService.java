package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmUserJxs;
import com.chinatechstar.crm.vo.CrmUserJxsVO;

import java.util.List;

/**
 * 经销商列表(CrmUserJxs)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:01
 */
public interface CrmUserJxsService {

    /**
     * 通过ID查询单条数据
     *
     * @param userId 主键
     * @return 实例对象
     */
    CrmUserJxs queryById(Long userId);

    /**
     * 分页查询
     *
     * @param crmUserJxs 筛选条件
     * @return 查询结果
     */
    List<CrmUserJxs> queryByPage(CrmUserJxsVO crmUserJxs);

    /**
     * 新增数据
     *
     * @param crmUserJxs 实例对象
     * @return 实例对象
     */
    CrmUserJxs insert(CrmUserJxs crmUserJxs);

    /**
     * 修改数据
     *
     * @param crmUserJxs 实例对象
     * @return 实例对象
     */
    CrmUserJxs update(CrmUserJxs crmUserJxs);

    /**
     * 通过主键删除数据
     *
     * @param userId 主键
     * @return 是否成功
     */
    boolean deleteById(Long userId);

}
