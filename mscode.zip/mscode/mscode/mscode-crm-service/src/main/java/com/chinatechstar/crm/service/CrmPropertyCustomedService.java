package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmPropertyCustomed;
import com.chinatechstar.crm.vo.CrmPropertyCustomedVO;

import java.util.List;
import java.util.Map;


/**
 * 自定义标签表(CrmPropertyCustomed)表服务接口
 *
 * @author makejava
 * @since 2024-06-24 17:20:22
 */
public interface CrmPropertyCustomedService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmPropertyCustomed queryById(Long id);

    /**
     * 分页查询
     *
     * @param vo 筛选条件
     * @return 查询结果
     */
    Map<String, Object> queryByPage(CrmPropertyCustomedVO vo);
    /**
     * 新增数据
     *
     * @param crmPropertyCustomed 实例对象
     * @return 实例对象
     */
    CrmPropertyCustomed insert(CrmPropertyCustomed crmPropertyCustomed);

    /**
     * 修改数据
     *
     * @param crmPropertyCustomed 实例对象
     * @return 实例对象
     */
    CrmPropertyCustomed update(CrmPropertyCustomed crmPropertyCustomed);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Long[] id);

}
