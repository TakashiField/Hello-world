package com.chinatechstar.crm.schedule;

import cn.hutool.core.lang.copier.Copier;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.schedule
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-15 16-40
 * @Description: TODO
 * @Version: 1.0
 */
public class CrmExectors {

    private ExecutorService executorService;

    private final int coreSize = 10;

    private Runnable runnable;
    public CrmExectors(Runnable runnable) {
        ExecutorService executorService = Executors.newFixedThreadPool(coreSize);
        this.executorService = executorService;
        this.runnable = runnable;
    }

    public void run(){
        executorService.submit(runnable);
        executorService.shutdown();
    }

}
