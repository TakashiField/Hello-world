package com.chinatechstar.crm.service;

public interface CrmBaseService {

    void insert();

}
