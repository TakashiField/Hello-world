package com.chinatechstar.crm.service.impl;

import com.chinatechstar.crm.entity.CrmUserJxs;
import com.chinatechstar.crm.dao.CrmUserJxsDao;
import com.chinatechstar.crm.service.CrmUserJxsService;
import com.chinatechstar.crm.vo.CrmUserJxsVO;
import com.github.pagehelper.PageHelper;
import org.springframework.stereotype.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 经销商列表(CrmUserJxs)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:01
 */
@Service("crmUserJxsService")
public class CrmUserJxsServiceImpl implements CrmUserJxsService {
    @Autowired
    private CrmUserJxsDao crmUserJxsDao;

    /**
     * 通过ID查询单条数据
     *
     * @param userId 主键
     * @return 实例对象
     */
    @Override
    public CrmUserJxs queryById(Long userId) {
        return this.crmUserJxsDao.queryById(userId);
    }

    /**
     * 分页查询
     *
     * @param crmUserJxs 筛选条件
     * @return 查询结果
     */
    @Override
    public List<CrmUserJxs> queryByPage(CrmUserJxsVO crmUserJxs) {
        //long total = this.crmUserJxsDao.count(crmUserJxs);
        PageHelper.startPage(crmUserJxs.getCurrentPage(),crmUserJxs.getPageSize());
        return (this.crmUserJxsDao.queryAllByPage(crmUserJxs));
    }


    /**
     * 新增数据
     *
     * @param crmUserJxs 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserJxs insert(CrmUserJxs crmUserJxs) {
        this.crmUserJxsDao.insert(crmUserJxs);
        return crmUserJxs;
    }

    /**
     * 修改数据
     *
     * @param crmUserJxs 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserJxs update(CrmUserJxs crmUserJxs) {
        this.crmUserJxsDao.update(crmUserJxs);
        return this.queryById(crmUserJxs.getUserId());
    }

    /**
     * 通过主键删除数据
     *
     * @param userId 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long userId) {
        return this.crmUserJxsDao.deleteById(userId) > 0;
    }
}
