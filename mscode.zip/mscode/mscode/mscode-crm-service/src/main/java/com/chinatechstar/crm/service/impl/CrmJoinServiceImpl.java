package com.chinatechstar.crm.service.impl;

import com.chinatechstar.crm.entity.CrmJoin;
import com.chinatechstar.crm.dao.CrmJoinDao;
import com.chinatechstar.crm.service.CrmJoinService;
import org.springframework.stereotype.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 招商加盟表(CrmJoin)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-08 15:35:19
 */
@Service("crmJoinService")
public class CrmJoinServiceImpl implements CrmJoinService {
    @Autowired
    private CrmJoinDao crmJoinDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmJoin queryById(Long id) {
        return this.crmJoinDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param crmJoin 筛选条件
     * @return 查询结果
     */
    @Override
    public List<CrmJoin> queryByPage(CrmJoin crmJoin) {
        long total = this.crmJoinDao.count(crmJoin);
        return (this.crmJoinDao.queryAllByPage(crmJoin));
    }


    /**
     * 新增数据
     *
     * @param crmJoin 实例对象
     * @return 实例对象
     */
    @Override
    public CrmJoin insert(CrmJoin crmJoin) {
        this.crmJoinDao.insert(crmJoin);
        return crmJoin;
    }

    /**
     * 修改数据
     *
     * @param crmJoin 实例对象
     * @return 实例对象
     */
    @Override
    public CrmJoin update(CrmJoin crmJoin) {
        this.crmJoinDao.update(crmJoin);
        return this.queryById(crmJoin.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return this.crmJoinDao.deleteById(id) > 0;
    }
}
