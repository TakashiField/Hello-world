package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmUserInfoWork;
import com.chinatechstar.crm.vo.CrmUserInfoWorkVO;

import java.util.List;
import java.util.Map;

/**
 * 会员健康信息表(CrmUserInfoWork)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:03
 */
public interface CrmUserInfoWorkService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmUserInfoWork queryById(Long id);

    /**
     * 分页查询
     *
     * @param crmUserInfoWork 筛选条件
     * @return 查询结果
     */
    Map<String, Object> queryByPage(CrmUserInfoWorkVO crmUserInfoWork);

    /**
     * 新增数据
     *
     * @param crmUserInfoWork 实例对象
     * @return 实例对象
     */
    CrmUserInfoWork insert(CrmUserInfoWork crmUserInfoWork);

    /**
     * 修改数据
     *
     * @param crmUserInfoWork 实例对象
     * @return 实例对象
     */
    CrmUserInfoWork update(CrmUserInfoWork crmUserInfoWork);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Long id);

}
