package com.chinatechstar.crm.dao;

import com.chinatechstar.crm.entity.CrmUserHonor;
import com.chinatechstar.crm.vo.CrmUserHonorVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 会员荣誉列表(CrmUserHonor)表数据库访问层
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:00
 */
public interface CrmUserHonorDao {

    /**
     * 通过ID查询单条数据
     *
     * @param userId 主键
     * @return 实例对象
     */
    CrmUserHonor queryById(Long userId);

    /**
     * 查询指定行数据
     *
     * @param crmUserHonor 查询条件
     * @return 对象列表
     */
    List<CrmUserHonor> queryAllByPage(CrmUserHonorVO crmUserHonor);

    /**
     * 统计总行数
     *
     * @param crmUserHonor 查询条件
     * @return 总行数
     */
    long count(CrmUserHonor crmUserHonor);

    /**
     * 新增数据
     *
     * @param crmUserHonor 实例对象
     * @return 影响行数
     */
    int insert(CrmUserHonor crmUserHonor);

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmUserHonor> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<CrmUserHonor> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmUserHonor> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<CrmUserHonor> entities);

    /**
     * 修改数据
     *
     * @param crmUserHonor 实例对象
     * @return 影响行数
     */
    int update(CrmUserHonor crmUserHonor);

    /**
     * 通过主键删除数据
     *
     * @param userId 主键
     * @return 影响行数
     */
    int deleteById(Long userId);

}

