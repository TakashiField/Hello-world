//package com.chinatechstar.crm.controller;
//
//import com.chinatechstar.crm.constants.CrmConstants;
//import com.chinatechstar.crm.entity.CrmRelationType;
//import com.chinatechstar.crm.service.CrmService;
//import com.chinatechstar.crm.vo.CrmCommReqVO;
//import com.chinatechstar.crm.vo.CrmCommResVO;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.poi.ss.formula.functions.T;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.validation.annotation.Validated;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import java.lang.reflect.InvocationTargetException;
//import java.lang.reflect.Method;
//import java.util.Map;
//
///**
// * @Project: mscode
// * @Package: com.chinatechstar.crm.controller
// * @Author: zhengxiaolei
// * @CreateTime: 2024-06-26 14-14
// * @Description: TODO
// * @Version: 1.0
// */
//@RestController
//@RequestMapping("crmBase")
//@Slf4j
//public class CrmBaseController {
//
//    @Autowired
//    private Map<String, CrmService> crmServiceMap;
//
//    @RequestMapping("/crm")
//    public CrmCommResVO<T> crm(@RequestBody @Validated CrmCommReqVO<T> crmCommReqVO){
//
//        /** 获取交易代码来获取请求的服务信息 */
//        String jydm = crmCommReqVO.getTrans_code();
//        CrmService service = crmServiceMap.get(jydm);
//
//        Class<? extends CrmService> clazz = service.getClass();
//        /** 获取操作类型 add-新增 query-查询 update-修改 delete 删除 */
//        String operType = crmCommReqVO.getOper_type();
//        String method = null;
//        switch (operType){
//            case CrmConstants.OPERATE_TYPE_ADD:
//                method = "insert";
//                break;
//            case CrmConstants.OPERATE_TYPE_DELETE:
//                method = "deleteById";
//                break;
//            case CrmConstants.OPERATE_TYPE_QUEUY:
//                method = "queryById";
//                break;
//            case CrmConstants.OPERATE_TYPE_UPDATE:
//                method = "update";
//                break;
//            default:
//                throw new RuntimeException("无效的操作类型");
//        }
//        CrmCommResVO<T> resVO = null;
//        try {
//            Method methods = clazz.getMethod(method, CrmRelationType.class);
//
//            resVO = (CrmCommResVO<T>) methods.invoke(service,(CrmRelationType) crmCommReqVO.getReq_data());
//        } catch (NoSuchMethodException e) {
//            throw new RuntimeException(e);
//        } catch (IllegalAccessException e) {
//            throw new RuntimeException(e);
//        } catch (InvocationTargetException e) {
//            throw new RuntimeException(e);
//        }
//
//        return resVO;
//    }
//}
