package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmRelationSymbol;
import com.chinatechstar.crm.vo.CrmRelationSymbolVO;

import java.util.List;
import java.util.Map;

/**
 * 会员标签表(CrmRelationSymbol)表服务接口
 *
 * @author makejava
 * @since 2024-06-26 09:59:20
 */
public interface CrmRelationSymbolService {

    /**
     * 通过ID查询单条数据
     *
     * @param symbolId 主键
     * @return 实例对象
     */
    CrmRelationSymbol queryById(Long symbolId);

    /*
     * 分页查询
     *
     * @param crmRelationSymbol 筛选条件
     * @return 查询结果
     */
    Map<String, Object> queryByPage(CrmRelationSymbolVO crmRelationSymbol);


    /**
     * 新增数据
     *
     * @param crmRelationSymbol 实例对象
     * @return 实例对象
     */
    CrmRelationSymbol insert(CrmRelationSymbol crmRelationSymbol);

    /**
     * 修改数据
     *
     * @param crmRelationSymbol 实例对象
     * @return 实例对象
     */
    CrmRelationSymbol update(CrmRelationSymbol crmRelationSymbol);

    /**
     * 通过主键删除数据
     *
     * @param symbolId 主键
     * @return 是否成功
     */
    boolean deleteById(Long symbolId);

}
