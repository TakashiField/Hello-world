package com.chinatechstar.crm.service.impl;

import com.chinatechstar.component.commons.result.PaginationBuilder;
import com.chinatechstar.component.commons.utils.CurrentUserUtils;
import com.chinatechstar.component.commons.utils.SequenceGenerator;
import com.chinatechstar.crm.entity.CrmUserInfoHealth;
import com.chinatechstar.crm.entity.CrmUserInfoWork;
import com.chinatechstar.crm.dao.CrmUserInfoWorkDao;
import com.chinatechstar.crm.service.CrmUserInfoWorkService;
import com.chinatechstar.crm.util.DateUtils;
import com.chinatechstar.crm.vo.CrmUserInfoWorkVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员健康信息表(CrmUserInfoWork)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:03
 */
@Service("crmUserInfoWorkService")
public class CrmUserInfoWorkServiceImpl implements CrmUserInfoWorkService {

    private static final SequenceGenerator sequenceGenerator = new SequenceGenerator();
    @Autowired
    private CrmUserInfoWorkDao crmUserInfoWorkDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmUserInfoWork queryById(Long id) {
        return this.crmUserInfoWorkDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param crmUserInfoWork 筛选条件
     * @return 查询结果
     */
    @Override
    public Map<String, Object> queryByPage(CrmUserInfoWorkVO crmUserInfoWork) {
        PageHelper.startPage(crmUserInfoWork.getCurrentPage(),crmUserInfoWork.getPageSize(),true);
        List<CrmUserInfoWork> workList = this.crmUserInfoWorkDao.queryAllByPage(crmUserInfoWork);
        PageInfo<CrmUserInfoWork> pageInfo = new PageInfo<>(workList);
        return PaginationBuilder.buildResultObject(workList, pageInfo.getTotal(), crmUserInfoWork.getCurrentPage(), crmUserInfoWork.getPageSize());

    }


    /**
     * 新增数据
     *
     * @param crmUserInfoWork 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserInfoWork insert(CrmUserInfoWork crmUserInfoWork) {

        //String tenantCode = CurrentUserUtils.getOAuth2AuthenticationDetailsInfo().get("tenantCode");
        crmUserInfoWork.setId(sequenceGenerator.nextId());
        crmUserInfoWork.setUserId(crmUserInfoWork.getUserId());
        crmUserInfoWork.setCreateUser(crmUserInfoWork.getOperatorName());
        crmUserInfoWork.setCreateTime(DateUtils.timestamp());
        this.crmUserInfoWorkDao.insert(crmUserInfoWork);
        return crmUserInfoWork;
    }

    /**
     * 修改数据
     *
     * @param crmUserInfoWork 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserInfoWork update(CrmUserInfoWork crmUserInfoWork) {
        crmUserInfoWork.setUpdateTime(DateUtils.timestamp());
        crmUserInfoWork.setUpdateUser(crmUserInfoWork.getOperatorName());
        this.crmUserInfoWorkDao.update(crmUserInfoWork);
        return this.queryById(crmUserInfoWork.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return this.crmUserInfoWorkDao.deleteById(id) > 0;
    }
}
