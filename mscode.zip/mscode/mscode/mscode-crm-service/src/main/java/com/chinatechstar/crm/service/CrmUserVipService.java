package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmUserVip;
import com.chinatechstar.crm.vo.CrmUserVipVO;

import java.util.List;
import java.util.Map;

/**
 * 消费会员列表(CrmUserVip)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:02
 */
public interface CrmUserVipService {

    /**
     * 通过ID查询单条数据
     *
     * @param userId 主键
     * @return 实例对象
     */
    CrmUserVip queryById(Long userId);

    /**
     * 分页查询
     *
     * @param crmUserVip 筛选条件
     * @return 查询结果
     */
    Map<String, Object> queryByPage(CrmUserVipVO crmUserVip);

    /**
     * 新增数据
     *
     * @param crmUserVip 实例对象
     * @return 实例对象
     */
    CrmUserVip insert(CrmUserVip crmUserVip);

    /**
     * 修改数据
     *
     * @param crmUserVip 实例对象
     * @return 实例对象
     */
    CrmUserVip update(CrmUserVip crmUserVip);

    /**
     * 通过主键删除数据
     *
     * @param userId 主键
     * @return 是否成功
     */
    boolean deleteById(Long userId);

}
