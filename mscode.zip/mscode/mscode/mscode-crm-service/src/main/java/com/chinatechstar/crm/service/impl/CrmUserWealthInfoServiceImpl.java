package com.chinatechstar.crm.service.impl;

import com.chinatechstar.crm.entity.CrmUserWealthInfo;
import com.chinatechstar.crm.dao.CrmUserWealthInfoDao;
import com.chinatechstar.crm.service.CrmUserWealthInfoService;
import org.springframework.stereotype.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员资产信息表(CrmUserWealthInfo)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:02
 */
@Service("crmUserWealthInfoService")
public class CrmUserWealthInfoServiceImpl implements CrmUserWealthInfoService {
    @Autowired
    private CrmUserWealthInfoDao crmUserWealthInfoDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmUserWealthInfo queryById(Integer id) {
        return this.crmUserWealthInfoDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param crmUserWealthInfo 筛选条件
     * @return 查询结果
     */
    @Override
    public List<CrmUserWealthInfo> queryByPage(CrmUserWealthInfo crmUserWealthInfo) {
        long total = this.crmUserWealthInfoDao.count(crmUserWealthInfo);
        return (this.crmUserWealthInfoDao.queryAllByPage(crmUserWealthInfo));
    }


    /**
     * 新增数据
     *
     * @param crmUserWealthInfo 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserWealthInfo insert(CrmUserWealthInfo crmUserWealthInfo) {
        this.crmUserWealthInfoDao.insert(crmUserWealthInfo);
        return crmUserWealthInfo;
    }

    /**
     * 修改数据
     *
     * @param crmUserWealthInfo 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUserWealthInfo update(CrmUserWealthInfo crmUserWealthInfo) {
        this.crmUserWealthInfoDao.update(crmUserWealthInfo);
        return this.queryById(crmUserWealthInfo.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Integer id) {
        return this.crmUserWealthInfoDao.deleteById(id) > 0;
    }
}
