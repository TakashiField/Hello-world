package com.chinatechstar.crm;


import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

/**
 * MSCode的系统管理启动类
 * 
 * @版权所有 东软集团
 */
@SpringBootApplication(scanBasePackages = "com.chinatechstar")
@EnableDiscoveryClient
@EnableWebSecurity
@EnableFeignClients(basePackages = { "com.chinatechstar" })
@EnableCircuitBreaker
@EnableGlobalMethodSecurity(prePostEnabled = true)
@MapperScan("com.chinatechstar.crm.dao")
@EnableWebMvc
@EnableScheduling
public class MSCodeCrmApplication {


	public static void main(String[] args) {
		SpringApplication.run(MSCodeCrmApplication.class);
	}


}
