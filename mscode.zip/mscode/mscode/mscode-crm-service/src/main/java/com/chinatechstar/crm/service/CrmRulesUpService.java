package com.chinatechstar.crm.service;
import com.chinatechstar.crm.entity.CrmRulesUp;
import com.chinatechstar.crm.vo.CrmRulesVO;

import java.util.List;

/**
 * 会员升级规则(CrmRulesUp)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-03 12:43:03
 */
public interface CrmRulesUpService {

    /**
     * 通过ID查询单条数据
     *
     * @param ruleId 主键
     * @return 实例对象
     */
    CrmRulesUp queryById(Long ruleId);

    /**
     * 分页查询
     *
     * @param crmRulesUp 筛选条件
     * @return 查询结果
     */
    List<CrmRulesUp> queryByPage(CrmRulesVO crmRulesUp);

    /**
     * 新增数据
     *
     * @param crmRulesUp 实例对象
     * @return 实例对象
     */
    CrmRulesUp insert(CrmRulesUp crmRulesUp);

    /**
     * 修改数据
     *
     * @param crmRulesUp 实例对象
     * @return 实例对象
     */
    CrmRulesUp update(CrmRulesUp crmRulesUp);

    /**
     * 通过主键删除数据
     *
     * @param ruleId 主键
     * @return 是否成功
     */
    boolean deleteById(Long ruleId);

    List<CrmRulesUp> queryByGradeId(CrmRulesVO vo);
}
