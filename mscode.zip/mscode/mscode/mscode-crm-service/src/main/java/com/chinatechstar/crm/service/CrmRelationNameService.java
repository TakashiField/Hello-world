package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmRelationName;
import com.chinatechstar.crm.vo.CrmRelationNameVO;

import java.util.List;

/**
 * 会员关系名称表(CrmRelationName)表服务接口
 *
 * @author makejava
 * @since 2024-06-26 09:59:19
 */
public interface CrmRelationNameService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmRelationName queryById(Long id);

    /*
     * 分页查询
     *
     * @param crmRelationName 筛选条件
     * @param pageRequest      分页对象
     * @return 查询结果
     */
    List<CrmRelationName> queryByPage(CrmRelationNameVO crmRelationName);


    /**
     * 新增数据
     *
     * @param crmRelationName 实例对象
     * @return 实例对象
     */
    CrmRelationName insert(CrmRelationName crmRelationName);

    /**
     * 修改数据
     *
     * @param crmRelationName 实例对象
     * @return 实例对象
     */
    CrmRelationName update(CrmRelationName crmRelationName);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Long id);

}
