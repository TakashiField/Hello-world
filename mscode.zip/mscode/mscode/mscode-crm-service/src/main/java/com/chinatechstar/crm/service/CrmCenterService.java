package com.chinatechstar.crm.service;

import com.chinatechstar.crm.vo.CrmCenterVO;

public interface CrmCenterService {

    /**
     * 根据mchtID 和 userID查询会员基本信息
     * @param vo
     * @return vo
     */
    CrmCenterVO queryCenter(CrmCenterVO vo);
}
