package com.chinatechstar.crm.service.impl;

import com.chinatechstar.component.commons.utils.UUIDUtil;
import com.chinatechstar.crm.entity.CrmRelationSymbol;
import com.chinatechstar.crm.entity.CrmRelationType;
import com.chinatechstar.crm.dao.CrmRelationTypeDao;
import com.chinatechstar.crm.service.CrmRelationTypeService;
import com.chinatechstar.crm.util.DateUtils;
import com.chinatechstar.crm.vo.CrmRelationTypeVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 会员关系类别表(CrmRelationType)表服务实现类
 *
 * @author makejava
 * @since 2024-06-26 09:59:20
 */
@Service("crmRelationTypeService")
public class CrmRelationTypeServiceImpl implements CrmRelationTypeService {
    @Resource
    private CrmRelationTypeDao crmRelationTypeDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmRelationType query(Long id) {
        return this.crmRelationTypeDao.query(id);
    }

    /*
     * 分页查询
     *
     * @param crmRelationType 筛选条件
     * @param pageRequest      分页对象
     * @return 查询结果
     */
    @Override
    public List<CrmRelationType> queryByPage(CrmRelationTypeVO vo) {
        PageHelper.startPage(vo.getCurrentPage(),vo.getPageSize(),true);
        List<CrmRelationType> relationTypeList = this.crmRelationTypeDao.queryByPage(vo);
        PageInfo<CrmRelationType> pageInfo = new PageInfo<>(relationTypeList);
        vo.setTotalSize( pageInfo.getTotal() );
        vo.setTotalPage( pageInfo.getPages() );
        return relationTypeList;
    }


    /**
     * 新增数据
     *
     * @param crmRelationType 实例对象
     * @return 实例对象
     */
    @Override
    public CrmRelationType insert(CrmRelationType crmRelationType) {
        CrmRelationType select = new CrmRelationType();
        select.setRelationType(crmRelationType.getRelationType());
        long count = crmRelationTypeDao.count(select);
        if(count > 0) {
            throw new RuntimeException("该关系类别已存在");
        } else {
            crmRelationType.setId(UUIDUtil.snowflakeId());
            crmRelationType.setCreateTime(DateUtils.timestamp());
            this.crmRelationTypeDao.insert(crmRelationType);
        }
        return crmRelationType;
    }

    /**
     * 修改数据
     *
     * @param crmRelationType 实例对象
     * @return 实例对象
     */
    @Override
    public void update(CrmRelationType crmRelationType) {
        this.crmRelationTypeDao.update(crmRelationType);

        //return this.query(crmRelationType.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return this.crmRelationTypeDao.deleteById(id) > 0;
    }
}
