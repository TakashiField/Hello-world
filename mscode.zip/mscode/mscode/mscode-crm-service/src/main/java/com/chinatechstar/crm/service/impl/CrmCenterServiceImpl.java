package com.chinatechstar.crm.service.impl;

import com.chinatechstar.crm.dao.*;
import com.chinatechstar.crm.entity.*;
import com.chinatechstar.crm.service.CrmCenterService;
import com.chinatechstar.crm.vo.CrmCenterVO;
import lombok.extern.slf4j.Slf4j;
import org.checkerframework.checker.units.qual.C;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.service.impl
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-30 15-23
 * @Description: TODO
 * @Version: 1.0
 */
@Service("crmCenterService")
@Slf4j
public class CrmCenterServiceImpl implements CrmCenterService {

    @Autowired
    private CrmUserDao crmUserDao;
    @Autowired
    private CrmUserVipDao crmUserVipDao;
    @Autowired
    private CrmUserHonorDao crmUserHonorDao;
    @Autowired
    private CrmUserJxsDao crmUserJxsDao;
    @Autowired
    private CrmUserGysDao crmUserGysDao;
    @Autowired
    private CrmParamSexDao crmParamSexDao;

    /**
     * 根据mchtID 和 userID查询会员基本信息
     *
     * @param vo
     * @return vo
     */
    @Override
    public CrmCenterVO queryCenter(CrmCenterVO vo) {
        Long userId = vo.getUserId();
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("userId",vo.getUserId());
        //查询基础信息crm_user
        CrmUser crmUser = crmUserDao.queryById(userId);
        vo.setCrmUser(crmUser);
        //查询会员等级信息
        CrmUserVip crmUserVip = crmUserVipDao.queryById(userId);
        vo.setCrmUserVip(crmUserVip);
        //查询荣誉信息
        CrmUserHonor crmUserHonor = crmUserHonorDao.queryById(userId);
        if(crmUserHonor != null) {
            vo.setCrmUserHonor(crmUserHonor);
        }
        //查询经销商信息
        CrmUserJxs crmUserJxs = crmUserJxsDao.queryById(userId);
        if(crmUserHonor != null) {
            vo.setCrmUserJxs(crmUserJxs);
        }
        //查询供货商信息
        CrmUserGys crmUserGys = crmUserGysDao.queryById(userId);
        if(crmUserHonor != null) {
            vo.setCrmUserGys(crmUserGys);
        }
        //查询性别图标
        CrmParamSex crmParamSex = crmParamSexDao.queryBySexMchtId(crmUser.getSex(),vo.getMchtId());
        vo.setCrmParamSex(crmParamSex);
        return vo;
    }
}
