package com.chinatechstar.crm.service.impl;

import com.chinatechstar.crm.dao.CrmUserDao;
import com.chinatechstar.crm.entity.CrmCooperationManager;
import com.chinatechstar.crm.dao.CrmCooperationManagerDao;
import com.chinatechstar.crm.service.CrmCooperationManagerService;
import com.chinatechstar.crm.util.DateUtils;
import com.chinatechstar.crm.vo.CrmCooperationManagerVO;
import com.github.pagehelper.PageHelper;

import org.springframework.stereotype.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 合作商管理表(CrmCooperationManager)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-01 10:20:46
 */
@Service("crmCooperationManagerService")
public class CrmCooperationManagerServiceImpl implements CrmCooperationManagerService {
    @Autowired
    private CrmCooperationManagerDao crmCooperationManagerDao;
    @Autowired
    private CrmUserDao crmUserDao;
    /**
     * 通过ID查询单条数据
     *
     * @param userId 主键
     * @return 实例对象
     */
    @Override
    public CrmCooperationManager queryById(Long userId) {
        return this.crmCooperationManagerDao.queryById(userId);
    }

    /**
     * 分页查询
     *
     * @param crmCooperationManager 筛选条件
     * @return 查询结果
     */
    @Override
    public List<CrmCooperationManager> queryByPage(CrmCooperationManagerVO crmCooperationManager) {
        PageHelper.startPage(crmCooperationManager.getCurrentPage(),crmCooperationManager.getPageSize());
        long total = this.crmCooperationManagerDao.count(crmCooperationManager);
        return (this.crmCooperationManagerDao.queryAllByPage(crmCooperationManager));
    }


    /**
     * 新增数据
     *
     * @param crmCooperationManager 实例对象
     * @return 实例对象
     */
    @Override
    public CrmCooperationManager insert(CrmCooperationManager crmCooperationManager) {
        //根据姓名和手机号、商户号查询是否已注册成为合作商
        CrmCooperationManagerVO vo = new CrmCooperationManagerVO();
        vo.setName(crmCooperationManager.getName());
        vo.setMobile(crmCooperationManager.getMobile());
        vo.setCoopType(crmCooperationManager.getCoopType());
        long count = crmCooperationManagerDao.count(vo);
        if(count > 0){
            throw new RuntimeException("该用户已是合作商");
        }else {
            //根据姓名和手机号码、商户号查询用户user_ID
            Long userId = crmUserDao.selectIdByNameMobileMchtId(vo.getName(),vo.getMobile(),vo.getMchtId());
            crmCooperationManager.setUserId(userId);
            crmCooperationManager.setCheckStatus("0"); //未审核状态
            crmCooperationManager.setCreateTime(DateUtils.timestamp());//当前时间戳
            crmCooperationManager.setCreateUser("");//当前操作用户
            this.crmCooperationManagerDao.insert(crmCooperationManager);
            return crmCooperationManager;
        }
    }

    /**
     * 修改数据
     *
     * @param crmCooperationManager 实例对象
     * @return 实例对象
     */
    @Override
    public CrmCooperationManager update(CrmCooperationManager crmCooperationManager) {

        crmCooperationManager.setUpdateTime(DateUtils.timestamp());
        crmCooperationManager.setUpdateUser("");
        this.crmCooperationManagerDao.update(crmCooperationManager);
        return this.queryById(crmCooperationManager.getUserId());
    }

    /**
     * 通过主键删除数据
     *
     * @param userId 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long userId) {
        return this.crmCooperationManagerDao.deleteById(userId) > 0;
    }

    /**
     * 数据审核
     * @param crmCooperationManager
     */
    @Override
    public void check(CrmCooperationManager crmCooperationManager) {
        crmCooperationManager.setCheckTime(DateUtils.timestamp());
        crmCooperationManager.setCheckUser("");
        this.crmCooperationManagerDao.update(crmCooperationManager);
    }


}
