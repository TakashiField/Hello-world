package com.chinatechstar.crm.config;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.config
 * @Author: zhengxiaolei
 * @CreateTime: 2024-06-11 11-13
 * @Description: TODO
 * @Version: 1.0
 */
public class BusinessException extends Exception{

    private static final long serialVersionUID = -395519744859162811L;

    public BusinessException() {
        super();
    }

    public BusinessException(Exception e) {
        super(e);
    }

    public BusinessException(String msg) {
        super(msg);
    }

    public BusinessException(String msg, Throwable ex) {
        super(msg, ex);
    }

}
