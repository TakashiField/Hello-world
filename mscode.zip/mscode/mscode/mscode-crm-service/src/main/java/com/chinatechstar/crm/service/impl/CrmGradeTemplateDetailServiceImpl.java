package com.chinatechstar.crm.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.chinatechstar.crm.constants.CrmConstants;
import com.chinatechstar.crm.dao.*;
import com.chinatechstar.crm.entity.*;
import com.chinatechstar.crm.service.CrmGradeTemplateDetailService;
import com.chinatechstar.crm.vo.CrmGradeTemplateDetailVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 等级模板明细表(CrmGradeTemplateDetail)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-02 10:58:36
 */
@Service("crmGradeTemplateDetailService")
public class CrmGradeTemplateDetailServiceImpl implements CrmGradeTemplateDetailService {

    private final Logger logger = LoggerFactory.getLogger(getClass());
    @Autowired
    private CrmGradeTemplateDetailDao crmGradeTemplateDetailDao;
    @Autowired
    private CrmGradeTemplateDao crmGradeTemplateDao;
    @Autowired
    private CrmGradeRuleDao crmGradeRuleDao;
    @Autowired
    private CrmRulesUpDao crmRulesUpDao;
    @Autowired
    private CrmRulesDownDao crmRulesDownDao;
    @Autowired
    private CrmRulesEquityDao crmRulesEquityDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public CrmGradeTemplateDetail queryById(Long id) {
        return this.crmGradeTemplateDetailDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param crmGradeTemplateDetail 筛选条件
     * @return 查询结果
     */
    @Override
    public List<CrmGradeTemplateDetail> queryByPage(CrmGradeTemplateDetail crmGradeTemplateDetail) {
        long total = this.crmGradeTemplateDetailDao.count(crmGradeTemplateDetail);
        List<CrmGradeTemplateDetail> details = this.crmGradeTemplateDetailDao.queryAllByPage(crmGradeTemplateDetail);
        for (int i = 0; i < details.size(); i++) {
            // 如果规则状态为开启状态，则去查询规则明细
            if (CrmConstants.STATUS_ON.equals(details.get(i).getRulesUpState())){
                String[] ids = details.get(i).getRulesUpId().split(",");
                List<CrmRulesUp> rulesUpList = crmRulesUpDao.queryByIds(ids);
                StringBuilder sb = new StringBuilder();
                if (rulesUpList.size() > 0){
                    int index = 1;
                    for (CrmRulesUp crmRulesUp : rulesUpList) {
                        sb.append(index).append("、").append(crmRulesUp.getRuleDesc()).append("。");
                        index++;
                    }
                }
                details.get(i).setRuleUpContent(sb.toString());
            }

            if (CrmConstants.STATUS_ON.equals(details.get(i).getRulesDownState())){
                String[] ids = details.get(i).getRulesDownId().split(",");
                List<CrmRulesDown> rulesDownList = crmRulesDownDao.queryByIds(ids);
                StringBuilder sb = new StringBuilder();
                if (rulesDownList.size() > 0){
                    int index = 1;
                    for (CrmRulesDown crmRulesDown : rulesDownList) {
                        sb.append(index).append("、").append(crmRulesDown.getRuleDesc()).append("。");
                        index++;
                    }
                }
                details.get(i).setRuleUpContent(sb.toString());
            }

//            if (CrmConstants.STATUS_ON.equals(details.get(i).getRulesBenefitStatus())){
//                String[] ids = details.get(i).getRulesBenefitId().split(",");
//                List<CrmRulesUp> rulesUpList = crmRulesUpDao.queryByIds(ids);
//                StringBuilder sb = new StringBuilder();
//                if (rulesUpList.size() > 0){
//                    int index = 1;
//                    for (CrmRulesUp crmRulesUp : rulesUpList) {
//                        sb.append(index).append("、").append(crmRulesUp.getRuleDesc()).append("。");
//                    }
//                }
//                details.get(i).setRuleUpContent(sb.toString());
//            }
        }
        return details;
    }


    /**
     * 新增数据
     *
     * @param crmGradeTemplateDetail 实例对象
     * @return 实例对象
     */
    @Override
    public CrmGradeTemplateDetail insert(CrmGradeTemplateDetail crmGradeTemplateDetail) {
        this.crmGradeTemplateDetailDao.insert(crmGradeTemplateDetail);
        return crmGradeTemplateDetail;
    }

    /**
     * 修改数据
     *
     * @param crmGradeTemplateDetail 实例对象
     * @return 实例对象
     */
    @Override
    public CrmGradeTemplateDetail update(CrmGradeTemplateDetail crmGradeTemplateDetail) {
        List<CrmRulesUp> rulesUpList = crmGradeTemplateDetail.getRulesUpList();
        List<CrmRulesDown> rulesDownList = crmGradeTemplateDetail.getRulesDownList();
        List<CrmRulesEquity> rulesEquityList = crmGradeTemplateDetail.getRulesEquityList();
        // 升级规则
        if(rulesUpList != null) {
            //将规则列表中规则Id，以，分隔符拼接在一起
            StringBuilder ruleUpIds = new StringBuilder();
            for (CrmRulesUp crmRulesUp : rulesUpList) {
                ruleUpIds.append(crmRulesUp.getRuleId()).append(",");
            }
            crmGradeTemplateDetail.setRulesUpId(ruleUpIds.toString());
        }
        // 降级规则
        if(rulesDownList != null) {
            //将规则列表中规则Id，以，分隔符拼接在一起
            StringBuilder ruleDownIds = new StringBuilder();
            for (CrmRulesDown crmRulesDown : rulesDownList) {
                ruleDownIds.append(crmRulesDown.getRuleId()).append(",");
            }
            crmGradeTemplateDetail.setRulesDownId(ruleDownIds.toString());
        }
        // 升级规则
        if(rulesEquityList != null) {
            //将规则列表中规则Id，以，分隔符拼接在一起
            StringBuilder ruleIds = new StringBuilder();
            for (CrmRulesEquity crmRulesEquity : rulesEquityList) {
                ruleIds.append(crmRulesEquity.getRuleId()).append(",");
            }
            crmGradeTemplateDetail.setRulesBenefitId(ruleIds.toString());
        }
        this.crmGradeTemplateDetailDao.update(crmGradeTemplateDetail);
        return this.queryById(crmGradeTemplateDetail.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return this.crmGradeTemplateDetailDao.deleteById(id) > 0;
    }

    /**
     * @param templateType
     * @return
     */
    @Override
    public List<CrmGradeTemplateDetail> queryDetailByType(CrmGradeTemplateDetailVO templateType) {

        //查询当前生效的等级模板ID
        Long templateId = this.crmGradeTemplateDao.queryByType(templateType);
        //根据templateID查询等级模板明细
        CrmGradeTemplateDetail select = new CrmGradeTemplateDetail();
        select.setTemplateId(templateId);
        List<CrmGradeTemplateDetail> list = this.crmGradeTemplateDetailDao.queryAllByPage(select);
        //
        return list;
    }

    /**
     * @param crmGradeRule
     */
    @Override
    public void turnOn(CrmGradeRule crmGradeRule) {
        long count = this.crmGradeRuleDao.count(crmGradeRule);
        if(count == 0){
            this.crmGradeRuleDao.insert(crmGradeRule);
        } else{
            this.crmGradeRuleDao.update(crmGradeRule);
        }
        updateCrmGradeTemplateDetail(crmGradeRule);
    }

    /**
     * @param crmGradeRule
     */
    @Override
    public void turnOff(CrmGradeRule crmGradeRule) {
        this.crmGradeRuleDao.update(crmGradeRule);
        updateCrmGradeTemplateDetail(crmGradeRule);
    }

    /**
     * @param crmGradeRule
     */
    @Override
    public void selectOn(CrmGradeRule crmGradeRule) {
        //支持多选
        String ruleId = String.valueOf(crmGradeRule.getRuleId());
        String[] ids = ruleId.split(",");
        List<CrmGradeRule> list = new ArrayList<>();
        for (String id : ids) {
            CrmGradeRule rule = new CrmGradeRule();
            rule.setGradeId(crmGradeRule.getGradeId());
            rule.setRuleId(Long.getLong(id));
            rule.setStatus(CrmConstants.STATUS_ON);
            list.add(rule);

        }
        this.crmGradeRuleDao.insertOrUpdateBatch(list);

        updateCrmGradeTemplateDetail(crmGradeRule);
    }

    private void updateCrmGradeTemplateDetail(CrmGradeRule crmGradeRule) {
        //更新等级的规则信息
        CrmGradeRule select = new CrmGradeRule();
        select.setGradeId(crmGradeRule.getGradeId());
        select.setStatus(CrmConstants.STATUS_ON);
        List<CrmGradeRule> ruleList = this.crmGradeRuleDao.queryAllByPage(select);
        StringBuilder sb = new StringBuilder();
        int bonus = 0;
        int i = 1;
        for (CrmGradeRule gradeRule : ruleList) {
            CrmRulesUp rulesUp = this.crmRulesUpDao.queryById(gradeRule.getRuleId());
            logger.info(JSONObject.toJSONString(rulesUp));
            sb.append(i+"、"+rulesUp.getRuleDesc()+"。");
            //bonus += Integer.getInteger(rulesUp.getRuleBonus() == null ? "0" : rulesUp.getRuleBonus());
            i++;
        }

        CrmGradeTemplateDetail templateDetail = new CrmGradeTemplateDetail();
        templateDetail.setId(crmGradeRule.getGradeId());
        templateDetail.setRulesUpState(CrmConstants.STATUS_ON);
        templateDetail.setRulesUpId(sb.toString());
        templateDetail.setBonus(String.valueOf(bonus));
        this.crmGradeTemplateDetailDao.update(templateDetail);
    }
}
