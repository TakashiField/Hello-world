package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmUserJxs;
import com.chinatechstar.crm.service.CrmUserJxsService;
import com.chinatechstar.crm.vo.CrmUserJxsVO;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 经销商列表(CrmUserJxs)表控制层
 *
 * @author zhengxl
 * @since 2024-07-12 10:02:01
 */
@RestController
@RequestMapping("crmUserJxs")
public class CrmUserJxsController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmUserJxsService crmUserJxsService;

    /**
     * 分页查询
     *
     * @param crmUserJxs 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage(@Validated CrmUserJxsVO crmUserJxs) {
        List<CrmUserJxs> userJxs = this.crmUserJxsService.queryByPage(crmUserJxs);
        crmUserJxs.setCrmList(userJxs);
        return ResultBuilder.buildListSuccess(crmUserJxs);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {
        CrmUserJxs crmUserJxs = this.crmUserJxsService.queryById(id);
        return ResultBuilder.buildListSuccess(crmUserJxs);
    }

    /**
     * 新增数据
     *
     * @param crmUserJxs 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody CrmUserJxs crmUserJxs) {
        this.crmUserJxsService.insert(crmUserJxs);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmUserJxs 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody CrmUserJxs crmUserJxs) {
        this.crmUserJxsService.update(crmUserJxs);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Long id) {
        this.crmUserJxsService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

}

