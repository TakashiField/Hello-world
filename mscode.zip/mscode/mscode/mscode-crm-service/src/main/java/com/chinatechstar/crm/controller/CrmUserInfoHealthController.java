package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmUserInfoHealth;
import com.chinatechstar.crm.service.CrmUserInfoHealthService;
import com.chinatechstar.crm.vo.CrmUserInfoHealthVO;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员健康信息表(CrmUserInfoHealth)表控制层
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:03
 */
@RestController
@RequestMapping("crmUserInfoHealth")
public class CrmUserInfoHealthController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmUserInfoHealthService crmUserInfoHealthService;

    /**
     * 分页查询
     *
     * @param crmUserInfoHealth 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage(@Validated CrmUserInfoHealthVO crmUserInfoHealth) {
        Map<String, Object> data = this.crmUserInfoHealthService.queryByPage(crmUserInfoHealth);
        return ResultBuilder.buildListSuccess(data);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {
        return ResultBuilder.buildListSuccess(this.crmUserInfoHealthService.queryById(id));
    }

    /**
     * 新增数据
     *
     * @param crmUserInfoHealth 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody CrmUserInfoHealth crmUserInfoHealth) {
        this.crmUserInfoHealthService.insert(crmUserInfoHealth);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmUserInfoHealth 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody CrmUserInfoHealth crmUserInfoHealth) {
        this.crmUserInfoHealthService.update(crmUserInfoHealth);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Long id) {
        this.crmUserInfoHealthService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

}

