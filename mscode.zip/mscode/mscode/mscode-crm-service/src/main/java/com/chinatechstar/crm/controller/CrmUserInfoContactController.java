package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmUserInfoContact;
import com.chinatechstar.crm.service.CrmUserInfoContactService;
import com.chinatechstar.crm.vo.CrmUserInfoContactVO;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员联系人信息表(CrmUserInfoContact)表控制层
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:02
 */
@RestController
@RequestMapping("crmUserInfoContact")
public class CrmUserInfoContactController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmUserInfoContactService crmUserInfoContactService;

    /**
     * 分页查询
     *
     * @param crmUserInfoContact 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage(@Validated CrmUserInfoContactVO crmUserInfoContact) {
        Map<String,Object> data = this.crmUserInfoContactService.queryByPage(crmUserInfoContact);
        return ResultBuilder.buildListSuccess(data);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {
        return ResultBuilder.buildListSuccess(this.crmUserInfoContactService.queryById(id));
    }

    /**
     * 新增数据
     *
     * @param crmUserInfoContact 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody CrmUserInfoContact crmUserInfoContact) {
        this.crmUserInfoContactService.insert(crmUserInfoContact);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmUserInfoContact 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody CrmUserInfoContact crmUserInfoContact) {
        this.crmUserInfoContactService.update(crmUserInfoContact);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Long id) {
        this.crmUserInfoContactService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

}

