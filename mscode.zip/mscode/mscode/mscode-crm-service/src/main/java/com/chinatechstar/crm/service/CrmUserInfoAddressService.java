package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmUserInfoAddress;
import com.chinatechstar.crm.vo.CrmUserInfoAddressVO;

import java.util.List;
import java.util.Map;

/**
 * 会员地址信息表(CrmUserInfoAddress)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:02
 */
public interface CrmUserInfoAddressService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmUserInfoAddress queryById(Long id);

    /**
     * 分页查询
     *
     * @param crmUserInfoAddress 筛选条件
     * @return 查询结果
     */
    Map<String, Object> queryByPage(CrmUserInfoAddressVO crmUserInfoAddress);

    /**
     * 新增数据
     *
     * @param crmUserInfoAddress 实例对象
     * @return 实例对象
     */
    CrmUserInfoAddress insert(CrmUserInfoAddress crmUserInfoAddress);

    /**
     * 修改数据
     *
     * @param crmUserInfoAddress 实例对象
     * @return 实例对象
     */
    CrmUserInfoAddress update(CrmUserInfoAddress crmUserInfoAddress);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Long id);

}
