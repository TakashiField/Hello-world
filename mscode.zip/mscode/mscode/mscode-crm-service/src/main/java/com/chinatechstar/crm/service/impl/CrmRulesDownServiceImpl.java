package com.chinatechstar.crm.service.impl;


import com.chinatechstar.crm.dao.CrmRulesDownDao;
import com.chinatechstar.crm.entity.CrmRulesDown;
import com.chinatechstar.crm.service.CrmRulesDownService;
import org.springframework.stereotype.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员升级规则(CrmRulesDown)表服务实现类
 *
 * @author zhengxl
 * @since 2024-07-03 12:43:15
 */
@Service("crmRulesDownService")
public class CrmRulesDownServiceImpl implements CrmRulesDownService {
    @Autowired
    private CrmRulesDownDao crmRulesDownDao;

    /**
     * 通过ID查询单条数据
     *
     * @param ruleId 主键
     * @return 实例对象
     */
    @Override
    public CrmRulesDown queryById(Long ruleId) {
        return this.crmRulesDownDao.queryById(ruleId);
    }

    /**
     * 分页查询
     *
     * @param crmRulesDown 筛选条件
     * @return 查询结果
     */
    @Override
    public List<CrmRulesDown> queryByPage(CrmRulesDown crmRulesDown) {
        long total = this.crmRulesDownDao.count(crmRulesDown);
        return (this.crmRulesDownDao.queryAllByPage(crmRulesDown));
    }


    /**
     * 新增数据
     *
     * @param crmRulesDown 实例对象
     * @return 实例对象
     */
    @Override
    public CrmRulesDown insert(CrmRulesDown crmRulesDown) {
        this.crmRulesDownDao.insert(crmRulesDown);
        return crmRulesDown;
    }

    /**
     * 修改数据
     *
     * @param crmRulesDown 实例对象
     * @return 实例对象
     */
    @Override
    public CrmRulesDown update(CrmRulesDown crmRulesDown) {
        this.crmRulesDownDao.update(crmRulesDown);
        return this.queryById(crmRulesDown.getRuleId());
    }

    /**
     * 通过主键删除数据
     *
     * @param ruleId 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long ruleId) {
        return this.crmRulesDownDao.deleteById(ruleId) > 0;
    }
}
