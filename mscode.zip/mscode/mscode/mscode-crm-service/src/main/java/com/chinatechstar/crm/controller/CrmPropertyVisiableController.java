package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmPropertyVisiable;
import com.chinatechstar.crm.service.CrmPropertyVisiableService;
import com.chinatechstar.crm.vo.CrmPropertyVisiableVO;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 属性可见控制表(CrmPropertyVisiable)表控制层
 *
 * @author zhengxl
 * @since 2024-06-28 10:00:31
 */
@RestController
@RequestMapping("crmPropertyVisiable")
public class CrmPropertyVisiableController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmPropertyVisiableService crmPropertyVisiableService;

    /**
     * 分页查询
     *
     * @param vo 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage( @Validated CrmPropertyVisiableVO vo) {
        Map<String,Object> data = this.crmPropertyVisiableService.queryByPage(vo);
        return ResultBuilder.buildListSuccess(data);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {
        CrmPropertyVisiable propertyVisiable = this.crmPropertyVisiableService.queryById(id);
        return ResultBuilder.buildListSuccess(propertyVisiable);
    }

    /**
     * 新增数据
     *
     * @param crmPropertyVisiable 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody @Validated CrmPropertyVisiable crmPropertyVisiable) {
        this.crmPropertyVisiableService.insert(crmPropertyVisiable);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param id 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody CrmPropertyVisiable crmPropertyVisiable) {
        Long[] ids = crmPropertyVisiable.getIds();
        this.crmPropertyVisiableService.update(ids);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Long id) {
        this.crmPropertyVisiableService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

}

