package com.chinatechstar.crm.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.fastjson.JSONObject;
import com.chinatechstar.component.commons.result.PaginationBuilder;
import com.chinatechstar.component.commons.utils.StringUtils;
import com.chinatechstar.component.commons.utils.UUIDUtil;
import com.chinatechstar.crm.dao.CrmPropertyCustomedValueDao;
import com.chinatechstar.crm.dao.CrmRelationSymbolDao;
import com.chinatechstar.crm.entity.*;
import com.chinatechstar.crm.dao.CrmUserDao;
import com.chinatechstar.crm.service.CrmUserService;
import com.chinatechstar.crm.util.DateUtils;
import com.chinatechstar.crm.vo.CrmSymbolInfo;
import com.chinatechstar.crm.vo.CrmUserVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.ConvertUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 会员基础信息表(CrmUser)表服务实现类
 *
 * @author zhengxl
 * @since 2024-06-28 11:31:38
 */
@Service("crmUserService")
@Slf4j
public class CrmUserServiceImpl implements CrmUserService {
    @Autowired
    private CrmUserDao crmUserDao;
    @Autowired
    private CrmRelationSymbolDao crmRelationSymbolDao;
    @Autowired
    private CrmPropertyCustomedValueDao crmPropertyCustomedValueDao;

    /**
     * 通过ID查询单条数据
     *
     * @param userId 主键
     * @return 实例对象
     */
    @Override
    public CrmUser queryById(Long userId) {
        CrmUser crmUser = this.crmUserDao.queryById(userId);
        List<CrmPropertyCustomedValue> propValue = this.crmPropertyCustomedValueDao.queryById(crmUser.getUserId());
        crmUser.setPropValue(propValue);
        return crmUser;
    }

    /**
     * 分页查询
     *
     * @param vo 筛选条件
     * @return 查询结果
     */
    @Override
    public Map<String, Object> queryByPage(CrmUserVO vo) {

        List<CrmSymbolInfo> list = null;
        log.info("----会员名称：" + vo.getName() + "----");
        log.info("----证件类型：" + vo.getIdType() + "----");
        log.info("----证件号码：" + vo.getIdNo() + "----");
        log.info("----手机号码：" + vo.getMobile() + "----");
        log.info("----性别   ：" + vo.getSex() + "----");
        log.info("----认证状态：" + vo.getIdtStatus() + "----");
        PageHelper.startPage(vo.getCurrentPage(),vo.getPageSize());
        //long total = this.crmUserDao.count(vo);
        List<CrmUser> userList = this.crmUserDao.queryAllByPage(vo);
        for (CrmUser crmUser : userList) {
            List<CrmPropertyCustomedValue> propValue = this.crmPropertyCustomedValueDao.queryById(crmUser.getUserId());
            crmUser.setPropValue(propValue);
            if(StringUtils.isNotBlank(crmUser.getSymbol())){
                //获取标签信息
                log.info("标签信息：{}",crmUser.getSymbol());
                String[] ids = crmUser.getSymbol().split(",");
                Long[] id = (Long[]) ConvertUtils.convert(ids,Long.class);
                List<CrmRelationSymbol> crmRelationSymbol = this.crmRelationSymbolDao.queryByIds(id);
                list = new ArrayList<>();
                for (CrmRelationSymbol symbol : crmRelationSymbol) {
                    CrmSymbolInfo symbolInfo = new CrmSymbolInfo();
                    symbolInfo.setSymbolColor(symbol.getSymbolColor());
                    symbolInfo.setSymbolName(symbol.getSymbolName());
                    list.add(symbolInfo);
                }
                //String collect = CollUtil.join(list,",");
                crmUser.setSymbol(JSONObject.toJSONString(list));
                log.info("标签信息：{}",crmUser.getSymbol());
            }
        }
        PageInfo<CrmUser> pageInfo = new PageInfo<>(userList);
        vo.setTotalSize( pageInfo.getTotal() );
        vo.setTotalPage( pageInfo.getPages() );
        return PaginationBuilder.buildResultObject(userList, pageInfo.getTotal(), vo.getCurrentPage(), vo.getPageSize());
    }


    /**
     * 新增数据
     *
     * @param crmUser 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUser insert(CrmUser crmUser) {

        //判断手机号是否已注册
        CrmUser user = new CrmUser();
        user.setMobile(crmUser.getMobile());
        long count = this.crmUserDao.count(user);
        if(count > 0) {
            log.info("该手机号码已存在");
//            Long id = this.crmUserDao.selectIdByNameMobileMchtId(null, crmUser.getMobile(), null);
//            crmUser.setUserId(id);
            throw new RuntimeException("该手机号码已存在,请确认该用户未注册");
        } else {
            crmUser.setUserId(UUIDUtil.snowflakeId());
            log.info("ID-->" + crmUser.getUserId());
            StringBuilder sb = new StringBuilder();
            /**获取自定义属性*/
            List<CrmPropertyCustomedValue> propValue = crmUser.getPropValue();
            if (propValue != null && propValue.size() > 0) {
                int index = 1;
                for (CrmPropertyCustomedValue crmPropertyCustomedValue : propValue) {
                    crmPropertyCustomedValue.setUserId(crmUser.getUserId());
                    if (index == 1) {
                        sb.append(crmPropertyCustomedValue.getPropId());
                    } else {
                        sb.append("," + crmPropertyCustomedValue.getPropId());
                    }
                    index++;
                }
                //插入自定义属性字段值
                this.crmPropertyCustomedValueDao.insertBatch(propValue);
            }

            /**将自定义属性ID 组合存放在crm_user表 properties字段*/
            crmUser.setProperties(sb.toString());
            /**其他属性*/
            crmUser.setCreateTime(DateUtils.timestamp());
            /**插入用户数据*/
            this.crmUserDao.insert(crmUser);
        }

        return crmUser;
    }

    /**
     * 修改数据
     *
     * @param crmUser 实例对象
     * @return 实例对象
     */
    @Override
    public CrmUser update(CrmUser crmUser) {
        /**获取自定义属性*/
        StringBuilder sb = new StringBuilder();
        List<CrmPropertyCustomedValue> propValue = crmUser.getPropValue();
        if (propValue != null && propValue.size() > 0) {
            int index = 1;
            for (CrmPropertyCustomedValue crmPropertyCustomedValue : propValue) {
                crmPropertyCustomedValue.setUserId(crmUser.getUserId());
                if (index == 1) {
                    sb.append(crmPropertyCustomedValue.getPropId());
                } else {
                    sb.append("," + crmPropertyCustomedValue.getPropId());
                }
                index++;
            }
            // 更新或新增自定义属性值
            crmPropertyCustomedValueDao.insertOrUpdateBatch(propValue);
            /**将自定义属性ID 组合存放在crm_user表 properties字段*/
            crmUser.setProperties(sb.toString());
        }
        this.crmUserDao.update(crmUser);
        return this.queryById(crmUser.getUserId());
    }

    /**
     * 通过主键删除数据
     *
     * @param userId 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long userId) {
        return this.crmUserDao.deleteById(userId) > 0;
    }

    /**
     *  判断手机号是否已存在
     * @param crmUser
     * @return
     */
    @Override
    public Boolean checkExists(CrmUser crmUser) {
        if(StringUtils.isNotBlank(crmUser.getMobile())){
            long count = this.crmUserDao.count(crmUser);
            return count <= 0;
        }
        return false;
    }

    /**
     * 会员信息同步
     * @param crmUser
     * @return
     */
    @Override
    public CrmUserVO sync(CrmUserVO crmUser) {
        //判断手机号是否已注册
        CrmUser user = new CrmUser();
        user.setMobile(crmUser.getMobile());
        user.setMchtId(crmUser.getMchtId());
        long count = this.crmUserDao.count(user);
        if(count > 0) {
            log.info("商户下该手机号码已存在");
            Long id = this.crmUserDao.selectIdByNameMobileMchtId(null, crmUser.getMobile(), crmUser.getMchtId());
            crmUser.setUserId(id);
            BeanUtil.copyProperties(crmUser,user);
            this.crmUserDao.update(user);
        }else{
            //新增一条会员数据
            BeanUtil.copyProperties(crmUser,user);
            user.setUserId(UUIDUtil.snowflakeId());
            user.setCreateTime(DateUtils.timestamp());
            crmUserDao.insert(user);
            if (null != crmUser.getShareMobile() && " " != crmUser.getShareMobile()){
                //关联的数据存表

            }
            //新增一条会员等级数据
            CrmUserVip crmUserVip = new CrmUserVip();
            crmUserVip.setUserId(user.getUserId());
            crmUserVip.setMchtId(user.getMchtId());
            crmUserVip.setGrade("0");
            crmUserVip.setName(user.getName());
            //crmUserVip.set
            crmUser.setUserId(user.getUserId());



        }
        return crmUser;
    }
}
