package com.chinatechstar.crm.dao;

import com.chinatechstar.crm.entity.CrmUserWealthInfoDetail;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 会员资产明细表(CrmUserWealthInfoDetail)表数据库访问层
 *
 * @author zhengxl
 * @since 2024-07-05 10:02:02
 */
public interface CrmUserWealthInfoDetailDao {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmUserWealthInfoDetail queryById(Integer id);

    /**
     * 查询指定行数据
     *
     * @param crmUserWealthInfoDetail 查询条件
     * @return 对象列表
     */
    List<CrmUserWealthInfoDetail> queryAllByPage(CrmUserWealthInfoDetail crmUserWealthInfoDetail);

    /**
     * 统计总行数
     *
     * @param crmUserWealthInfoDetail 查询条件
     * @return 总行数
     */
    long count(CrmUserWealthInfoDetail crmUserWealthInfoDetail);

    /**
     * 新增数据
     *
     * @param crmUserWealthInfoDetail 实例对象
     * @return 影响行数
     */
    int insert(CrmUserWealthInfoDetail crmUserWealthInfoDetail);

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmUserWealthInfoDetail> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<CrmUserWealthInfoDetail> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmUserWealthInfoDetail> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<CrmUserWealthInfoDetail> entities);

    /**
     * 修改数据
     *
     * @param crmUserWealthInfoDetail 实例对象
     * @return 影响行数
     */
    int update(CrmUserWealthInfoDetail crmUserWealthInfoDetail);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 影响行数
     */
    int deleteById(Integer id);

}

