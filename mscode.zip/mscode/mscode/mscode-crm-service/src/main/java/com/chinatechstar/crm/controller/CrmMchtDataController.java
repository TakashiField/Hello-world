package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmMchtData;
import com.chinatechstar.crm.service.CrmMchtDataService;
import com.chinatechstar.crm.vo.CrmMchtDataVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * 会员资料表(CrmMchtData)表控制层
 *
 * @author makejava
 * @since 2024-06-19 16:57:40
 */
@RestController
@RequestMapping("crmMchtData")
public class CrmMchtDataController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmMchtDataService crmMchtDataService;



    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {
        CrmMchtData result = crmMchtDataService.queryById(id);
        return ResultBuilder.buildListSuccess(result);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param vo 主键
     * @return 单条数据
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage(@Validated CrmMchtDataVO vo) {
        List<CrmMchtData> result = crmMchtDataService.queryByPage(vo);
        vo.setCrmList(result);
        return ResultBuilder.buildListSuccess(vo);
    }

    /**
     * 新增数据
     *
     * @param crmMchtData 实体
     * @return 新增结果
     */
    @PostMapping(path = "/add")
    public ActionResult add(@RequestBody @Validated CrmMchtData crmMchtData) {
        crmMchtDataService.insert(crmMchtData);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmMchtData 实体
     * @return 编辑结果
     */
    @PostMapping(path = "/edit")
    public ActionResult edit(@RequestBody @Validated CrmMchtData crmMchtData) {
        crmMchtDataService.update(crmMchtData);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */

    @PostMapping(path="/delete")
    public ActionResult deleteById(Long id) {
        crmMchtDataService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

    @RequestMapping("/test")
    public String test(Long id){
        System.out.println("test");
        return "test";
    }
}

