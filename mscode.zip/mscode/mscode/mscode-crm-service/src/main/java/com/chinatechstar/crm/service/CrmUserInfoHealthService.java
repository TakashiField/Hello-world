package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmUserInfoHealth;
import com.chinatechstar.crm.vo.CrmUserInfoHealthVO;

import java.util.List;
import java.util.Map;

/**
 * 会员健康信息表(CrmUserInfoHealth)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:03
 */
public interface CrmUserInfoHealthService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmUserInfoHealth queryById(Long id);

    /**
     * 分页查询
     *
     * @param crmUserInfoHealth 筛选条件
     * @return 查询结果
     */
    Map<String, Object> queryByPage(CrmUserInfoHealthVO crmUserInfoHealth);

    /**
     * 新增数据
     *
     * @param crmUserInfoHealth 实例对象
     * @return 实例对象
     */
    CrmUserInfoHealth insert(CrmUserInfoHealth crmUserInfoHealth);

    /**
     * 修改数据
     *
     * @param crmUserInfoHealth 实例对象
     * @return 实例对象
     */
    CrmUserInfoHealth update(CrmUserInfoHealth crmUserInfoHealth);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Long id);

}
