package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmCooperationManager;
import com.chinatechstar.crm.vo.CrmCooperationManagerVO;

import java.util.List;

/**
 * 合作商管理表(CrmCooperationManager)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-01 10:20:46
 */
public interface CrmCooperationManagerService {

    /**
     * 通过ID查询单条数据
     *
     * @param userId 主键
     * @return 实例对象
     */
    CrmCooperationManager queryById(Long userId);

    /**
     * 分页查询
     *
     * @param crmCooperationManager 筛选条件
     * @return 查询结果
     */
    List<CrmCooperationManager> queryByPage(CrmCooperationManagerVO crmCooperationManager);

    /**
     * 新增数据
     *
     * @param crmCooperationManager 实例对象
     * @return 实例对象
     */
    CrmCooperationManager insert(CrmCooperationManager crmCooperationManager);

    /**
     * 修改数据
     *
     * @param crmCooperationManager 实例对象
     * @return 实例对象
     */
    CrmCooperationManager update(CrmCooperationManager crmCooperationManager);

    /**
     * 通过主键删除数据
     *
     * @param userId 主键
     * @return 是否成功
     */
    boolean deleteById(Long userId);

    void check(CrmCooperationManager crmCooperationManager);
}
