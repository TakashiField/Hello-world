package com.chinatechstar.crm.schedule.runnable;

import com.chinatechstar.crm.entity.CrmTaskNotice;
import com.chinatechstar.crm.entity.CrmUser;
import com.chinatechstar.crm.schedule.CrmNoticeService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.schedule.runnable
 * @Author: zhengxiaolei
 * @CreateTime: 2024-07-15 16-52
 * @Description: TODO
 * @Version: 1.0
 */
@Slf4j
public class BirthdayRunnable implements Runnable{

    @Autowired
    private CrmNoticeService crmNoticeService;

    private List<CrmUser> crmUsersList;

    private CrmTaskNotice crmTaskNotice;

    public BirthdayRunnable(List<CrmUser> crmUsersList, CrmTaskNotice crmTaskNotice) {
        this.crmUsersList = crmUsersList;
        this.crmTaskNotice = crmTaskNotice;
    }

    /**
     * When an object implementing interface <code>Runnable</code> is used
     * to create a thread, starting the thread causes the object's
     * <code>run</code> method to be called in that separately executing
     * thread.
     * <p>
     * The general contract of the method <code>run</code> is that it may
     * take any action whatsoever.
     *
     * @see Thread#run()
     */
    @Override
    public void run() {

        log.info("当前线程[{}],线程名[{}]",Thread.currentThread().getId(),Thread.currentThread().getName());


        //获取通配符
        String character = crmTaskNotice.getCharacters();
        //获取短信内容
        String sendContent = crmTaskNotice.getSendContent();

        //调用短信网关发送短信
        for (CrmUser crmUser : crmUsersList) {

            String userName = crmUser.getUserName();
            String mobile = crmUser.getMobile();
            String content = sendContent.replace(character, userName);
            crmNoticeService.sendSms(mobile,content);
        }
    }
}
