package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmInvestment;
import com.chinatechstar.crm.service.CrmInvestmentService;
import com.chinatechstar.crm.vo.CrmInvestmentVO;
import com.chinatechstar.crm.vo.CrmMchtDataVO;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 招商加盟表(CrmInvestment)表控制层
 *
 * @author zhengxl
 * @since 2024-07-16 09:50:29
 */
@RestController
@RequestMapping("crmInvestment")
public class CrmInvestmentController {
    /**
     * 服务对象
     */
    @Autowired
    private CrmInvestmentService crmInvestmentService;

    /**
     * 分页查询
     *
     * @param crmInvestment 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage(@RequestBody @Validated CrmInvestmentVO crmInvestment) {
        List<CrmInvestment> crmInvestments = this.crmInvestmentService.queryByPage(crmInvestment);
        crmInvestment.setCrmList(crmInvestments);
        return ResultBuilder.buildListSuccess(crmInvestment);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(@RequestParam(name = "id") Long id) {
        CrmInvestment crmInvestment = this.crmInvestmentService.queryById(id);
        return ResultBuilder.buildListSuccess(crmInvestment);
    }

    /**
     * 新增数据
     *
     * @param crmInvestment 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody @Validated CrmInvestment crmInvestment) {
        this.crmInvestmentService.insert(crmInvestment);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmInvestment 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody @Validated CrmInvestment crmInvestment) {
        this.crmInvestmentService.update(crmInvestment);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(Long id) {
        this.crmInvestmentService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

}

