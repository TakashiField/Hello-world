package com.chinatechstar.crm.service;

public interface CrmService {
}
