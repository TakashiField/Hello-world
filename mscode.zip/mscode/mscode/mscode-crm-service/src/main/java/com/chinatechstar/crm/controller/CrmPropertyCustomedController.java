package com.chinatechstar.crm.controller;

import com.chinatechstar.component.commons.result.ActionResult;
import com.chinatechstar.component.commons.result.ListResult;
import com.chinatechstar.component.commons.result.ResultBuilder;
import com.chinatechstar.crm.entity.CrmPropertyCustomed;
import com.chinatechstar.crm.service.CrmPropertyCustomedService;
import com.chinatechstar.crm.vo.CrmPropertyCustomedVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;


/**
 * 自定义标签表(CrmPropertyCustomed)表控制层
 *
 * @author makejava
 * @since 2024-06-24 17:20:21
 */
@RestController
@RequestMapping("crmPropertyCustomed")
@Slf4j
public class CrmPropertyCustomedController {
    /**
     * 服务对象
     */
    @Resource
    private CrmPropertyCustomedService crmPropertyCustomedService;

    /**
     * 分页查询
     *
     * @param vo 筛选条件
     * @return 查询结果
     */
    @GetMapping("/queryByPage")
    public ListResult<Object> queryByPage( @Validated CrmPropertyCustomedVO vo) {

        Map<String,Object> data = crmPropertyCustomedService.queryByPage(vo);
        return ResultBuilder.buildListSuccess(data);
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/queryById")
    public ListResult<Object> queryById(Long id) {
        CrmPropertyCustomed crmPropertyCustomed = this.crmPropertyCustomedService.queryById(id);
        return ResultBuilder.buildListSuccess(crmPropertyCustomed);
    }

    /**
     * 新增数据
     *
     * @param crmPropertyCustomed 实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ActionResult add(@RequestBody @Validated CrmPropertyCustomed crmPropertyCustomed) {
        this.crmPropertyCustomedService.insert(crmPropertyCustomed);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 编辑数据
     *
     * @param crmPropertyCustomed 实体
     * @return 编辑结果
     */
    @PostMapping("/update")
    public ActionResult edit(@RequestBody @Validated CrmPropertyCustomed crmPropertyCustomed) {
        this.crmPropertyCustomedService.update(crmPropertyCustomed);
        return ResultBuilder.buildActionSuccess();
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除是否成功
     */
    @PostMapping("/delete")
    public ActionResult deleteById(@RequestParam(name = "id", required = true) Long[] id) {
        this.crmPropertyCustomedService.deleteById(id);
        return ResultBuilder.buildActionSuccess();
    }

}

