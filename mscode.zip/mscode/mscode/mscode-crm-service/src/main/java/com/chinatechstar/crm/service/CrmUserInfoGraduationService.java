package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmUserInfoGraduation;
import com.chinatechstar.crm.vo.CrmUserInfoGraduationVO;

import java.util.List;
import java.util.Map;

/**
 * 会员学习信息表(CrmUserInfoGraduation)表服务接口
 *
 * @author zhengxl
 * @since 2024-07-26 16:33:03
 */
public interface CrmUserInfoGraduationService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmUserInfoGraduation queryById(Long id);

    /**
     * 分页查询
     *
     * @param crmUserInfoGraduation 筛选条件
     * @return 查询结果
     */
    Map<String, Object> queryByPage(CrmUserInfoGraduationVO crmUserInfoGraduation);

    /**
     * 新增数据
     *
     * @param crmUserInfoGraduation 实例对象
     * @return 实例对象
     */
    CrmUserInfoGraduation insert(CrmUserInfoGraduation crmUserInfoGraduation);

    /**
     * 修改数据
     *
     * @param crmUserInfoGraduation 实例对象
     * @return 实例对象
     */
    CrmUserInfoGraduation update(CrmUserInfoGraduation crmUserInfoGraduation);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Long id);

}
