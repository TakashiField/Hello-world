package com.chinatechstar.crm.service;

import com.chinatechstar.crm.entity.CrmRelationType;
import com.chinatechstar.crm.vo.CrmRelationTypeVO;

import java.util.List;

/**
 * 会员关系类别表(CrmRelationType)表服务接口
 *
 * @author makejava
 * @since 2024-06-26 09:59:20
 */
public interface CrmRelationTypeService extends CrmService{

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    CrmRelationType query(Long id);

    /*
     * 分页查询
     *
     * @param crmRelationType 筛选条件
     * @param pageRequest      分页对象
     * @return 查询结果
     */
    List<CrmRelationType> queryByPage(CrmRelationTypeVO crmRelationType);


    /**
     * 新增数据
     *
     * @param crmRelationType 实例对象
     * @return 实例对象
     */
    CrmRelationType insert(CrmRelationType crmRelationType);

    /**
     * 修改数据
     *
     * @param crmRelationType 实例对象
     * @return 实例对象
     */
    void update(CrmRelationType crmRelationType);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Long id);

}
