package com.chinatechstar.crm.task.sync;


import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.read.builder.ExcelReaderBuilder;
import com.chinatechstar.component.commons.utils.FileUtils;
import com.chinatechstar.component.commons.utils.UUIDUtil;
import com.chinatechstar.crm.dao.CrmUserDao;
import com.chinatechstar.crm.entity.CrmUser;
import com.chinatechstar.crm.util.FtpUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.annotation.Schedules;
import org.springframework.stereotype.Component;

import java.io.*;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * @Project: mscode
 * @Package: com.chinatechstar.crm.task.sync
 * @Author: zhengxiaolei
 * @CreateTime: 2024-11-22 09-00
 * @Description: TODO
 * @Version: 1.0
 */
@Component
public class CrmUserSyncTask {

    @Autowired
    private CrmUserDao crmUserDao;

    @Scheduled(cron = "0 */5 * * * ?")
    void userSync() throws IOException {
        String filename = "meicun.txt";
        String rmtFile = "/file/download/" + filename;
        String locFile = "D\\download\\";
        // 获取文件        FtpUtils.connect("127.0.0.1",21,"test","test");
//        FtpUtils.downloadFile(rmtFile + filename, locFile);
//        if (!FileUtil.exist(locFile)) {
//            throw new RuntimeException("文件下载失败");
//        }
        // 处理文件
        ExcelReaderBuilder builder = EasyExcel.read(locFile);
//        "name": "string",
//                "idType": "string",
//                "idNo": "string",
//                "mobile": "string",
//                "idtStatus": "string",
//                "sex": "string",
//  GHNM,`           "userName": "string",
//                "shareMobile": "string",
//                "isMcht": "string"
//        name|idType|idNo|mobile|sex|birthday|userName|shareMobile|isMcht|


        //郑希言|1|341523202211086710|13162753667|20221108|小开心|185214|0|
        String filePath = "E:/file/92330282_20241127.txt"; // 替换为你的文件路径
        Long mchtId = 92330282L;
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            List<CrmUser> userList = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                String[] split = line.split("\\|");
                CrmUser crmUser = new CrmUser();
                crmUser.setMchtId(mchtId);
                crmUser.setName(split[0]);
                crmUser.setIdType(split[1]);
                crmUser.setIdNo(split[2]);
                crmUser.setMobile(split[3]);
                crmUser.setSex(split[4]);
                crmUser.setBirthday(DateUtils.parseDate(split[5],"YYYY-MM-DD"));
                crmUser.setUserName(split[6]);
                crmUser.setShareCode(split[7]);
                crmUser.setIsMcht(split[8]);
                crmUser.setUserId(UUIDUtil.snowflakeId());
                userList.add(crmUser);
            }
            crmUserDao.insertOrUpdateBatch(userList);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

    }
}
