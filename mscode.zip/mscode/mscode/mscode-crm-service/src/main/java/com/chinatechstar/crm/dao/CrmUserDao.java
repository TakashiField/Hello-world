package com.chinatechstar.crm.dao;

import com.chinatechstar.crm.entity.CrmUser;
import com.chinatechstar.crm.vo.CrmPersonInfo;
import com.chinatechstar.crm.vo.CrmUserVO;
import org.apache.ibatis.annotations.Param;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.List;
import java.util.Map;

/**
 * 会员基础信息表(CrmUser)表数据库访问层
 *
 * @author zhengxl
 * @since 2024-06-28 11:31:37
 */
public interface CrmUserDao {

    /**
     * 通过ID查询单条数据
     *
     * @param userId 主键
     * @return 实例对象
     */
    CrmUser queryById(Long userId);

    /**
     * 查询指定行数据
     *
     * @param crmUser 查询条件
     * @return 对象列表
     */
    List<CrmUser> queryAllByPage(CrmUserVO crmUser);

    /**
     * 统计总行数
     *
     * @param crmUser 查询条件
     * @return 总行数
     */
    long count(CrmUser crmUser);

    /**
     * 新增数据
     *
     * @param crmUser 实例对象
     * @return 影响行数
     */
    int insert(CrmUser crmUser);

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmUser> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<CrmUser> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<CrmUser> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<CrmUser> entities);

    /**
     * 修改数据
     *
     * @param crmUser 实例对象
     * @return 影响行数
     */
    int update(CrmUser crmUser);

    /**
     * 通过主键删除数据
     *
     * @param userId 主键
     * @return 影响行数
     */
    int deleteById(Long userId);

    Long selectIdByNameMobileMchtId(@Param("name") String name, @Param("mobile") String mobile, @Param("mchtId") @NotBlank @Size Long mchtId);

    List<CrmPersonInfo> selectIdNoByNameMchtId(@Param("name") String name, @Param("mchtId") @NotBlank @Size Long mchtId);


}

