package com.chinatechstar.admin.client;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 提供给其他微服务调用的角色微服务接口的熔断降级类
 * 
 * @版权所有 东软集团
 */
@Component
public class SysRoleServiceClientFallback implements SysRoleServiceClient {

	/**
	 * 查询当前用户的过滤数据字段
	 */
	@Override
	public String queryRoleData(String menuCode, String username, String tenantCode) {
		return null;
	}

}
